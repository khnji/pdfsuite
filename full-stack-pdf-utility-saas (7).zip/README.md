# PDF Suite Pro

Enterprise document workspace that runs 100% in the browser (pdf.js, pdf-lib, Mammoth, SheetJS, JSZip, qrcode-generator, jsQR are loaded from CDNs on demand).
Supabase is used only for **auth**, **AppSumo license keys** and **support tickets**.

## Routes
| Route | Purpose |
|-------|---------|
| `/` | Workspace (Free Basic Mode for guests, Lifetime Premium for activated users) |
| `/signup` | Full name, email, password + **AppSumo License Key** |
| `/login` | Email + password (no key needed again) |
| `/admin` | Hidden support inbox (passcode protected) – view & delete `support_tickets` |

## Supabase
* URL / anon key are set in `src/lib/supabase.ts` (override with `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`).
* License table: `"appsumo_licenses pdf"` – columns `license_key`, `status`. The app tries that exact name first and
  automatically falls back to `appsumo_licensespdf` (the name PostgREST exposes for it).
* Sign-up flow: key lookup → `status === "active"` → `auth.signUp` (instant, no email confirmation) →
  `update({ status: <user email> }).eq("license_key", key)`. Any other status ⇒ *"This license key has already been redeemed by another account."*
  No match ⇒ *"Invalid AppSumo license key. Please check the key and try again."*
* Make sure **Authentication → Providers → Email → "Confirm email" is OFF** (it already is on your project).
* `supabase/policies.sql` contains the RLS policies the app needs.

## Admin passcode
Set `NEXT_PUBLIC_ADMIN_PASSCODE` (Netlify → Site settings → Environment variables). Default: `pdfsuite-admin`.
For real security also restrict `support_tickets` with RLS (see `supabase/policies.sql`).

## Netlify
Deploy as a Next.js site (Netlify detects it automatically). Build command: `npm run build`.
No server code or API keys are required for any tool – everything runs client-side.
