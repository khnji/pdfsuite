"use client";
import { BadgeCheck, Clock, Combine, FilePenLine, LifeBuoy, LogIn, LogOut, Lock, Menu, MessageSquareText, QrCode, Repeat, ScanLine, ShieldAlert, UserPlus, X, type LucideIcon } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useAuth } from "./AuthProvider";
import ChatPanel from "./ChatPanel";
import ConvertPanel from "./ConvertPanel";
import Editor from "./editor/Editor";
import QrPanel from "./QrPanel";
import RecentWork from "./RecentWork";
import ScannerPanel from "./ScannerPanel";
import SupportPanel from "./SupportPanel";
import { Logo } from "./ui";
import { WorkspaceProvider, useWS, type Tab } from "./Workspace";

type NavItem = { id: Tab | "pages"; label: string; icon: LucideIcon; premium?: boolean };
const NAV: NavItem[] = [
  { id: "editor", label: "Workspace", icon: FilePenLine },
  { id: "convert", label: "Convert", icon: Repeat },
  { id: "chat", label: "Ask Your PDF", icon: MessageSquareText, premium: true },
  { id: "qr", label: "QR Toolkit", icon: QrCode },
  { id: "scanner", label: "Doc Scanner", icon: ScanLine, premium: true },
  { id: "pages", label: "Merge & Crop", icon: Combine, premium: true },
  { id: "recent", label: "Recent Work", icon: Clock },
  { id: "support", label: "Support", icon: LifeBuoy },
];

export default function Shell() {
  return (
    <WorkspaceProvider>
      <ShellInner />
    </WorkspaceProvider>
  );
}

function ShellInner() {
  const ws = useWS();
  const { user, premium, signOut, openGate, gate, loading } = useAuth();
  const [open, setOpen] = useState(false);

  const go = (item: NavItem) => {
    if (item.premium && !gate(item.label)) {
      setOpen(false);
      return;
    }
    if (item.id === "pages") ws.openPages();
    else {
      if (item.id === "editor" && ws.panel === "pages") ws.setPanel(null);
      ws.setTab(item.id);
    }
    setOpen(false);
  };
  const isActive = (item: NavItem) => (item.id === "pages" ? ws.tab === "editor" && ws.panel === "pages" : item.id === "editor" ? ws.tab === "editor" && ws.panel !== "pages" : ws.tab === item.id);
  const name = (user?.user_metadata?.full_name as string | undefined) || user?.email?.split("@")[0] || "";

  const locked = !premium && (ws.tab === "chat" || ws.tab === "scanner");

  return (
    <div className="flex h-dvh overflow-hidden bg-[#090b10]">
      {open && <div className="fixed inset-0 z-40 bg-black/70 md:hidden" onClick={() => setOpen(false)} />}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 shrink-0 flex-col border-r border-white/10 bg-[#0c0f15] transition-transform duration-200 md:static md:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="flex items-center gap-3 px-4 py-4">
          <Logo />
          <div className="leading-tight">
            <div className="text-[15px] font-bold text-white">PDF Suite Pro</div>
            <div className="text-[11px] text-zinc-500">Document Workspace</div>
          </div>
          <button className="ml-auto rounded p-1 text-zinc-400 hover:bg-white/10 md:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav className="min-h-0 flex-1 space-y-1 overflow-y-auto px-3 py-2">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = isActive(item);
            return (
              <button
                key={item.id}
                onClick={() => go(item)}
                className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${active ? "bg-gradient-to-r from-[#ff4a00]/25 to-[#ff4a00]/5 text-white shadow-[inset_3px_0_0_#ff4a00]" : "text-zinc-400 hover:bg-white/5 hover:text-white"}`}
              >
                <Icon className={`h-[18px] w-[18px] ${active ? "text-[#ff7a3d]" : ""}`} />
                <span className="flex-1 text-left">{item.label}</span>
                {item.premium && !premium && <Lock className="h-3.5 w-3.5 text-zinc-600" />}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-white/10 p-3">
          {loading ? null : user ? (
            <div className="rounded-xl bg-white/[0.04] p-3">
              <div className="truncate text-sm font-semibold text-white">{name}</div>
              <div className="truncate text-[11px] text-zinc-500">{user.email}</div>
              <button onClick={() => signOut()} className="mt-2 inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white">
                <LogOut className="h-3.5 w-3.5" /> Log out
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <Link href="/login" className="btn-ghost !px-2 !py-2 text-xs">
                <LogIn className="h-3.5 w-3.5" /> Log in
              </Link>
              <Link href="/signup" className="btn-primary !px-2 !py-2 text-xs">
                <UserPlus className="h-3.5 w-3.5" /> Sign up
              </Link>
            </div>
          )}
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex shrink-0 items-center gap-3 border-b border-white/10 bg-[#0c0f15] px-3 py-2 sm:px-4">
          <button className="rounded-lg p-2 text-zinc-300 hover:bg-white/10 md:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
          <div className="min-w-0 flex-1">
            {premium ? (
              <div className="premium-badge inline-flex max-w-full items-center gap-2 rounded-full border border-emerald-400/60 bg-gradient-to-r from-emerald-500/25 to-emerald-400/10 px-3.5 py-1.5 text-[11px] font-extrabold tracking-wider text-emerald-300 sm:text-xs">
                <BadgeCheck className="h-4 w-4 shrink-0" />
                <span className="truncate">LIFETIME PREMIUM ACCESS ACTIVATED</span>
              </div>
            ) : (
              <button
                onClick={() => openGate()}
                className="inline-flex max-w-full items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 text-left text-[11px] font-medium leading-tight text-amber-200 hover:bg-amber-500/15 sm:text-xs"
              >
                <ShieldAlert className="h-4 w-4 shrink-0 text-amber-400" />
                <span>Free Basic Mode • Enter AppSumo Code to Unlock Enterprise Features</span>
              </button>
            )}
          </div>
        </header>
        <main className="min-h-0 flex-1 overflow-hidden">
          {locked ? (
            <div className="grid h-full place-items-center p-6 text-center">
              <div className="max-w-sm">
                <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-[#ff4a00]/15 text-[#ff7a3d]">
                  <Lock className="h-8 w-8" />
                </div>
                <h2 className="text-xl font-bold text-white">Premium feature</h2>
                <p className="mt-2 text-sm text-zinc-400">Activate your AppSumo lifetime license to use this tool.</p>
                <button className="btn-primary mt-5" onClick={() => openGate()}>
                  Unlock now
                </button>
              </div>
            </div>
          ) : (
            <>
              {ws.tab === "editor" && <Editor />}
              {ws.tab === "convert" && <ConvertPanel />}
              {ws.tab === "chat" && <ChatPanel />}
              {ws.tab === "qr" && <QrPanel />}
              {ws.tab === "scanner" && <ScannerPanel />}
              {ws.tab === "recent" && <RecentWork />}
              {ws.tab === "support" && <SupportPanel />}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
