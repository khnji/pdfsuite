"use client";
import { AlertTriangle, Loader2, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

export function ErrorFlash({ message }: { message: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (message) setN((x) => x + 1);
  }, [message]);
  if (!message) return null;
  return (
    // key forces the shake animation to replay whenever a new error appears
    <div
      key={n}
      role="alert"
      className="animate-shake flex items-start gap-3 rounded-xl border border-red-500/60 bg-red-500/15 px-4 py-3 text-sm font-medium text-red-200 shadow-[0_0_24px_rgba(239,68,68,0.25)]"
    >
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
      <span>{message}</span>
    </div>
  );
}

export function Spinner({ className = "h-4 w-4" }: { className?: string }) {
  return <Loader2 className={`${className} animate-spin`} />;
}

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4" onMouseDown={onClose}>
      <div
        className={`animate-pop max-h-[92dvh] w-full overflow-y-auto rounded-t-2xl border border-white/10 bg-[#11141b] p-5 shadow-2xl sm:rounded-2xl ${wide ? "sm:max-w-2xl" : "sm:max-w-md"}`}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-zinc-400 hover:bg-white/10 hover:text-white" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <div
      style={{ width: size, height: size }}
      className="grid shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#ff4a00] to-[#ff9a1a] font-black text-white shadow-[0_6px_20px_rgba(255,74,0,0.4)]"
    >
      <span style={{ fontSize: size * 0.42 }}>PS</span>
    </div>
  );
}
