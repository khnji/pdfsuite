"use client";
import { Camera, CameraOff, FilePlus2, FileText, ImageUp, SwitchCamera, Trash2, Wand2 } from "lucide-react";
import { useState } from "react";
import { fileToImage } from "@/lib/docOps";
import { downloadBlob, saveToHistory } from "@/lib/history";
import { loadPdfLib } from "@/lib/libs";
import { uid } from "@/lib/types";
import { useCamera } from "@/lib/useCamera";
import { ErrorFlash, Spinner } from "./ui";
import { useWS } from "./Workspace";

type Filter = "original" | "enhance" | "gray" | "bw";
type Shot = { id: string; src: string; filter: Filter };

const FILTERS: { id: Filter; label: string }[] = [
  { id: "original", label: "Original" },
  { id: "enhance", label: "Enhance" },
  { id: "gray", label: "Grayscale" },
  { id: "bw", label: "B&W" },
];
const CSS_FILTER: Record<Filter, string> = { original: "none", enhance: "contrast(1.25) brightness(1.08)", gray: "grayscale(1)", bw: "grayscale(1) contrast(3) brightness(1.1)" };

async function processShot(src: string, f: Filter): Promise<string> {
  const img = await new Promise<HTMLImageElement>((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = () => rej(new Error("image"));
    i.src = src;
  });
  const c = document.createElement("canvas");
  c.width = img.naturalWidth;
  c.height = img.naturalHeight;
  const ctx = c.getContext("2d")!;
  ctx.drawImage(img, 0, 0);
  if (f !== "original") {
    const d = ctx.getImageData(0, 0, c.width, c.height);
    const p = d.data;
    let mean = 0;
    if (f === "bw") {
      for (let i = 0; i < p.length; i += 4) mean += p[i] * 0.299 + p[i + 1] * 0.587 + p[i + 2] * 0.114;
      mean /= p.length / 4;
    }
    for (let i = 0; i < p.length; i += 4) {
      let r = p[i], g = p[i + 1], b = p[i + 2];
      if (f === "enhance") {
        r = (r - 128) * 1.25 + 128 + 10;
        g = (g - 128) * 1.25 + 128 + 10;
        b = (b - 128) * 1.25 + 128 + 10;
      } else {
        const l = r * 0.299 + g * 0.587 + b * 0.114;
        r = g = b = f === "bw" ? (l > mean * 0.88 ? 255 : 0) : l;
      }
      p[i] = r;
      p[i + 1] = g;
      p[i + 2] = b;
    }
    ctx.putImageData(d, 0, 0);
  }
  return c.toDataURL("image/jpeg", 0.9);
}

export default function ScannerPanel() {
  const ws = useWS();
  const cam = useCamera();
  const [shots, setShots] = useState<Shot[]>([]);
  const [filter, setFilter] = useState<Filter>("enhance");
  const [busy, setBusy] = useState(false);
  const [flash, setFlash] = useState(false);

  const capture = () => {
    const v = cam.videoRef.current;
    if (!v || !v.videoWidth) return;
    const k = Math.min(1, 2000 / Math.max(v.videoWidth, v.videoHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(v.videoWidth * k);
    c.height = Math.round(v.videoHeight * k);
    c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height);
    setShots((s) => [...s, { id: uid(), src: c.toDataURL("image/jpeg", 0.92), filter }]);
    setFlash(true);
    setTimeout(() => setFlash(false), 140);
    if (navigator.vibrate) navigator.vibrate(30);
  };

  const upload = async (files: FileList | null) => {
    if (!files) return;
    for (const f of Array.from(files)) {
      try {
        const im = await fileToImage(f, 2400);
        setShots((s) => [...s, { id: uid(), src: im.src, filter }]);
      } catch (e) {
        ws.toast((e as Error).message, "error");
      }
    }
  };

  const build = async () => {
    setBusy(true);
    try {
      const L = await loadPdfLib();
      const pdf = await L.PDFDocument.create();
      for (const s of shots) {
        const url = await processShot(s.src, s.filter);
        const im = await pdf.embedJpg(url);
        const landscape = im.width > im.height;
        const [W, H] = landscape ? [841.89, 595.28] : [595.28, 841.89];
        const k = Math.min(W / im.width, H / im.height);
        const page = pdf.addPage([im.width * k, im.height * k]);
        page.drawImage(im, { x: 0, y: 0, width: im.width * k, height: im.height * k });
      }
      pdf.setProducer("PDF Suite Pro");
      const bytes: Uint8Array = await pdf.save();
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      const fn = `scan-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.pdf`;
      downloadBlob(blob, fn);
      await saveToHistory(fn, "Doc Scanner", { blob });
      ws.toast(`Scan saved as ${fn}`, "ok");
      return new File([blob], fn, { type: "application/pdf" });
    } catch (e) {
      ws.toast("Could not build PDF: " + (e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto h-full max-w-5xl overflow-y-auto p-4 sm:p-6">
      <div className="mb-5">
        <h2 className="text-xl font-bold text-white">Document Scanner</h2>
        <p className="text-sm text-zinc-400">Capture paper documents with your camera (or upload photos), clean them up and turn them into a PDF.</p>
      </div>
      <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <div className="card p-4">
          <div className="relative aspect-[3/4] max-h-[62dvh] w-full overflow-hidden rounded-xl bg-black sm:aspect-[4/3]">
            <video ref={cam.videoRef} playsInline muted autoPlay className={`h-full w-full object-cover ${cam.active ? "" : "invisible"}`} style={{ filter: CSS_FILTER[filter] }} />
            {!cam.active && (
              <div className="absolute inset-0 grid place-items-center text-center text-sm text-zinc-500">
                <div>
                  <CameraOff className="mx-auto mb-2 h-10 w-10" />
                  Camera is off
                </div>
              </div>
            )}
            {cam.active && <div className="pointer-events-none absolute inset-[6%] rounded-lg border-2 border-dashed border-white/40" />}
            {flash && <div className="absolute inset-0 bg-white/80" />}
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {!cam.active ? (
              <button className="btn-primary flex-1" onClick={() => cam.start()}>
                <Camera className="h-4 w-4" /> Start camera
              </button>
            ) : (
              <>
                <button className="btn-primary flex-1" onClick={capture}>
                  <Camera className="h-4 w-4" /> Capture page
                </button>
                <button className="btn-ghost" onClick={() => cam.flip()} aria-label="Switch camera">
                  <SwitchCamera className="h-4 w-4" />
                </button>
                <button className="btn-ghost" onClick={cam.stop}>
                  <CameraOff className="h-4 w-4" />
                </button>
              </>
            )}
            <label className="btn-ghost cursor-pointer">
              <ImageUp className="h-4 w-4" /> Upload photos
              <input type="file" accept="image/*" multiple hidden onChange={(e) => { upload(e.target.files); e.target.value = ""; }} />
            </label>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <Wand2 className="h-4 w-4 text-[#ff7a3d]" />
            {FILTERS.map((f) => (
              <button key={f.id} className={`tb-btn ${filter === f.id ? "active" : ""}`} onClick={() => setFilter(f.id)}>
                {f.label}
              </button>
            ))}
          </div>
          <div className="mt-3">
            <ErrorFlash message={cam.error} />
          </div>
        </div>

        <div className="card flex flex-col p-4">
          <h3 className="mb-3 text-sm font-semibold text-white">Scanned pages ({shots.length})</h3>
          {shots.length === 0 ? (
            <p className="py-8 text-center text-sm text-zinc-500">Captured pages will appear here.</p>
          ) : (
            <div className="grid max-h-[46dvh] grid-cols-3 gap-2 overflow-y-auto sm:grid-cols-4 lg:grid-cols-3">
              {shots.map((s, i) => (
                <div key={s.id} className="group relative overflow-hidden rounded-lg border border-white/10 bg-black">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={s.src} alt={`Scan ${i + 1}`} className="aspect-[3/4] w-full object-cover" style={{ filter: CSS_FILTER[s.filter] }} />
                  <span className="absolute left-1 top-1 rounded bg-black/70 px-1.5 text-[10px] text-white">{i + 1}</span>
                  <button className="absolute right-1 top-1 rounded bg-black/70 p-1 text-red-300" onClick={() => setShots((x) => x.filter((y) => y.id !== s.id))} aria-label="Delete scan">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                  <select className="absolute inset-x-1 bottom-1 rounded bg-black/70 px-1 py-0.5 text-[10px] text-white" value={s.filter} onChange={(e) => setShots((x) => x.map((y) => (y.id === s.id ? { ...y, filter: e.target.value as Filter } : y)))}>
                    {FILTERS.map((f) => (
                      <option key={f.id} value={f.id}>{f.label}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          )}
          <div className="mt-4 space-y-2">
            <button className="btn-primary w-full" disabled={!shots.length || busy} onClick={build}>
              {busy ? <Spinner /> : <FileText className="h-4 w-4" />} Create & download PDF
            </button>
            <button
              className="btn-ghost w-full"
              disabled={!shots.length || busy}
              onClick={async () => {
                const f = await build();
                if (f && (await ws.openFiles([f]))) ws.setTab("editor");
              }}
            >
              <FilePlus2 className="h-4 w-4" /> Create PDF & edit it
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
