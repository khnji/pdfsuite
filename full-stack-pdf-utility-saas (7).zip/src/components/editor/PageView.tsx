"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import { memo, useEffect, useMemo, useRef, useState } from "react";
import { FONT_CSS, type FontFamily, type Layer, type PageMeta, type Source, type TextEdit } from "@/lib/types";
import LayerBox from "./LayerBox";

export type Tool = "select" | "text" | "note" | "highlight" | "redact" | "link";

type Item = { i: number; str: string; x: number; base: number; fs: number; w: number; family: FontFamily; k: number; mw: number };

type Props = {
  meta: PageMeta;
  index: number;
  zoom: number;
  source?: Source;
  layers: Layer[];
  edits: Record<string, TextEdit>;
  tool: Tool;
  selectedId: string | null;
  autoEditId: string | null;
  onSelect: (id: string | null) => void;
  onLayerCommit: (id: string, patch: Partial<Layer>) => void;
  onLayerDelete: (id: string) => void;
  onAutoEditDone: () => void;
  onTextEdit: (pageId: string, i: number, edit: TextEdit | null) => void;
  onDraw: (pageId: string, tool: Tool, rect: { x: number; y: number; w: number; h: number }) => void;
  onActive: (index: number, ratio: number) => void;
};

let measureCtx: CanvasRenderingContext2D | null = null;
const measure = (font: string, s: string) => {
  measureCtx ||= document.createElement("canvas").getContext("2d");
  if (!measureCtx) return 0;
  measureCtx.font = font;
  return measureCtx.measureText(s).width;
};

function PageViewImpl(p: Props) {
  const { meta, index, zoom, source, layers, edits, tool, selectedId } = p;
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [visible, setVisible] = useState(index < 2);
  const [items, setItems] = useState<Item[]>([]);
  const [draft, setDraft] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const drawStart = useRef<{ x: number; y: number } | null>(null);

  // visibility (lazy render) + active page tracking
  useEffect(() => {
    const el = outerRef.current;
    if (!el) return;
    const io1 = new IntersectionObserver((es) => es.forEach((e) => setVisible(e.isIntersecting)), { rootMargin: "900px 0px" });
    const io2 = new IntersectionObserver((es) => es.forEach((e) => p.onActive(index, e.intersectionRatio)), {
      threshold: [0, 0.1, 0.25, 0.4, 0.55, 0.7, 0.85, 1],
    });
    io1.observe(el);
    io2.observe(el);
    return () => {
      io1.disconnect();
      io2.disconnect();
      p.onActive(index, 0);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  // render PDF page into canvas
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    if (!visible || !source) {
      cv.width = 0;
      cv.height = 0;
      return;
    }
    let cancelled = false;
    let task: any;
    (async () => {
      try {
        const page = await source.pdf.getPage((meta.srcIndex || 0) + 1);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const scale = Math.min(zoom * dpr, 4200 / Math.max(meta.w, meta.h));
        const vp = page.getViewport({ scale });
        const buf = document.createElement("canvas");
        buf.width = Math.floor(vp.width);
        buf.height = Math.floor(vp.height);
        task = page.render({ canvasContext: buf.getContext("2d"), viewport: vp });
        await task.promise;
        if (cancelled) return;
        cv.width = buf.width;
        cv.height = buf.height;
        cv.getContext("2d")!.drawImage(buf, 0, 0);
      } catch {
        /* cancelled render */
      }
    })();
    return () => {
      cancelled = true;
      try {
        task?.cancel();
      } catch {
        /* ignore */
      }
    };
  }, [visible, source, meta.srcIndex, meta.w, meta.h, zoom]);

  // text items for precise in-place editing
  useEffect(() => {
    if (!visible || !source) {
      setItems((s) => (s.length ? [] : s));
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const page = await source.pdf.getPage((meta.srcIndex || 0) + 1);
        const vp = page.getViewport({ scale: 1 });
        const tc = await page.getTextContent();
        const m1 = vp.transform;
        const out: Item[] = [];
        (tc.items as any[]).forEach((it, i) => {
          if (!it.str || !it.str.trim()) return;
          const m2 = it.transform;
          const a = m1[0] * m2[0] + m1[2] * m2[1];
          const b = m1[1] * m2[0] + m1[3] * m2[1];
          const c = m1[0] * m2[2] + m1[2] * m2[3];
          const d = m1[1] * m2[2] + m1[3] * m2[3];
          const e = m1[0] * m2[4] + m1[2] * m2[5] + m1[4];
          const f = m1[1] * m2[4] + m1[3] * m2[5] + m1[5];
          const fs = Math.hypot(c, d);
          if (fs < 2 || Math.abs(b) > 0.02 * Math.hypot(a, b) || Math.abs(c) > 0.02 * fs * 4) return;
          const ff: string = tc.styles?.[it.fontName]?.fontFamily || "";
          const family: FontFamily = /mono|courier/i.test(ff) ? "mono" : /serif/i.test(ff) && !/sans/i.test(ff) ? "serif" : "sans";
          const mw = measure(`${fs}px ${FONT_CSS[family]}`, it.str);
          const w = Math.max(1, it.width * (Math.hypot(a, b) / (Math.hypot(m2[0], m2[1]) || 1)));
          out.push({ i, str: it.str, x: e, base: f, fs, w, family, mw, k: mw > 0 ? Math.min(2.5, Math.max(0.4, w / mw)) : 1 });
        });
        if (!cancelled) setItems(out);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, source, meta.srcIndex]);

  const pageEdits = useMemo(() => {
    const pre = meta.id + ":";
    const o: Record<number, TextEdit> = {};
    for (const k in edits) if (k.startsWith(pre)) o[+k.slice(pre.length)] = edits[k];
    return o;
  }, [edits, meta.id]);

  const toPage = (e: React.PointerEvent) => {
    const r = innerRef.current!.getBoundingClientRect();
    return { x: (e.clientX - r.left) / zoom, y: (e.clientY - r.top) / zoom };
  };

  // click in blank space between words -> caret jumps to the nearest text position
  const onBgDown = (e: React.PointerEvent) => {
    p.onSelect(null);
    const t = e.target as HTMLElement;
    if (t.closest("[data-ti]") || !items.length) return;
    const { x: px, y: py } = toPage(e);
    let best: Item | null = null;
    let bd = 1e9;
    for (const it of items) {
      if (Math.abs(py - (it.base - it.fs * 0.35)) > it.fs * 0.8) continue;
      const dx = px < it.x ? it.x - px : px > it.x + it.w ? px - (it.x + it.w) : 0;
      if (dx < bd) {
        bd = dx;
        best = it;
      }
    }
    if (best && bd < 90) {
      const el = innerRef.current!.querySelector(`[data-ti="${best.i}"]`) as HTMLElement | null;
      if (!el) return;
      e.preventDefault();
      el.focus();
      const r = document.createRange();
      r.selectNodeContents(el);
      r.collapse(px < best.x + best.w / 2);
      const s = window.getSelection();
      s?.removeAllRanges();
      s?.addRange(r);
    }
  };

  const drawing = tool !== "select";
  const onDrawDown = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drawStart.current = toPage(e);
    setDraft({ ...drawStart.current, w: 0, h: 0 });
  };
  const onDrawMove = (e: React.PointerEvent) => {
    const s = drawStart.current;
    if (!s) return;
    const c = toPage(e);
    setDraft({ x: Math.min(s.x, c.x), y: Math.min(s.y, c.y), w: Math.abs(c.x - s.x), h: Math.abs(c.y - s.y) });
  };
  const onDrawUp = (e: React.PointerEvent) => {
    const s = drawStart.current;
    drawStart.current = null;
    if (!s) return;
    const c = toPage(e);
    const r = { x: Math.min(s.x, c.x), y: Math.min(s.y, c.y), w: Math.abs(c.x - s.x), h: Math.abs(c.y - s.y) };
    setDraft(null);
    if (r.w < 6 && r.h < 6) r.x = c.x, r.y = c.y, r.w = 0, r.h = 0; // simple click
    p.onDraw(meta.id, tool, r);
  };

  const cropped = meta.crop.l || meta.crop.t || meta.crop.r || meta.crop.b;
  const cw = (meta.w - meta.crop.l - meta.crop.r) * zoom;
  const ch = (meta.h - meta.crop.t - meta.crop.b) * zoom;

  return (
    <div
      ref={outerRef}
      id={`page-${index}`}
      className="page-shadow relative mx-auto mb-5 bg-white"
      style={{ width: cw, height: ch, overflow: cropped ? "hidden" : "visible", flexShrink: 0 }}
    >
      <div
        ref={innerRef}
        className="absolute bg-white"
        style={{ left: -meta.crop.l * zoom, top: -meta.crop.t * zoom, width: meta.w * zoom, height: meta.h * zoom }}
        onPointerDown={onBgDown}
      >
        {source ? (
          <canvas ref={canvasRef} className="pointer-events-none absolute left-0 top-0 select-none" style={{ width: meta.w * zoom, height: meta.h * zoom }} />
        ) : meta.bg ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={meta.bg} alt="" draggable={false} className="pointer-events-none absolute inset-0 h-full w-full select-none" />
        ) : null}

        {items.map((it) => {
          const ed = pageEdits[it.i];
          return (
            <span
              key={`${it.i}:${ed ? ed.text : ""}`}
              data-ti={it.i}
              contentEditable
              suppressContentEditableWarning
              spellCheck={false}
              onInput={(e) => {
                e.currentTarget.style.background = "#fff";
                e.currentTarget.style.color = "#000";
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.width = "auto";
                e.currentTarget.style.minWidth = it.w * zoom + "px";
              }}
              onKeyDown={(e) => {
                e.stopPropagation();
                if (e.key === "Enter" || e.key === "Escape") {
                  e.preventDefault();
                  e.currentTarget.blur();
                }
              }}
              onPaste={(e) => {
                e.preventDefault();
                document.execCommand("insertText", false, e.clipboardData.getData("text/plain").replace(/\s+/g, " "));
              }}
              onBlur={(e) => {
                const txt = (e.currentTarget.textContent || "").replace(/\u00a0/g, " ");
                const cur = ed ? ed.text : it.str;
                if (txt === cur) return;
                if (txt === it.str) return p.onTextEdit(meta.id, it.i, null);
                p.onTextEdit(meta.id, it.i, {
                  text: txt, orig: it.str, x: it.x, top: it.base - it.fs * 1.02, w: it.w, h: it.fs * 1.3, fs: it.fs, base: it.base, family: it.family, color: "#000000",
                });
              }}
              className="absolute z-[5] cursor-text"
              style={{
                left: it.x * zoom,
                top: (it.base - it.fs * 0.97) * zoom,
                fontSize: it.fs * zoom,
                lineHeight: 1.25,
                fontFamily: FONT_CSS[it.family],
                whiteSpace: "pre",
                color: ed ? "#000" : "transparent",
                background: ed ? "#fff" : "transparent",
                caretColor: "#ff4a00",
                transformOrigin: "0 0",
                ...(ed ? { minWidth: it.w * zoom } : { transform: `scaleX(${it.k})`, width: it.mw * zoom }),
              }}
            >
              {ed ? ed.text : it.str}
            </span>
          );
        })}

        {layers.map((l) =>
          l.hidden ? null : (
            <LayerBox
              key={l.id}
              layer={l}
              zoom={zoom}
              selected={selectedId === l.id}
              autoEdit={p.autoEditId === l.id}
              onSelect={p.onSelect}
              onCommit={p.onLayerCommit}
              onDelete={p.onLayerDelete}
              onAutoEditDone={p.onAutoEditDone}
            />
          )
        )}

        {drawing && (
          <div
            className="absolute inset-0 z-[60] cursor-crosshair touch-none"
            onPointerDown={onDrawDown}
            onPointerMove={onDrawMove}
            onPointerUp={onDrawUp}
            onPointerCancel={() => {
              drawStart.current = null;
              setDraft(null);
            }}
          >
            {draft && (
              <div
                className={`absolute border-2 border-dashed ${tool === "redact" ? "border-black bg-black/60" : tool === "highlight" ? "border-yellow-500 bg-yellow-300/50" : "border-[#ff4a00] bg-[#ff4a00]/15"}`}
                style={{ left: draft.x * zoom, top: draft.y * zoom, width: draft.w * zoom, height: draft.h * zoom }}
              />
            )}
          </div>
        )}
      </div>
      <div className="pointer-events-none absolute -bottom-5 right-0 text-[10px] text-zinc-500">{index + 1}</div>
    </div>
  );
}

export default memo(PageViewImpl);
