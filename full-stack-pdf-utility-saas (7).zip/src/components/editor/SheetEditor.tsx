"use client";
import { FileDown, Plus, Repeat, Table2 } from "lucide-react";
import { useState } from "react";
import { useWS } from "../Workspace";
import { Spinner } from "../ui";

const colName = (n: number) => {
  let s = "";
  n++;
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
};

export default function SheetEditor({ onSave, saving }: { onSave: () => void; saving: boolean }) {
  const ws = useWS();
  const sheet = ws.sheet!;
  const [active, setActive] = useState(0);
  const [limit, setLimit] = useState(300);
  const cur = sheet.sheets[Math.min(active, sheet.sheets.length - 1)];
  const rows = cur.rows;
  const cols = Math.max(1, ...rows.slice(0, 500).map((r) => r.length));

  const update = (fn: (rows: string[][]) => string[][]) =>
    ws.setSheet((s) => ({ sheets: s.sheets.map((x, i) => (i === active ? { ...x, rows: fn(x.rows) } : x)) }));

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-b border-white/10 bg-[#0d1017] px-2 py-1.5">
        <span className="tb-btn !cursor-default text-zinc-400"><Table2 className="h-4 w-4 text-[#ff7a3d]" /> {ws.name}</span>
        <button className="btn-primary !px-3 !py-1.5 !text-xs" onClick={onSave} disabled={saving}>
          {saving ? <Spinner /> : <FileDown className="h-4 w-4" />} Save as PDF
        </button>
        <button className="tb-btn" onClick={() => ws.setTab("convert")}><Repeat className="h-4 w-4" /> Convert (CSV, XLSX, HTML…)</button>
        <button className="tb-btn" onClick={() => update((r) => [...r, Array(cols).fill("")])}><Plus className="h-4 w-4" /> Row</button>
        <button className="tb-btn" onClick={() => update((r) => r.map((x) => [...x, ""]))}><Plus className="h-4 w-4" /> Column</button>
        <button className="tb-btn ml-auto" onClick={ws.closeDoc}>Close</button>
      </div>
      <div className="min-h-0 flex-1 overflow-auto bg-[#0a0c10] p-2 sm:p-4">
        <table className="border-separate border-spacing-0 text-sm text-zinc-200">
          <thead>
            <tr>
              <th className="sticky left-0 top-0 z-20 min-w-10 border border-white/10 bg-[#1a1e28] px-2 py-1 text-xs text-zinc-500" />
              {Array.from({ length: cols }, (_, c) => (
                <th key={c} className="sticky top-0 z-10 min-w-28 border border-white/10 bg-[#1a1e28] px-2 py-1 text-xs font-semibold text-zinc-400">
                  {colName(c)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, limit).map((row, ri) => (
              <tr key={ri}>
                <td className="sticky left-0 z-10 border border-white/10 bg-[#1a1e28] px-2 py-1 text-center text-xs text-zinc-500">{ri + 1}</td>
                {Array.from({ length: cols }, (_, ci) => {
                  const cell = row[ci] ?? "";
                  return (
                    <td
                      key={`${ci}-${cell}`}
                      contentEditable
                      suppressContentEditableWarning
                      spellCheck={false}
                      onBlur={(e) => {
                        const v = e.currentTarget.innerText.replace(/\n$/, "");
                        if (v === cell) return;
                        update((rs) => rs.map((r, i) => (i === ri ? Array.from({ length: cols }, (_, k) => (k === ci ? v : r[k] ?? "")) : r)));
                      }}
                      className={`min-w-28 max-w-[320px] border border-white/10 px-2 py-1 align-top focus:bg-[#ff4a00]/10 focus:outline focus:outline-1 focus:outline-[#ff4a00] ${ri === 0 ? "bg-white/[0.05] font-semibold" : "bg-[#10131a]"}`}
                    >
                      {cell}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length > limit && (
          <button className="btn-ghost mt-3" onClick={() => setLimit((l) => l + 500)}>
            Show more rows ({rows.length - limit} remaining)
          </button>
        )}
      </div>
      <div className="flex shrink-0 gap-1 overflow-x-auto border-t border-white/10 bg-[#0d1017] px-2 py-1.5">
        {sheet.sheets.map((s, i) => (
          <button key={s.name + i} onClick={() => { setActive(i); setLimit(300); }} className={`tb-btn ${i === active ? "active" : ""}`}>
            {s.name} <span className="text-[10px] opacity-60">{s.rows.length}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
