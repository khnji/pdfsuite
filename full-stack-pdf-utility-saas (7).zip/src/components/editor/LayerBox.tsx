"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import { GripHorizontal, Link2 } from "lucide-react";
import { memo, useEffect, useRef, useState } from "react";
import { rotPt, TEXT_PAD, LINE_H } from "@/lib/docOps";
import { FONT_CSS, type Layer } from "@/lib/types";

type Props = {
  layer: Layer;
  zoom: number;
  selected: boolean;
  autoEdit: boolean;
  onSelect: (id: string | null) => void;
  onCommit: (id: string, patch: Partial<Layer>) => void;
  onDelete: (id: string) => void;
  onAutoEditDone: () => void;
};

const HANDLE =
  "absolute z-50 h-3.5 w-3.5 rounded-[4px] border-2 border-[#ff4a00] bg-white shadow [@media(pointer:coarse)]:h-6 [@media(pointer:coarse)]:w-6 touch-none";

function LayerBoxImpl({ layer, zoom, selected, autoEdit, onSelect, onCommit, onDelete, onAutoEditDone }: Props) {
  const [g, setG] = useState<Partial<Layer> | null>(null);
  const [editing, setEditing] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number; moved: boolean; grip: boolean } | null>(null);
  const tap = useRef<{ x: number; y: number } | null>(null);
  const caret = useRef<Range | null>(null);
  const L: Layer = g ? { ...layer, ...g } : layer;
  const isText = L.type === "text";

  useEffect(() => {
    if (autoEdit) {
      setEditing(true);
      onAutoEditDone();
    }
  }, [autoEdit, onAutoEditDone]);

  useEffect(() => {
    if (!editing) return;
    const el = textRef.current;
    if (!el) return;
    el.focus();
    const sel = window.getSelection();
    if (!sel) return;
    sel.removeAllRanges();
    if (caret.current && el.contains(caret.current.startContainer)) {
      sel.addRange(caret.current);
    } else {
      const r = document.createRange();
      r.selectNodeContents(el);
      r.collapse(false);
      sel.addRange(r);
    }
    caret.current = null;
  }, [editing]);

  const rangeAt = (x: number, y: number): Range | null => {
    const d: any = document;
    if (d.caretRangeFromPoint) return d.caretRangeFromPoint(x, y);
    if (d.caretPositionFromPoint) {
      const p = d.caretPositionFromPoint(x, y);
      if (p) {
        const r = document.createRange();
        r.setStart(p.offsetNode, p.offset);
        r.collapse(true);
        return r;
      }
    }
    return null;
  };

  /* ---------- move ---------- */
  const beginDrag = (e: React.PointerEvent, grip: boolean) => {
    onSelect(layer.id);
    drag.current = { sx: e.clientX, sy: e.clientY, ox: layer.x, oy: layer.y, moved: false, grip };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onBodyDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    if (editing) return;
    if (e.pointerType === "touch" && !selected) {
      tap.current = { x: e.clientX, y: e.clientY };
      return;
    }
    beginDrag(e, false);
  };
  const onGripDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    beginDrag(e, true);
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = (e.clientX - d.sx) / zoom;
    const dy = (e.clientY - d.sy) / zoom;
    if (!d.moved && Math.hypot(dx, dy) * zoom < 4) return;
    d.moved = true;
    setG({ x: d.ox + dx, y: d.oy + dy });
  };
  const onUp = (e: React.PointerEvent) => {
    if (tap.current) {
      const t = tap.current;
      tap.current = null;
      if (Math.hypot(e.clientX - t.x, e.clientY - t.y) < 8) onSelect(layer.id);
      return;
    }
    const d = drag.current;
    drag.current = null;
    if (!d) return;
    if (d.moved && g) {
      onCommit(layer.id, { x: g.x ?? layer.x, y: g.y ?? layer.y });
      setG(null);
    } else if (isText && !d.grip) {
      caret.current = rangeAt(e.clientX, e.clientY);
      setEditing(true);
    }
  };

  /* ---------- resize ---------- */
  const resize = useRef<any>(null);
  const startResize = (sx: number, sy: number) => (e: React.PointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const h = isText ? Math.max(layer.h, (boxRef.current?.offsetHeight || 0) / zoom) : layer.h;
    resize.current = { sx, sy, px: e.clientX, py: e.clientY, x: layer.x, y: layer.y, w: layer.w, h, rot: layer.rot, fs: layer.fs || 16 };
  };
  const moveResize = (e: React.PointerEvent) => {
    const r = resize.current;
    if (!r) return;
    const dxp = (e.clientX - r.px) / zoom;
    const dyp = (e.clientY - r.py) / zoom;
    const a = (-r.rot * Math.PI) / 180;
    const ldx = dxp * Math.cos(a) - dyp * Math.sin(a);
    const ldy = dxp * Math.sin(a) + dyp * Math.cos(a);
    const minW = L.type === "text" ? 30 : 8;
    const minH = L.type === "text" ? 16 : 8;
    let nw = r.w;
    let nh = r.h;
    if (r.sx) nw = Math.max(minW, r.w + r.sx * ldx);
    if (r.sy) nh = Math.max(minH, r.h + r.sy * ldy);
    let fs = r.fs;
    if (r.sx && r.sy && (L.type === "image" || L.type === "text")) {
      const k = Math.max(0.1, (nw / r.w + nh / r.h) / 2);
      nw = Math.max(minW, r.w * k);
      nh = Math.max(minH, r.h * k);
      if (L.type === "text") fs = Math.max(4, Math.min(300, r.fs * k));
    }
    const c = rotPt(r.x + r.w / 2, r.y + r.h / 2, (r.sx * (nw - r.w)) / 2, (r.sy * (nh - r.h)) / 2, r.rot);
    const patch: Partial<Layer> = { x: c.x - nw / 2, y: c.y - nh / 2, w: nw, h: nh };
    if (L.type === "text") patch.fs = fs;
    setG(patch);
  };
  const endResize = () => {
    if (resize.current && g) onCommit(layer.id, g);
    resize.current = null;
    setG(null);
  };

  /* ---------- rotate ---------- */
  const rotating = useRef(false);
  const startRotate = (e: React.PointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    rotating.current = true;
  };
  const moveRotate = (e: React.PointerEvent) => {
    if (!rotating.current || !boxRef.current) return;
    const r = boxRef.current.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let ang = (Math.atan2(e.clientY - cy, e.clientX - cx) * 180) / Math.PI + 90;
    ang = ((ang % 360) + 360) % 360;
    const snap = Math.round(ang / 45) * 45;
    if (Math.abs(ang - snap) < 4) ang = snap % 360;
    setG({ rot: Math.round(ang * 10) / 10 });
  };
  const endRotate = () => {
    if (rotating.current && g) onCommit(layer.id, { rot: g.rot ?? layer.rot });
    rotating.current = false;
    setG(null);
  };

  /* ---------- text editing ---------- */
  const finishEdit = () => {
    const el = textRef.current;
    setEditing(false);
    if (!el) return;
    let t = el.innerText.replace(/\u00a0/g, " ");
    if (t.endsWith("\n") && !(layer.text || "").endsWith("\n")) t = t.slice(0, -1);
    if (!t.trim() && (layer.kind === "text" || layer.kind === "note")) {
      onDelete(layer.id);
      return;
    }
    const h = Math.max(layer.h, (boxRef.current?.offsetHeight || 0) / zoom);
    if (t !== (layer.text || "") || h > layer.h + 0.5) onCommit(layer.id, { text: t, h });
  };

  const fs = (L.fs || 16) * zoom;
  const style: React.CSSProperties = {
    left: L.x * zoom,
    top: L.y * zoom,
    width: L.w * zoom,
    transform: `rotate(${L.rot}deg)`,
    transformOrigin: "50% 50%",
    zIndex: selected ? 40 : 10,
    touchAction: selected ? "none" : "pan-x pan-y",
    cursor: editing ? "text" : "move",
    ...(isText ? { minHeight: L.h * zoom } : { height: L.h * zoom }),
  };

  return (
    <div
      ref={boxRef}
      data-layer={L.id}
      className="absolute select-none"
      style={style}
      onPointerDown={onBodyDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={() => {
        drag.current = null;
        tap.current = null;
        setG(null);
      }}
    >
      {isText && (
        <div
          ref={textRef}
          key={layer.text}
          dir="auto"
          contentEditable={editing}
          suppressContentEditableWarning
          spellCheck={editing}
          data-ph="Type here…"
          onBlur={finishEdit}
          onKeyDown={(e) => {
            e.stopPropagation();
            if (e.key === "Escape") (e.currentTarget as HTMLElement).blur();
          }}
          onPaste={(e) => {
            e.preventDefault();
            const t = e.clipboardData.getData("text/plain");
            document.execCommand("insertText", false, t);
          }}
          className="w-full empty:before:text-zinc-400 empty:before:content-[attr(data-ph)]"
          style={{
            padding: TEXT_PAD * zoom,
            fontSize: fs,
            lineHeight: LINE_H,
            fontFamily: FONT_CSS[L.font || "sans"],
            fontWeight: L.bold ? 700 : 400,
            fontStyle: L.italic ? "italic" : "normal",
            color: L.color || "#111",
            textAlign: L.align || "left",
            background: L.bg || "transparent",
            whiteSpace: "pre-wrap",
            overflowWrap: "anywhere",
            minHeight: L.h * zoom,
            caretColor: L.color || "#111",
            opacity: L.opacity ?? 1,
            userSelect: editing ? "text" : "none",
            WebkitUserSelect: editing ? "text" : "none",
          }}
        >
          {layer.text}
        </div>
      )}
      {L.type === "image" && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={L.src} alt="" draggable={false} className="pointer-events-none h-full w-full select-none" style={{ opacity: L.opacity ?? 1 }} />
      )}
      {L.type === "shape" && <div className="h-full w-full" style={{ background: L.fill || "#fde047", opacity: L.opacity ?? 0.4 }} />}
      {L.type === "redact" && <div className="h-full w-full bg-black" />}
      {L.type === "link" && (
        <div className="flex h-full w-full items-start justify-start overflow-hidden border-2 border-dashed border-sky-400 bg-sky-400/15">
          <span className="m-0.5 inline-flex max-w-full items-center gap-1 truncate rounded bg-sky-500 px-1 text-[10px] font-medium text-white">
            <Link2 className="h-3 w-3 shrink-0" />
            <span className="truncate">{L.url}</span>
          </span>
        </div>
      )}

      {selected && (
        <>
          <div className="pointer-events-none absolute -inset-px border-[1.5px] border-[#ff4a00]" style={{ boxShadow: "0 0 0 1px rgba(255,255,255,0.5)" }} />
          {/* drag grip */}
          <div
            onPointerDown={onGripDown}
            onPointerMove={onMove}
            onPointerUp={onUp}
            title="Drag to move"
            className="absolute left-0 z-50 flex h-6 cursor-grab touch-none items-center gap-1 rounded-md bg-[#ff4a00] px-1.5 text-[10px] font-semibold text-white shadow [@media(pointer:coarse)]:h-8 [@media(pointer:coarse)]:px-2.5"
            style={{ top: -30 }}
          >
            <GripHorizontal className="h-3.5 w-3.5" /> Move
          </div>
          {/* rotate */}
          <div className="pointer-events-none absolute left-1/2 -top-8 h-8 w-px -translate-x-1/2 bg-[#ff4a00]" style={{ display: "none" }} />
          <div
            onPointerDown={startRotate}
            onPointerMove={moveRotate}
            onPointerUp={endRotate}
            onPointerCancel={endRotate}
            title="Drag to rotate"
            className="absolute left-1/2 z-50 flex h-5 w-5 -translate-x-1/2 cursor-grab touch-none items-center justify-center rounded-full border-2 border-[#ff4a00] bg-white text-[10px] shadow [@media(pointer:coarse)]:h-8 [@media(pointer:coarse)]:w-8"
            style={{ top: -34 }}
          >
            ⟳
          </div>
          {/* corners */}
          {(
            [
              [-1, -1, "-left-2 -top-2 cursor-nwse-resize"],
              [1, -1, "-right-2 -top-2 cursor-nesw-resize"],
              [-1, 1, "-bottom-2 -left-2 cursor-nesw-resize"],
              [1, 1, "-bottom-2 -right-2 cursor-nwse-resize"],
            ] as const
          ).map(([sx, sy, cls]) => (
            <div key={cls} className={`${HANDLE} ${cls}`} onPointerDown={startResize(sx, sy)} onPointerMove={moveResize} onPointerUp={endResize} onPointerCancel={endResize} />
          ))}
          {isText && (
            <>
              <div className={`${HANDLE} -left-2 top-1/2 -translate-y-1/2 cursor-ew-resize`} onPointerDown={startResize(-1, 0)} onPointerMove={moveResize} onPointerUp={endResize} onPointerCancel={endResize} />
              <div className={`${HANDLE} -right-2 top-1/2 -translate-y-1/2 cursor-ew-resize`} onPointerDown={startResize(1, 0)} onPointerMove={moveResize} onPointerUp={endResize} onPointerCancel={endResize} />
            </>
          )}
        </>
      )}
    </div>
  );
}

export default memo(LayerBoxImpl);
