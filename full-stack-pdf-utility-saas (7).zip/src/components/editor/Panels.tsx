"use client";
import { ArrowDown, ArrowUp, Copy, Download, Eye, EyeOff, FilePlus2, Image as ImageIcon, Link2, QrCode, RectangleHorizontal, Square, Trash2, Type, X, PenLine, Layers as LayersIcon, Crop, Combine } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { baseName, loadImg, NOCROP, parsePageRange } from "@/lib/docOps";
import { downloadBlob, saveToHistory } from "@/lib/history";
import { A4, LETTER, uid, type Layer, type PageMeta, type Source } from "@/lib/types";
import { useWS } from "../Workspace";
import { Spinner } from "../ui";

function PageThumb({ meta, source }: { meta: PageMeta; source?: Source }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const io = new IntersectionObserver((e) => setVis(e[0].isIntersecting), { rootMargin: "200px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  useEffect(() => {
    const cv = ref.current;
    if (!cv || !vis) return;
    let cancel = false;
    let task: { cancel: () => void } | undefined;
    (async () => {
      const sc = 96 / meta.w;
      const buf = document.createElement("canvas");
      buf.width = 96;
      buf.height = Math.max(20, Math.round(meta.h * sc));
      const ctx = buf.getContext("2d")!;
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, buf.width, buf.height);
      try {
        if (source) {
          const page = await source.pdf.getPage((meta.srcIndex || 0) + 1);
          task = page.render({ canvasContext: ctx, viewport: page.getViewport({ scale: 96 / page.getViewport({ scale: 1 }).width }) });
          await (task as unknown as { promise: Promise<void> }).promise;
        } else if (meta.bg) {
          ctx.drawImage(await loadImg(meta.bg), 0, 0, buf.width, buf.height);
        }
      } catch {
        /* ignore */
      }
      if (cancel) return;
      cv.width = buf.width;
      cv.height = buf.height;
      cv.getContext("2d")!.drawImage(buf, 0, 0);
    })();
    return () => {
      cancel = true;
      task?.cancel();
    };
  }, [vis, meta.w, meta.h, meta.srcIndex, meta.bg, source]);
  return (
    <div ref={wrap} className="w-[60px] shrink-0 overflow-hidden rounded bg-white" style={{ aspectRatio: `${meta.w}/${meta.h}` }}>
      <canvas ref={ref} className="h-full w-full" />
    </div>
  );
}

export function PagesPanel({ activePage, onGoto, onClose }: { activePage: number; onGoto: (i: number) => void; onClose: () => void }) {
  const ws = useWS();
  const { doc, setDoc, sources } = ws;
  const [range, setRange] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const cur = doc.pages[activePage];

  const move = (i: number, d: number) =>
    setDoc((s) => {
      const j = i + d;
      if (j < 0 || j >= s.pages.length) return s;
      const pages = [...s.pages];
      [pages[i], pages[j]] = [pages[j], pages[i]];
      return { ...s, pages };
    });
  const remove = (i: number) => {
    if (doc.pages.length <= 1) return ws.toast("A document needs at least one page.", "info");
    setDoc((s) => {
      const id = s.pages[i].id;
      const edits = { ...s.edits };
      Object.keys(edits).forEach((k) => k.startsWith(id + ":") && delete edits[k]);
      return { pages: s.pages.filter((_, k) => k !== i), layers: s.layers.filter((l) => l.pageId !== id), edits };
    });
  };
  const dup = (i: number) =>
    setDoc((s) => {
      const src = s.pages[i];
      const np: PageMeta = { ...src, id: uid(), crop: { ...src.crop } };
      const layers: Layer[] = s.layers.filter((l) => l.pageId === src.id).map((l) => ({ ...l, id: uid(), pageId: np.id }));
      const edits = { ...s.edits };
      Object.keys(s.edits).forEach((k) => k.startsWith(src.id + ":") && (edits[np.id + k.slice(src.id.length)] = s.edits[k]));
      const pages = [...s.pages];
      pages.splice(i + 1, 0, np);
      return { pages, layers: [...s.layers, ...layers], edits };
    });
  const add = (w: number, h: number) =>
    setDoc((s) => ({ ...s, pages: [...s.pages, { id: uid(), w, h, crop: { ...NOCROP } }] }));

  const setCrop = (key: "l" | "t" | "r" | "b", pct: number) =>
    setDoc((s) => ({
      ...s,
      pages: s.pages.map((p, i) => {
        if (i !== activePage) return p;
        const base = key === "l" || key === "r" ? p.w : p.h;
        return { ...p, crop: { ...p.crop, [key]: (base * pct) / 100 } };
      }),
    }));
  const cropAll = () =>
    setDoc((s) => {
      const c = s.pages[activePage]?.crop;
      const ref = s.pages[activePage];
      if (!c || !ref) return s;
      return {
        ...s,
        pages: s.pages.map((p) => ({ ...p, crop: { l: (c.l / ref.w) * p.w, r: (c.r / ref.w) * p.w, t: (c.t / ref.h) * p.h, b: (c.b / ref.h) * p.h } })),
      };
    });
  const resetCrop = () => setDoc((s) => ({ ...s, pages: s.pages.map((p, i) => (i === activePage ? { ...p, crop: { ...NOCROP } } : p)) }));

  const extract = async () => {
    const idx = parsePageRange(range || "1", doc.pages.length);
    if (!idx.length) return ws.toast("Enter valid page numbers, e.g. 1-3,5", "error");
    setBusy(true);
    try {
      const bytes = await ws.exportPdf(idx);
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      const fn = `${baseName(ws.name)}-pages.pdf`;
      downloadBlob(blob, fn);
      saveToHistory(fn, "Split / Extract Pages", { blob });
      ws.toast(`Extracted ${idx.length} page(s).`, "ok");
    } catch (e) {
      ws.toast("Extract failed: " + (e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };

  const pct = (key: "l" | "t" | "r" | "b") => {
    if (!cur) return 0;
    const base = key === "l" || key === "r" ? cur.w : cur.h;
    return Math.round((cur.crop[key] / base) * 100);
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between border-b border-white/10 px-3 py-2.5">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Combine className="h-4 w-4 text-[#ff7a3d]" /> Pages · Merge · Crop
        </div>
        <button onClick={onClose} className="rounded p-1 text-zinc-400 hover:bg-white/10" aria-label="Close panel">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-3">
        <div className="grid grid-cols-2 gap-2">
          <button className="btn-primary !px-2 !py-2 text-xs" onClick={() => fileRef.current?.click()}>
            <FilePlus2 className="h-4 w-4" /> Merge files
          </button>
          <button className="btn-ghost !px-2 !py-2 text-xs" onClick={() => add(A4.w, A4.h)}>
            + Blank A4
          </button>
          <button className="btn-ghost !px-2 !py-2 text-xs" onClick={() => add(LETTER.w, LETTER.h)}>
            + Letter
          </button>
          <button className="btn-ghost !px-2 !py-2 text-xs" onClick={() => add(A4.h, A4.w)}>
            + Landscape
          </button>
          <input ref={fileRef} type="file" multiple hidden accept=".pdf,image/*" onChange={(e) => { const f = Array.from(e.target.files || []); e.target.value = ""; ws.openFiles(f, { append: true }); }} />
        </div>

        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <div className="mb-2 flex items-center justify-between text-xs font-semibold text-zinc-300">
            <span className="flex items-center gap-1.5"><Crop className="h-3.5 w-3.5 text-[#ff7a3d]" /> Crop page {activePage + 1}</span>
            <button onClick={resetCrop} className="text-[11px] font-normal text-zinc-400 hover:text-white">Reset</button>
          </div>
          {(["t", "b", "l", "r"] as const).map((k) => (
            <label key={k} className="mb-1.5 flex items-center gap-2 text-[11px] text-zinc-400">
              <span className="w-12">{{ t: "Top", b: "Bottom", l: "Left", r: "Right" }[k]}</span>
              <input type="range" min={0} max={45} value={pct(k)} onChange={(e) => setCrop(k, +e.target.value)} className="flex-1 accent-[#ff4a00]" />
              <span className="w-8 text-right tabular-nums">{pct(k)}%</span>
            </label>
          ))}
          <button className="btn-ghost mt-1 w-full !py-1.5 text-xs" onClick={cropAll}>Apply same crop to all pages</button>
        </div>

        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <div className="mb-2 text-xs font-semibold text-zinc-300">Extract / split pages</div>
          <div className="flex gap-2">
            <input className="field !py-1.5 text-xs" placeholder="e.g. 1-3,5" value={range} onChange={(e) => setRange(e.target.value)} />
            <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={extract} disabled={busy}>
              {busy ? <Spinner /> : <Download className="h-4 w-4" />} PDF
            </button>
          </div>
        </div>

        <div className="space-y-1.5">
          {doc.pages.map((p, i) => (
            <div key={p.id} className={`flex items-center gap-2 rounded-lg border p-1.5 ${i === activePage ? "border-[#ff4a00]/60 bg-[#ff4a00]/10" : "border-white/10 bg-white/[0.02]"}`}>
              <button onClick={() => onGoto(i)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                <PageThumb meta={p} source={p.srcId ? sources[p.srcId] : undefined} />
                <span className="min-w-0 text-xs text-zinc-300">
                  <b className="text-white">Page {i + 1}</b>
                  <br />
                  <span className="block truncate text-[10px] text-zinc-500">{p.srcId ? sources[p.srcId]?.name : p.bg ? "Image" : "Blank"}</span>
                </span>
              </button>
              <div className="flex shrink-0 flex-col gap-0.5 sm:flex-row">
                <button className="rounded p-1.5 text-zinc-400 hover:bg-white/10 hover:text-white" onClick={() => move(i, -1)} aria-label="Move up"><ArrowUp className="h-3.5 w-3.5" /></button>
                <button className="rounded p-1.5 text-zinc-400 hover:bg-white/10 hover:text-white" onClick={() => move(i, 1)} aria-label="Move down"><ArrowDown className="h-3.5 w-3.5" /></button>
                <button className="rounded p-1.5 text-zinc-400 hover:bg-white/10 hover:text-white" onClick={() => dup(i)} aria-label="Duplicate"><Copy className="h-3.5 w-3.5" /></button>
                <button className="rounded p-1.5 text-red-400 hover:bg-red-500/15" onClick={() => remove(i)} aria-label="Delete page"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const ICONS = { text: Type, note: Type, image: ImageIcon, logo: ImageIcon, signature: PenLine, qr: QrCode, highlight: Square, redact: RectangleHorizontal, link: Link2 } as const;

export function LayersPanel({ selectedId, onSelect, onClose }: { selectedId: string | null; onSelect: (id: string, pageIndex: number) => void; onClose: () => void }) {
  const { doc, setDoc } = useWS();
  const reversed = [...doc.layers].reverse();
  const pageIdx = (id: string) => doc.pages.findIndex((p) => p.id === id);
  const reorder = (id: string, d: number) =>
    setDoc((s) => {
      const i = s.layers.findIndex((l) => l.id === id);
      const j = i + d;
      if (i < 0 || j < 0 || j >= s.layers.length) return s;
      const layers = [...s.layers];
      [layers[i], layers[j]] = [layers[j], layers[i]];
      return { ...s, layers };
    });
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between border-b border-white/10 px-3 py-2.5">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <LayersIcon className="h-4 w-4 text-[#ff7a3d]" /> Layers <span className="text-xs font-normal text-zinc-500">({doc.layers.length})</span>
        </div>
        <button onClick={onClose} className="rounded p-1 text-zinc-400 hover:bg-white/10" aria-label="Close panel">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto p-3">
        {reversed.length === 0 && <p className="py-8 text-center text-xs text-zinc-500">No layers yet. Add text, images, signatures, QR codes, highlights or redactions – they all appear here.</p>}
        {reversed.map((l) => {
          const Icon = ICONS[l.kind] || Type;
          return (
            <div key={l.id} className={`flex items-center gap-1.5 rounded-lg border p-1.5 ${selectedId === l.id ? "border-[#ff4a00]/60 bg-[#ff4a00]/10" : "border-white/10 bg-white/[0.02]"} ${l.hidden ? "opacity-50" : ""}`}>
              <button className="flex min-w-0 flex-1 items-center gap-2 text-left" onClick={() => onSelect(l.id, pageIdx(l.pageId))}>
                {l.type === "image" && l.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={l.src} alt="" className="h-8 w-8 shrink-0 rounded bg-white object-contain" />
                ) : (
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded bg-white/10"><Icon className="h-4 w-4 text-zinc-300" /></span>
                )}
                <span className="min-w-0 text-xs">
                  <span className="block truncate text-zinc-200">{l.type === "text" ? l.text?.slice(0, 28) || "Empty text" : l.type === "link" ? l.url : l.kind}</span>
                  <span className="text-[10px] text-zinc-500">Page {pageIdx(l.pageId) + 1} · {l.kind}</span>
                </span>
              </button>
              <button className="rounded p-1.5 text-zinc-400 hover:bg-white/10" onClick={() => setDoc((s) => ({ ...s, layers: s.layers.map((x) => (x.id === l.id ? { ...x, hidden: !x.hidden } : x)) }))} aria-label="Toggle visibility">
                {l.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
              <button className="rounded p-1.5 text-zinc-400 hover:bg-white/10" onClick={() => reorder(l.id, 1)} aria-label="Bring forward"><ArrowUp className="h-3.5 w-3.5" /></button>
              <button className="rounded p-1.5 text-zinc-400 hover:bg-white/10" onClick={() => reorder(l.id, -1)} aria-label="Send backward"><ArrowDown className="h-3.5 w-3.5" /></button>
              <button className="rounded p-1.5 text-red-400 hover:bg-red-500/15" onClick={() => setDoc((s) => ({ ...s, layers: s.layers.filter((x) => x.id !== l.id) }))} aria-label="Delete layer"><Trash2 className="h-3.5 w-3.5" /></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
