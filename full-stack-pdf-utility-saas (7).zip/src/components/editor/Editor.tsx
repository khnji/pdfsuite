"use client";
import {
  AlignCenter, AlignLeft, AlignRight, Bold, ChevronDown, ChevronUp, Combine, Copy, EyeOff, FilePlus, FileText, FileUp, Highlighter, ImagePlus, Italic, Layers as LayersIcon,
  Link2, Minus, MousePointer2, PenLine, Plus, QrCode, Redo2, Save, ScanLine, StickyNote, Trash2, Type, Undo2, Maximize2, X, ArrowUpToLine, ArrowDownToLine, RotateCw,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { baseName, fileToImage } from "@/lib/docOps";
import { downloadBlob, saveToHistory } from "@/lib/history";
import { uid, type FontFamily, type Layer, type TextEdit } from "@/lib/types";
import { useAuth } from "../AuthProvider";
import { Modal, Spinner } from "../ui";
import { useWS } from "../Workspace";
import { QrModal, SignatureModal } from "./InsertModals";
import { LayersPanel, PagesPanel } from "./Panels";
import PageView, { type Tool } from "./PageView";
import SheetEditor from "./SheetEditor";

const NONE: Layer[] = [];
const ACCEPT = ".pdf,.docx,.txt,.md,.xlsx,.xls,.csv,.epub,.html,.rtf,image/*";
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export default function Editor() {
  const ws = useWS();
  const { gate, premium } = useAuth();
  const { doc, setDoc, sources, hasDoc, sheet } = ws;

  const [zoom, setZoom] = useState(1);
  const [tool, setTool] = useState<Tool>("select");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [autoEditId, setAutoEditId] = useState<string | null>(null);
  const [activePage, setActivePage] = useState(0);
  const [showSig, setShowSig] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [linkDraft, setLinkDraft] = useState<{ pageId: string; rect: { x: number; y: number; w: number; h: number } } | null>(null);
  const [linkUrl, setLinkUrl] = useState("https://");
  const [dragging, setDragging] = useState(false);
  const [saving, setSaving] = useState(false);

  const scroller = useRef<HTMLDivElement>(null);
  const ratios = useRef<Record<number, number>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLInputElement>(null);
  const docRef = useRef(doc);
  docRef.current = doc;
  const activeRef = useRef(0);
  activeRef.current = activePage;
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;

  const byPage = useMemo(() => {
    const m: Record<string, Layer[]> = {};
    for (const l of doc.layers) (m[l.pageId] ||= []).push(l);
    return m;
  }, [doc.layers]);

  const sel = selectedId ? doc.layers.find((l) => l.id === selectedId) : undefined;

  /* ---------- layer helpers ---------- */
  const addLayer = useCallback(
    (p: Partial<Layer> & Pick<Layer, "pageId" | "type" | "kind" | "x" | "y" | "w" | "h">) => {
      const id = uid();
      setDoc((d) => ({ ...d, layers: [...d.layers, { rot: 0, ...p, id } as Layer] }));
      setSelectedId(id);
      return id;
    },
    [setDoc]
  );
  const patchLayer = useCallback(
    (id: string, patch: Partial<Layer>) => setDoc((d) => ({ ...d, layers: d.layers.map((l) => (l.id === id ? { ...l, ...patch } : l)) })),
    [setDoc]
  );
  const removeLayer = useCallback(
    (id: string) => {
      setDoc((d) => ({ ...d, layers: d.layers.filter((l) => l.id !== id) }));
      setSelectedId((s) => (s === id ? null : s));
    },
    [setDoc]
  );
  const onTextEdit = useCallback(
    (pageId: string, i: number, edit: TextEdit | null) =>
      setDoc((d) => {
        const edits = { ...d.edits };
        if (edit) edits[`${pageId}:${i}`] = edit;
        else delete edits[`${pageId}:${i}`];
        return { ...d, edits };
      }),
    [setDoc]
  );
  const onActive = useCallback((i: number, r: number) => {
    ratios.current[i] = r;
    let best = -1;
    let bv = 0;
    for (const k in ratios.current) {
      if (ratios.current[k] > bv) {
        bv = ratios.current[k];
        best = +k;
      }
    }
    if (best >= 0) setActivePage((p) => (p === best ? p : best));
  }, []);
  const onAutoEditDone = useCallback(() => setAutoEditId(null), []);

  const viewTarget = (w: number, h: number) => {
    const d = docRef.current;
    const idx = Math.min(activeRef.current, d.pages.length - 1);
    const page = d.pages[Math.max(0, idx)];
    let cy = page.h / 2;
    const el = document.getElementById("page-" + idx);
    const sc = scroller.current;
    if (el && sc) {
      const er = el.getBoundingClientRect();
      const sr = sc.getBoundingClientRect();
      cy = clamp((sr.top + sr.height / 2 - er.top) / zoomRef.current + page.crop.t, h / 2 + 4, page.h - h / 2 - 4);
    }
    return { pageId: page.id, x: Math.max(0, (page.w - w) / 2), y: Math.max(0, cy - h / 2) };
  };

  const insertImage = async (file: File) => {
    try {
      const im = await fileToImage(file);
      const page = docRef.current.pages[Math.min(activeRef.current, docRef.current.pages.length - 1)];
      const w = Math.min(220, page.w * 0.45);
      const h = (w * im.h) / im.w;
      const t = viewTarget(w, h);
      addLayer({ pageId: t.pageId, type: "image", kind: "image", x: t.x, y: t.y, w, h, src: im.src });
    } catch (e) {
      ws.toast((e as Error).message, "error");
    }
  };
  const insertDataImage = (src: string, kind: "signature" | "qr", w0: number, ratio: number) => {
    const w = w0;
    const h = w * ratio;
    const t = viewTarget(w, h);
    addLayer({ pageId: t.pageId, type: "image", kind, x: t.x, y: t.y, w, h, src });
  };

  const onDraw = useCallback(
    (pageId: string, t: Tool, r: { x: number; y: number; w: number; h: number }) => {
      setTool("select");
      if (t === "text" || t === "note") {
        const note = t === "note";
        const w = r.w > 40 ? r.w : note ? 170 : 220;
        const h = r.h > 18 ? r.h : note ? 90 : 30;
        const id = addLayer({
          pageId, type: "text", kind: note ? "note" : "text", x: r.x, y: r.y, w, h, text: "", fs: note ? 12 : 16,
          color: "#111111", font: "sans", align: "left", bg: note ? "#fff3a3" : undefined,
        });
        setAutoEditId(id);
      } else if (t === "highlight") {
        const big = r.w > 6 && r.h > 4;
        addLayer({ pageId, type: "shape", kind: "highlight", x: r.x, y: r.y, w: big ? r.w : 120, h: big ? r.h : 16, fill: "#fde047", opacity: 0.4 });
      } else if (t === "redact") {
        const big = r.w > 6 && r.h > 4;
        addLayer({ pageId, type: "redact", kind: "redact", x: r.x, y: r.y, w: big ? r.w : 100, h: big ? r.h : 20 });
      } else if (t === "link") {
        const big = r.w > 6 && r.h > 4;
        setLinkUrl("https://");
        setLinkDraft({ pageId, rect: { x: r.x, y: r.y, w: big ? r.w : 120, h: big ? r.h : 24 } });
      }
    },
    [addLayer]
  );

  const pickTool = (t: Tool, feature?: string) => {
    if (feature && !gate(feature)) return;
    setTool((c) => (c === t ? "select" : t));
    setSelectedId(null);
  };

  /* ---------- zoom / fit ---------- */
  const fit = useCallback(() => {
    const sc = scroller.current;
    const d = docRef.current;
    if (!sc || !d.pages.length) return;
    const maxW = Math.max(...d.pages.map((p) => p.w - p.crop.l - p.crop.r));
    setZoom(clamp((sc.clientWidth - (sc.clientWidth < 640 ? 24 : 64)) / maxW, 0.25, 1.6));
  }, []);
  useEffect(() => {
    if (!hasDoc || sheet) return;
    const t = setTimeout(fit, 60);
    return () => clearTimeout(t);
  }, [ws.docId, hasDoc, sheet, fit]);
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const h = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      setZoom((z) => clamp(z * (e.deltaY < 0 ? 1.08 : 0.92), 0.25, 4));
    };
    el.addEventListener("wheel", h, { passive: false });
    return () => el.removeEventListener("wheel", h);
  }, [hasDoc, sheet]);

  useEffect(() => {
    if (!ws.jump) return;
    document.getElementById("page-" + ws.jump.page)?.scrollIntoView({ block: "start", behavior: "smooth" });
  }, [ws.jump]);

  const gotoPage = (i: number) => {
    const n = clamp(i, 0, doc.pages.length - 1);
    document.getElementById("page-" + n)?.scrollIntoView({ block: "start", behavior: "smooth" });
  };

  /* ---------- keyboard ---------- */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      const typing = !!t.closest?.('input,textarea,select,[contenteditable="true"]');
      const mod = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();
      if (mod && !typing && (k === "z" || k === "y")) {
        e.preventDefault();
        if (k === "y" || e.shiftKey) ws.redo();
        else ws.undo();
        return;
      }
      if (typing) return;
      if (e.key === "Escape") {
        setTool("select");
        setSelectedId(null);
        return;
      }
      if (!sel) return;
      if (e.key === "Delete" || e.key === "Backspace") {
        e.preventDefault();
        removeLayer(sel.id);
      } else if (e.key.startsWith("Arrow")) {
        e.preventDefault();
        const s = e.shiftKey ? 10 : 1;
        patchLayer(sel.id, {
          x: sel.x + (e.key === "ArrowRight" ? s : e.key === "ArrowLeft" ? -s : 0),
          y: sel.y + (e.key === "ArrowDown" ? s : e.key === "ArrowUp" ? -s : 0),
        });
      } else if (mod && k === "d") {
        e.preventDefault();
        duplicate();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel, ws.undo, ws.redo, removeLayer, patchLayer]);

  const duplicate = () => {
    if (!sel) return;
    const id = uid();
    setDoc((d) => ({ ...d, layers: [...d.layers, { ...sel, id, x: sel.x + 14, y: sel.y + 14 }] }));
    setSelectedId(id);
  };
  const reorder = (d: number) => {
    if (!sel) return;
    setDoc((s) => {
      const i = s.layers.findIndex((l) => l.id === sel.id);
      const j = d > 0 ? s.layers.length - 1 : 0;
      if (i < 0 || i === j) return s;
      const layers = s.layers.filter((l) => l.id !== sel.id);
      layers.splice(j, 0, sel);
      return { ...s, layers };
    });
  };

  /* ---------- save ---------- */
  const savePdf = async () => {
    setSaving(true);
    try {
      const bytes = await ws.exportPdf();
      const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
      const fn = `${baseName(ws.name)}${ws.dirty && !sheet ? "-edited" : ""}.pdf`;
      downloadBlob(blob, fn);
      await saveToHistory(fn, sheet ? "Sheet → PDF" : "PDF Editor", { blob });
      ws.markSaved();
      ws.toast(`Saved ${fn} – also added to Recent Work.`, "ok");
    } catch (e) {
      ws.toast("Could not create the PDF: " + ((e as Error).message || "unknown error"), "error");
    } finally {
      setSaving(false);
    }
  };

  /* ---------- drop ---------- */
  const onDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const files = Array.from(e.dataTransfer.files || []);
    if (!files.length) return;
    if (hasDoc && !sheet && files.every((f) => f.type.startsWith("image/"))) {
      for (const f of files) await insertImage(f);
      return;
    }
    await ws.openFiles(files);
  };
  const chooseFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = Array.from(e.target.files || []);
    e.target.value = "";
    ws.openFiles(f);
  };

  const openPanel = (p: "pages" | "layers") => {
    if (p === "pages" && ws.panel !== "pages" && !gate("Merge & Crop PDF")) return;
    ws.setPanel(ws.panel === p ? null : p);
  };

  const rootProps = {
    onDragOver: (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(true);
    },
    onDragLeave: (e: React.DragEvent) => {
      if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setDragging(false);
    },
    onDrop,
  };

  /* ---------- empty state ---------- */
  if (!hasDoc) {
    return (
      <div className="relative h-full overflow-y-auto p-4 sm:p-8" {...rootProps}>
        <div
          className={`mx-auto flex min-h-[420px] max-w-3xl flex-col items-center justify-center rounded-3xl border-2 border-dashed p-6 text-center transition sm:p-10 ${dragging ? "border-[#ff4a00] bg-[#ff4a00]/10" : "border-white/15 bg-white/[0.02]"}`}
        >
          <div className="mb-5 grid h-20 w-20 place-items-center rounded-2xl bg-gradient-to-br from-[#ff4a00] to-[#ff9a1a] shadow-[0_10px_40px_rgba(255,74,0,0.35)]">
            <FileUp className="h-9 w-9 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white">Drop your document here</h2>
          <p className="mt-2 max-w-md text-sm text-zinc-400">
            PDF, DOCX, TXT, Excel (.xlsx / .xls), CSV, EPUB and images. Everything is processed privately in your browser – nothing is uploaded.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button className="btn-primary" onClick={() => fileRef.current?.click()}>
              <FileUp className="h-4 w-4" /> Choose files
            </button>
            <button className="btn-ghost" onClick={ws.newBlank}>
              <FilePlus className="h-4 w-4" /> Blank document
            </button>
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-2 text-[11px] text-zinc-400">
            {["PDF", "DOCX", "TXT", "XLSX", "XLS", "CSV", "EPUB", "PNG", "JPG", "WEBP"].map((x) => (
              <span key={x} className="rounded-full border border-white/10 px-2.5 py-1">
                {x}
              </span>
            ))}
          </div>
          <p className="mt-5 max-w-lg text-xs text-zinc-500">Tip: select several PDFs or images at once to merge them into a single document.</p>
        </div>
        <input ref={fileRef} type="file" hidden multiple accept={ACCEPT} onChange={chooseFiles} />
      </div>
    );
  }

  if (sheet) {
    return (
      <div className="h-full" {...rootProps}>
        <SheetEditor onSave={savePdf} saving={saving} />
      </div>
    );
  }

  const fsVal = Math.round(sel?.fs || 16);

  return (
    <div className="relative flex h-full min-h-0 flex-col" {...rootProps}>
      {/* ===== fixed toolbar (never scrolls) ===== */}
      <div
        className="shrink-0 border-b border-white/10 bg-[#0d1017]"
        onMouseDown={(e) => {
          if (!(e.target as HTMLElement).closest("input,select,textarea")) e.preventDefault();
        }}
      >
        <div className="flex items-center gap-0.5 overflow-x-auto px-2 py-1.5">
          <button className="tb-btn" onClick={() => fileRef.current?.click()} title="Open file"><FileUp className="h-4 w-4" /> <span className="hidden lg:inline">Open</span></button>
          <button className="tb-btn" onClick={ws.newBlank} title="New blank document"><FilePlus className="h-4 w-4" /> <span className="hidden lg:inline">New</span></button>
          <button className="btn-primary !px-3 !py-1.5 !text-xs" onClick={savePdf} disabled={saving} title="Download PDF">
            {saving ? <Spinner /> : <Save className="h-4 w-4" />} Save PDF
          </button>
          <Sep />
          <button className="tb-btn" onClick={ws.undo} disabled={!ws.canUndo} title="Undo (Ctrl+Z)"><Undo2 className="h-4 w-4" /></button>
          <button className="tb-btn" onClick={ws.redo} disabled={!ws.canRedo} title="Redo (Ctrl+Y)"><Redo2 className="h-4 w-4" /></button>
          <Sep />
          <button className={`tb-btn ${tool === "select" ? "active" : ""}`} onClick={() => setTool("select")} title="Select / edit text"><MousePointer2 className="h-4 w-4" /> <span className="hidden xl:inline">Select</span></button>
          <button className={`tb-btn ${tool === "text" ? "active" : ""}`} onClick={() => pickTool("text")} title="Add text box"><Type className="h-4 w-4" /> <span className="hidden xl:inline">Text</span></button>
          <button className={`tb-btn ${tool === "note" ? "active" : ""}`} onClick={() => pickTool("note")} title="Add note"><StickyNote className="h-4 w-4" /> <span className="hidden xl:inline">Note</span></button>
          <button className={`tb-btn ${tool === "highlight" ? "active" : ""}`} onClick={() => pickTool("highlight")} title="Highlight"><Highlighter className="h-4 w-4" /> <span className="hidden xl:inline">Highlight</span></button>
          <button className={`tb-btn ${tool === "redact" ? "active" : ""}`} onClick={() => pickTool("redact", "Redaction")} title="Redact (black out)"><EyeOff className="h-4 w-4" /> <span className="hidden xl:inline">Redact</span></button>
          <button className={`tb-btn ${tool === "link" ? "active" : ""}`} onClick={() => pickTool("link", "Link boxes")} title="Add link area"><Link2 className="h-4 w-4" /> <span className="hidden xl:inline">Link</span></button>
          <Sep />
          <button className="tb-btn" onClick={() => imgRef.current?.click()} title="Insert image / logo"><ImagePlus className="h-4 w-4" /> <span className="hidden xl:inline">Image</span></button>
          <button className="tb-btn" onClick={() => gate("Digital Signature") && setShowSig(true)} title="Sign"><PenLine className="h-4 w-4" /> <span className="hidden xl:inline">Sign</span></button>
          <button className="tb-btn" onClick={() => setShowQr(true)} title="Insert QR code"><QrCode className="h-4 w-4" /> <span className="hidden xl:inline">QR</span></button>
          <Sep />
          <button className="tb-btn" onClick={() => setZoom((z) => clamp(z / 1.15, 0.25, 4))} title="Zoom out"><Minus className="h-4 w-4" /></button>
          <span className="w-11 shrink-0 text-center text-xs tabular-nums text-zinc-400">{Math.round(zoom * 100)}%</span>
          <button className="tb-btn" onClick={() => setZoom((z) => clamp(z * 1.15, 0.25, 4))} title="Zoom in"><Plus className="h-4 w-4" /></button>
          <button className="tb-btn" onClick={fit} title="Fit to width"><Maximize2 className="h-4 w-4" /></button>
          <Sep />
          <button className={`tb-btn ${ws.panel === "pages" ? "active" : ""}`} onClick={() => openPanel("pages")} title="Pages, merge & crop"><Combine className="h-4 w-4" /> <span className="hidden lg:inline">Pages</span></button>
          <button className={`tb-btn ${ws.panel === "layers" ? "active" : ""}`} onClick={() => openPanel("layers")} title="Layers"><LayersIcon className="h-4 w-4" /> <span className="hidden lg:inline">Layers</span></button>
          <Sep />
          <button className="tb-btn" onClick={() => gotoPage(activePage - 1)} disabled={activePage <= 0}><ChevronUp className="h-4 w-4" /></button>
          <span className="shrink-0 text-xs tabular-nums text-zinc-400">{activePage + 1} / {doc.pages.length}</span>
          <button className="tb-btn" onClick={() => gotoPage(activePage + 1)} disabled={activePage >= doc.pages.length - 1}><ChevronDown className="h-4 w-4" /></button>
          <button className="tb-btn ml-auto text-zinc-500" onClick={ws.closeDoc} title="Close document"><X className="h-4 w-4" /></button>
        </div>

        {/* context bar – always visible, never scrolls with the page */}
        <div className="flex min-h-[44px] items-center gap-1 overflow-x-auto border-t border-white/5 bg-[#0a0d13] px-2 py-1">
          {tool !== "select" && !sel && (
            <span className="flex items-center gap-2 px-2 text-xs text-[#ff9a5a]">
              <ScanLine className="h-4 w-4" />
              {tool === "text" || tool === "note" ? "Click on the page where you want to type (or drag to size the box)." : tool === "link" ? "Drag a rectangle to create a link area." : "Drag a rectangle on the page."}
              <button className="underline" onClick={() => setTool("select")}>Cancel</button>
            </span>
          )}
          {tool === "select" && !sel && (
            <span className="flex items-center gap-2 px-2 text-xs text-zinc-500">
              <FileText className="h-4 w-4" /> Click any text to edit it in place · add Text, Images, QR or Signatures, then drag, scale and rotate them.
            </span>
          )}
          {sel && (
            <>
              {sel.type === "text" && (
                <>
                  <select className="h-8 shrink-0 rounded-lg border border-white/10 bg-[#141821] px-2 text-xs text-zinc-200" value={sel.font || "sans"} onChange={(e) => patchLayer(sel.id, { font: e.target.value as FontFamily })}>
                    <option value="sans">Sans</option>
                    <option value="serif">Serif</option>
                    <option value="mono">Mono</option>
                  </select>
                  <button className="tb-btn !px-2" onClick={() => patchLayer(sel.id, { fs: Math.max(4, fsVal - 1) })}><Minus className="h-3.5 w-3.5" /></button>
                  <input type="number" className="h-8 w-14 shrink-0 rounded-lg border border-white/10 bg-[#141821] px-2 text-center text-xs text-zinc-200" value={fsVal} min={4} max={300} onChange={(e) => patchLayer(sel.id, { fs: clamp(+e.target.value || 12, 4, 300) })} />
                  <button className="tb-btn !px-2" onClick={() => patchLayer(sel.id, { fs: Math.min(300, fsVal + 1) })}><Plus className="h-3.5 w-3.5" /></button>
                  <button className={`tb-btn !px-2 ${sel.bold ? "active" : ""}`} onClick={() => patchLayer(sel.id, { bold: !sel.bold })}><Bold className="h-4 w-4" /></button>
                  <button className={`tb-btn !px-2 ${sel.italic ? "active" : ""}`} onClick={() => patchLayer(sel.id, { italic: !sel.italic })}><Italic className="h-4 w-4" /></button>
                  <button className={`tb-btn !px-2 ${(sel.align || "left") === "left" ? "active" : ""}`} onClick={() => patchLayer(sel.id, { align: "left" })}><AlignLeft className="h-4 w-4" /></button>
                  <button className={`tb-btn !px-2 ${sel.align === "center" ? "active" : ""}`} onClick={() => patchLayer(sel.id, { align: "center" })}><AlignCenter className="h-4 w-4" /></button>
                  <button className={`tb-btn !px-2 ${sel.align === "right" ? "active" : ""}`} onClick={() => patchLayer(sel.id, { align: "right" })}><AlignRight className="h-4 w-4" /></button>
                  <label className="flex shrink-0 items-center gap-1 text-[11px] text-zinc-500">Text <input type="color" className="h-7 w-8 rounded bg-transparent" value={sel.color || "#111111"} onChange={(e) => patchLayer(sel.id, { color: e.target.value })} /></label>
                  <label className="flex shrink-0 items-center gap-1 text-[11px] text-zinc-500">Fill
                    <input type="color" className="h-7 w-8 rounded bg-transparent" value={sel.bg || "#ffffff"} onChange={(e) => patchLayer(sel.id, { bg: e.target.value })} />
                    {sel.bg && <button className="text-[10px] text-zinc-400 underline" onClick={() => patchLayer(sel.id, { bg: undefined })}>none</button>}
                  </label>
                </>
              )}
              {(sel.type === "image" || sel.type === "shape" || sel.type === "text") && (
                <label className="flex shrink-0 items-center gap-1 text-[11px] text-zinc-500">Opacity
                  <input type="range" min={10} max={100} value={Math.round((sel.opacity ?? (sel.type === "shape" ? 0.4 : 1)) * 100)} onChange={(e) => patchLayer(sel.id, { opacity: +e.target.value / 100 })} className="w-20 accent-[#ff4a00]" />
                </label>
              )}
              {sel.type === "shape" && <input type="color" className="h-7 w-8 shrink-0 rounded bg-transparent" value={sel.fill || "#fde047"} onChange={(e) => patchLayer(sel.id, { fill: e.target.value })} />}
              {sel.type === "link" && <input className="h-8 w-56 shrink-0 rounded-lg border border-white/10 bg-[#141821] px-2 text-xs text-zinc-200" value={sel.url || ""} onChange={(e) => patchLayer(sel.id, { url: e.target.value })} placeholder="https://…" />}
              <Sep />
              <button className="tb-btn !px-2" title="Rotate −90°" onClick={() => patchLayer(sel.id, { rot: (((sel.rot - 90) % 360) + 360) % 360 })}><RotateCw className="h-4 w-4 -scale-x-100" /></button>
              <input type="number" className="h-8 w-16 shrink-0 rounded-lg border border-white/10 bg-[#141821] px-2 text-center text-xs text-zinc-200" value={Math.round(sel.rot)} onChange={(e) => patchLayer(sel.id, { rot: (((+e.target.value || 0) % 360) + 360) % 360 })} title="Rotation (degrees)" />
              <button className="tb-btn !px-2" title="Rotate +90°" onClick={() => patchLayer(sel.id, { rot: (sel.rot + 90) % 360 })}><RotateCw className="h-4 w-4" /></button>
              <Sep />
              <button className="tb-btn !px-2" title="Bring to front" onClick={() => reorder(1)}><ArrowUpToLine className="h-4 w-4" /></button>
              <button className="tb-btn !px-2" title="Send to back" onClick={() => reorder(-1)}><ArrowDownToLine className="h-4 w-4" /></button>
              <button className="tb-btn !px-2" title="Duplicate" onClick={duplicate}><Copy className="h-4 w-4" /></button>
              <button className="tb-btn !px-2 text-red-400" title="Delete" onClick={() => removeLayer(sel.id)}><Trash2 className="h-4 w-4" /></button>
            </>
          )}
        </div>
      </div>

      {/* ===== canvas + side panel ===== */}
      <div className="flex min-h-0 flex-1">
        <div ref={scroller} className="min-w-0 flex-1 overflow-auto overscroll-contain bg-[#07090d] px-2 pb-24 pt-10 sm:px-6" style={{ WebkitOverflowScrolling: "touch" }}>
          <div className="flex w-max min-w-full flex-col items-center">
            {doc.pages.map((p, i) => (
              <PageView
                key={p.id}
                meta={p}
                index={i}
                zoom={zoom}
                source={p.srcId ? sources[p.srcId] : undefined}
                layers={byPage[p.id] || NONE}
                edits={doc.edits}
                tool={tool}
                selectedId={selectedId}
                autoEditId={autoEditId}
                onSelect={setSelectedId}
                onLayerCommit={patchLayer}
                onLayerDelete={removeLayer}
                onAutoEditDone={onAutoEditDone}
                onTextEdit={onTextEdit}
                onDraw={onDraw}
                onActive={onActive}
              />
            ))}
          </div>
        </div>
        {ws.panel && (
          <aside className="fixed inset-x-0 bottom-0 z-40 h-[58dvh] rounded-t-2xl border-t border-white/15 bg-[#0d1017] shadow-[0_-20px_60px_rgba(0,0,0,0.6)] md:static md:z-auto md:h-auto md:w-80 md:shrink-0 md:rounded-none md:border-l md:border-t-0 md:shadow-none">
            {ws.panel === "pages" ? (
              <PagesPanel activePage={activePage} onGoto={gotoPage} onClose={() => ws.setPanel(null)} />
            ) : (
              <LayersPanel
                selectedId={selectedId}
                onSelect={(id, pi) => {
                  setSelectedId(id);
                  if (pi >= 0) gotoPage(pi);
                }}
                onClose={() => ws.setPanel(null)}
              />
            )}
          </aside>
        )}
      </div>

      {dragging && (
        <div className="pointer-events-none absolute inset-0 z-[70] grid place-items-center border-4 border-dashed border-[#ff4a00] bg-black/70 text-lg font-semibold text-white">
          Drop to open · drop images to insert them into the page
        </div>
      )}

      <input ref={fileRef} type="file" hidden multiple accept={ACCEPT} onChange={chooseFiles} />
      <input
        ref={imgRef}
        type="file"
        hidden
        multiple
        accept="image/*"
        onChange={async (e) => {
          const f = Array.from(e.target.files || []);
          e.target.value = "";
          for (const x of f) await insertImage(x);
        }}
      />
      <SignatureModal open={showSig} onClose={() => setShowSig(false)} onInsert={(url, w, h) => insertDataImage(url, "signature", Math.min(180, w), h / w)} />
      <QrModal open={showQr} onClose={() => setShowQr(false)} onInsert={(url) => insertDataImage(url, "qr", 110, 1)} />
      <Modal open={!!linkDraft} onClose={() => setLinkDraft(null)} title="Link target">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!linkDraft) return;
            const url = /^(https?:|mailto:|tel:)/i.test(linkUrl.trim()) ? linkUrl.trim() : "https://" + linkUrl.trim();
            addLayer({ pageId: linkDraft.pageId, type: "link", kind: "link", ...linkDraft.rect, url });
            setLinkDraft(null);
          }}
          className="space-y-3"
        >
          <input className="field" autoFocus placeholder="https://example.com" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} />
          <button className="btn-primary w-full">Add link area</button>
        </form>
      </Modal>
      {!premium && <span className="sr-only">Free basic mode</span>}
    </div>
  );
}

function Sep() {
  return <span className="mx-1 h-5 w-px shrink-0 bg-white/10" />;
}
