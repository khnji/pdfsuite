"use client";
import { Eraser, PenLine, QrCode, Type } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { qrToCanvas } from "@/lib/qr";
import { Modal, Spinner } from "../ui";

const SIG_COLORS = ["#111111", "#1d4ed8", "#dc2626", "#047857"];
const CURSIVE = "'Brush Script MT','Segoe Script','Snell Roundhand','Lucida Handwriting',cursive";

export function SignatureModal({ open, onClose, onInsert }: { open: boolean; onClose: () => void; onInsert: (url: string, w: number, h: number) => void }) {
  const [mode, setMode] = useState<"draw" | "type">("draw");
  const [color, setColor] = useState(SIG_COLORS[0]);
  const [width, setWidth] = useState(3);
  const [text, setText] = useState("");
  const [empty, setEmpty] = useState(true);
  const cv = useRef<HTMLCanvasElement>(null);
  const last = useRef<{ x: number; y: number } | null>(null);

  const clear = useCallback(() => {
    const c = cv.current;
    if (!c) return;
    c.getContext("2d")!.clearRect(0, 0, c.width, c.height);
    setEmpty(true);
  }, []);

  useEffect(() => {
    if (open) {
      const t = setTimeout(clear, 30);
      return () => clearTimeout(t);
    }
  }, [open, mode, clear]);

  useEffect(() => {
    if (mode !== "type") return;
    const c = cv.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, c.width, c.height);
    if (!text.trim()) return setEmpty(true);
    ctx.fillStyle = color;
    ctx.font = `italic 110px ${CURSIVE}`;
    ctx.textBaseline = "middle";
    let size = 110;
    while (ctx.measureText(text).width > c.width - 40 && size > 20) {
      size -= 6;
      ctx.font = `italic ${size}px ${CURSIVE}`;
    }
    ctx.fillText(text, 20, c.height / 2);
    setEmpty(false);
  }, [text, color, mode, open]);

  const pos = (e: React.PointerEvent) => {
    const c = cv.current!;
    const r = c.getBoundingClientRect();
    return { x: ((e.clientX - r.left) * c.width) / r.width, y: ((e.clientY - r.top) * c.height) / r.height };
  };
  const down = (e: React.PointerEvent) => {
    if (mode !== "draw") return;
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    last.current = pos(e);
    const ctx = cv.current!.getContext("2d")!;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(last.current.x, last.current.y, width * 1.2, 0, Math.PI * 2);
    ctx.fill();
    setEmpty(false);
  };
  const move = (e: React.PointerEvent) => {
    if (!last.current) return;
    const p = pos(e);
    const ctx = cv.current!.getContext("2d")!;
    ctx.strokeStyle = color;
    ctx.lineWidth = width * 2.4;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(last.current.x, last.current.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last.current = p;
  };

  const insert = () => {
    const c = cv.current!;
    const ctx = c.getContext("2d")!;
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let x0 = c.width, y0 = c.height, x1 = 0, y1 = 0;
    for (let y = 0; y < c.height; y++)
      for (let x = 0; x < c.width; x++)
        if (d[(y * c.width + x) * 4 + 3] > 10) {
          if (x < x0) x0 = x;
          if (x > x1) x1 = x;
          if (y < y0) y0 = y;
          if (y > y1) y1 = y;
        }
    if (x1 <= x0) return;
    const pad = 8;
    x0 = Math.max(0, x0 - pad);
    y0 = Math.max(0, y0 - pad);
    x1 = Math.min(c.width, x1 + pad);
    y1 = Math.min(c.height, y1 + pad);
    const o = document.createElement("canvas");
    o.width = x1 - x0;
    o.height = y1 - y0;
    o.getContext("2d")!.drawImage(c, x0, y0, o.width, o.height, 0, 0, o.width, o.height);
    onInsert(o.toDataURL("image/png"), o.width, o.height);
    setText("");
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title="Digital Signature" wide>
      <div className="mb-3 flex gap-2">
        <button className={`tb-btn ${mode === "draw" ? "active" : ""}`} onClick={() => setMode("draw")}>
          <PenLine className="h-4 w-4" /> Draw
        </button>
        <button className={`tb-btn ${mode === "type" ? "active" : ""}`} onClick={() => setMode("type")}>
          <Type className="h-4 w-4" /> Type
        </button>
      </div>
      {mode === "type" && <input className="field mb-3" placeholder="Type your name" value={text} onChange={(e) => setText(e.target.value)} />}
      <div className="overflow-hidden rounded-xl border border-white/10 bg-white" style={{ backgroundImage: "linear-gradient(#e5e7eb 1px, transparent 1px)", backgroundSize: "100% 60px", backgroundPosition: "0 170px" }}>
        <canvas
          ref={cv}
          width={900}
          height={300}
          className={`block h-auto w-full touch-none ${mode === "draw" ? "cursor-crosshair" : ""}`}
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={() => (last.current = null)}
          onPointerCancel={() => (last.current = null)}
        />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <div className="flex gap-1.5">
          {SIG_COLORS.map((c) => (
            <button key={c} onClick={() => setColor(c)} aria-label={c} className={`h-7 w-7 rounded-full border-2 ${color === c ? "border-[#ff4a00]" : "border-white/20"}`} style={{ background: c }} />
          ))}
        </div>
        {mode === "draw" && (
          <label className="flex items-center gap-2 text-xs text-zinc-400">
            Pen
            <input type="range" min={1} max={8} value={width} onChange={(e) => setWidth(+e.target.value)} className="accent-[#ff4a00]" />
          </label>
        )}
        <button className="btn-ghost ml-auto" onClick={mode === "draw" ? clear : () => setText("")}>
          <Eraser className="h-4 w-4" /> Clear
        </button>
        <button className="btn-primary" disabled={empty} onClick={insert}>
          Insert signature
        </button>
      </div>
      <p className="mt-2 text-xs text-zinc-500">After inserting you can drag, scale and rotate the signature anywhere on the page.</p>
    </Modal>
  );
}

export function QrModal({ open, onClose, onInsert }: { open: boolean; onClose: () => void; onInsert: (url: string) => void }) {
  const [text, setText] = useState("https://");
  const [fg, setFg] = useState("#000000");
  const [bg, setBg] = useState("#ffffff");
  const [preview, setPreview] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    setBusy(true);
    qrToCanvas({ text: text || " ", size: 420, fg, bg, margin: 2, ec: "M" })
      .then((c) => alive && setPreview(c.toDataURL("image/png")))
      .catch(() => alive && setPreview(""))
      .finally(() => alive && setBusy(false));
    return () => {
      alive = false;
    };
  }, [text, fg, bg, open]);

  return (
    <Modal open={open} onClose={onClose} title="Insert QR Code">
      <input className="field mb-3" placeholder="Text or URL" value={text} onChange={(e) => setText(e.target.value)} />
      <div className="mb-3 flex gap-4 text-xs text-zinc-400">
        <label className="flex items-center gap-2">
          Color <input type="color" value={fg} onChange={(e) => setFg(e.target.value)} className="h-8 w-10 rounded bg-transparent" />
        </label>
        <label className="flex items-center gap-2">
          Background <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-8 w-10 rounded bg-transparent" />
        </label>
      </div>
      <div className="mb-4 grid h-52 place-items-center rounded-xl bg-white/5">
        {busy && !preview ? <Spinner className="h-6 w-6" /> : preview ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={preview} alt="QR preview" className="h-48 w-48 rounded" /> : <span className="text-sm text-zinc-500">Could not generate</span>}
      </div>
      <button
        className="btn-primary w-full"
        disabled={!preview || !text.trim()}
        onClick={() => {
          onInsert(preview);
          onClose();
        }}
      >
        <QrCode className="h-4 w-4" /> Insert into page
      </button>
    </Modal>
  );
}
