"use client";
import { Clock, Download, FileArchive, FileCode2, FileImage, FileSpreadsheet, FileText, FolderOpen, QrCode, ScanLine, Trash2, type LucideIcon } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { clearHistory, deleteHistoryItem, downloadBlob, getHistory, getHistoryRecord, relativeTime, subscribeHistory, type HistoryItem } from "@/lib/history";
import { useWS } from "./Workspace";

function iconFor(item: HistoryItem): LucideIcon {
  const ext = (item.fileName.split(".").pop() || "").toLowerCase();
  if (item.kind === "qr" || /qr/i.test(item.toolUsed)) return QrCode;
  if (/scan/i.test(item.toolUsed)) return ScanLine;
  if (["png", "jpg", "jpeg", "webp", "gif", "svg"].includes(ext)) return FileImage;
  if (["xlsx", "xls", "csv"].includes(ext)) return FileSpreadsheet;
  if (["zip"].includes(ext)) return FileArchive;
  if (["html", "json", "md"].includes(ext)) return FileCode2;
  return FileText;
}

const fmtSize = (n?: number) => (!n ? "" : n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB");

export default function RecentWork() {
  const ws = useWS();
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [now, setNow] = useState(() => Date.now());

  const refresh = useCallback(() => setItems(getHistory()), []);
  useEffect(() => {
    refresh();
    const unsub = subscribeHistory(refresh);
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => {
      unsub();
      clearInterval(t);
    };
  }, [refresh]);

  const download = async (item: HistoryItem) => {
    const rec = await getHistoryRecord(item.id);
    if (rec?.blob) downloadBlob(rec.blob, item.fileName);
    else ws.toast("No downloadable file is stored for this entry.", "info");
  };

  return (
    <div className="mx-auto h-full max-w-4xl overflow-y-auto p-4 sm:p-6">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">Recent Work</h2>
          <p className="text-sm text-zinc-400">Your latest 10 results – saved only on this device. Click one to open it again.</p>
        </div>
        {items.length > 0 && (
          <button onClick={() => clearHistory()} className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 text-xs font-medium text-zinc-300 transition hover:border-[#ff4a00]/50 hover:bg-[#ff4a00]/10 hover:text-[#ff7a3d]">
            <Trash2 className="h-3.5 w-3.5" /> Clear History
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="card grid place-items-center px-6 py-16 text-center">
          <div className="mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-[#ff4a00]/10 text-[#ff7a3d]">
            <Clock className="h-8 w-8" />
          </div>
          <p className="max-w-sm text-sm text-zinc-400">No recent files found. Your workspace history will appear here locally.</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <ul className="divide-y divide-white/5">
            {items.map((item) => {
              const Icon = iconFor(item);
              return (
                <li key={item.id} className="group flex items-center gap-3 px-3 py-3 transition hover:bg-white/[0.03] sm:px-4">
                  <button onClick={() => ws.openFromHistory(item)} className="flex min-w-0 flex-1 items-center gap-3 text-left" title="Open again">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#ff4a00]/12 text-[#ff7a3d]" style={{ background: "rgba(255,74,0,0.12)" }}>
                      <Icon className="h-5 w-5" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium text-white">{item.fileName}</span>
                      <span className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-zinc-500">
                        <span className="rounded-full bg-[#ff4a00]/15 px-2 py-0.5 font-medium text-[#ff8a50]">{item.toolUsed}</span>
                        <span>{relativeTime(item.timestamp, now)}</span>
                        {item.size ? <span>· {fmtSize(item.size)}</span> : null}
                        <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-emerald-300">{item.status}</span>
                        {item.stored && <span className="inline-flex items-center gap-1 text-zinc-500"><FolderOpen className="h-3 w-3" /> saved locally</span>}
                      </span>
                    </span>
                  </button>
                  {item.stored && item.kind !== "qr" && (
                    <button onClick={() => download(item)} className="rounded-lg p-2 text-zinc-500 transition hover:bg-white/10 hover:text-white" aria-label="Download" title="Download">
                      <Download className="h-4 w-4" />
                    </button>
                  )}
                  <button onClick={() => deleteHistoryItem(item.id)} className="rounded-lg p-2 text-zinc-500 transition hover:bg-red-500/15 hover:text-red-400" aria-label="Remove from history" title="Remove">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
