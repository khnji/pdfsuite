"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { baseName, exportPdfBytes, extractAllText, fileExt, NOCROP, parseFile, sheetToPdfBytes } from "@/lib/docOps";
import { downloadBlob, getHistoryRecord, type HistoryItem } from "@/lib/history";
import { A4, uid, type DocState, type Layer, type PageMeta, type SheetData, type Source } from "@/lib/types";
import type { QrOptions } from "@/lib/qr";
import { CheckCircle2, Info, XCircle } from "lucide-react";

export type Tab = "editor" | "convert" | "chat" | "qr" | "scanner" | "recent" | "support";
export type Panel = "pages" | "layers" | null;

const EMPTY: DocState = { pages: [], layers: [], edits: {} };
type Hist = { past: DocState[]; present: DocState; future: DocState[] };
type ToastT = { id: number; msg: string; type: "ok" | "error" | "info" };

export type WS = {
  tab: Tab;
  setTab: (t: Tab) => void;
  panel: Panel;
  setPanel: (p: Panel) => void;
  openPages: () => void;
  jump: { page: number; n: number } | null;
  jumpTo: (page: number) => void;
  doc: DocState;
  hasDoc: boolean;
  name: string;
  sources: Record<string, Source>;
  sheet: SheetData | null;
  setSheet: (fn: (s: SheetData) => SheetData) => void;
  setDoc: (fn: (d: DocState) => DocState, record?: boolean) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  dirty: boolean;
  markSaved: () => void;
  openFiles: (files: File[], opts?: { append?: boolean }) => Promise<boolean>;
  newBlank: () => void;
  closeDoc: () => void;
  loading: string;
  docId: number;
  textPages: string[];
  indexing: { done: number; total: number } | null;
  refreshIndex: () => void;
  exportPdf: (pageIdx?: number[]) => Promise<Uint8Array>;
  toast: (msg: string, type?: ToastT["type"]) => void;
  qrPreset: QrOptions | null;
  openFromHistory: (item: HistoryItem) => Promise<void>;
};

const Ctx = createContext<WS | null>(null);
export const useWS = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useWS outside provider");
  return c;
};

const OPENABLE = ["pdf", "png", "jpg", "jpeg", "webp", "gif", "txt", "md", "csv", "xlsx", "xls", "docx", "epub"];

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [tab, setTabState] = useState<Tab>("editor");
  const [panel, setPanel] = useState<Panel>(null);
  const [jump, setJump] = useState<{ page: number; n: number } | null>(null);
  const [hist, setHist] = useState<Hist>({ past: [], present: EMPTY, future: [] });
  const [sources, setSources] = useState<Record<string, Source>>({});
  const [sheet, setSheetState] = useState<SheetData | null>(null);
  const [name, setName] = useState("Untitled");
  const [loading, setLoading] = useState("");
  const [docId, setDocId] = useState(0);
  const [dirty, setDirty] = useState(false);
  const [textPages, setTextPages] = useState<string[]>([]);
  const [indexing, setIndexing] = useState<{ done: number; total: number } | null>(null);
  const [indexTick, setIndexTick] = useState(0);
  const [toasts, setToasts] = useState<ToastT[]>([]);
  const [qrPreset, setQrPreset] = useState<QrOptions | null>(null);

  const ref = useRef({ hist, sources, sheet, dirty });
  ref.current = { hist, sources, sheet, dirty };

  const toast = useCallback((msg: string, type: ToastT["type"] = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, msg, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), type === "error" ? 7000 : 3800);
  }, []);

  const setTab = useCallback((t: Tab) => setTabState(t), []);
  const openPages = useCallback(() => {
    setTabState("editor");
    setPanel("pages");
  }, []);
  const jumpTo = useCallback((page: number) => {
    setTabState("editor");
    setJump({ page, n: Date.now() });
  }, []);

  const setDoc = useCallback((fn: (d: DocState) => DocState, record = true) => {
    setHist((h) => {
      const next = fn(h.present);
      if (next === h.present) return h;
      if (!record) return { ...h, present: next };
      return { past: [...h.past.slice(-59), h.present], present: next, future: [] };
    });
    if (record) setDirty(true);
  }, []);

  const undo = useCallback(() => {
    setHist((h) => (h.past.length ? { past: h.past.slice(0, -1), present: h.past[h.past.length - 1], future: [h.present, ...h.future] } : h));
  }, []);
  const redo = useCallback(() => {
    setHist((h) => (h.future.length ? { past: [...h.past, h.present], present: h.future[0], future: h.future.slice(1) } : h));
  }, []);

  const setSheet = useCallback((fn: (s: SheetData) => SheetData) => {
    setSheetState((s) => (s ? fn(s) : s));
    setDirty(true);
  }, []);

  const reset = useCallback((next: DocState, srcs: Source[], nm: string, sh: SheetData | null) => {
    Object.values(ref.current.sources).forEach((s) => {
      try {
        s.pdf?.destroy?.();
      } catch {
        /* ignore */
      }
    });
    setSources(Object.fromEntries(srcs.map((s) => [s.id, s])));
    setHist({ past: [], present: next, future: [] });
    setSheetState(sh);
    setName(nm);
    setDirty(false);
    setDocId((n) => n + 1);
  }, []);

  const confirmReplace = () =>
    !ref.current.dirty || window.confirm("Replace the current document? Your unsaved changes will be lost.");

  const openFiles = useCallback(
    async (files: File[], opts: { append?: boolean } = {}) => {
      if (!files.length) return false;
      const cur = ref.current;
      const append = !!opts.append && cur.hist.present.pages.length > 0;
      if (opts.append && cur.sheet) {
        toast("Spreadsheets can't be merged with other files.", "error");
        return false;
      }
      if (!append && !confirmReplace()) return false;
      try {
        const pages: PageMeta[] = [];
        const layers: Layer[] = [];
        const srcs: Source[] = [];
        let sheetData: SheetData | null = null;
        for (const f of files) {
          setLoading(`Reading ${f.name}…`);
          await new Promise((r) => setTimeout(r, 20));
          try {
            const parsed = await parseFile(f);
            if (parsed.sheet) {
              if (files.length === 1 && !append) sheetData = parsed.sheet;
              else toast(`${f.name}: spreadsheets open on their own and were skipped.`, "info");
              continue;
            }
            if (parsed.part) {
              pages.push(...parsed.part.pages);
              layers.push(...parsed.part.layers);
              srcs.push(...parsed.part.sources);
            }
          } catch (e) {
            toast(`${f.name}: ${(e as Error).message || "could not be opened"}`, "error");
          }
        }
        if (sheetData) {
          reset(EMPTY, [], files[0].name, sheetData);
          return true;
        }
        if (!pages.length) return false;
        if (append) {
          setSources((s) => ({ ...s, ...Object.fromEntries(srcs.map((x) => [x.id, x])) }));
          setHist((h) => ({
            past: [...h.past.slice(-59), h.present],
            present: { ...h.present, pages: [...h.present.pages, ...pages], layers: [...h.present.layers, ...layers] },
            future: [],
          }));
          setDirty(true);
          toast(`Added ${pages.length} page${pages.length > 1 ? "s" : ""}.`, "ok");
        } else {
          reset({ pages, layers, edits: {} }, srcs, files.length > 1 ? "merged-document" : files[0].name, null);
        }
        return true;
      } finally {
        setLoading("");
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [reset, toast]
  );

  const newBlank = useCallback(() => {
    if (!confirmReplace()) return;
    const p: PageMeta = { id: uid(), w: A4.w, h: A4.h, crop: { ...NOCROP } };
    reset({ pages: [p], layers: [], edits: {} }, [], "Untitled document", null);
    setTabState("editor");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reset]);

  const closeDoc = useCallback(() => {
    if (!confirmReplace()) return;
    reset(EMPTY, [], "Untitled", null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reset]);

  const exportPdf = useCallback(
    async (pageIdx?: number[]) => {
      const { hist: h, sources: s, sheet: sh } = ref.current;
      if (sh) return sheetToPdfBytes(sh);
      return exportPdfBytes(h.present, s, pageIdx);
    },
    []
  );

  /* ---- background text indexing for "Ask your PDF" ---- */
  useEffect(() => {
    let stale = false;
    const { hist: h, sources: s, sheet: sh } = ref.current;
    if (sh) {
      setTextPages(sh.sheets.map((x) => x.rows.map((r) => r.join(" | ")).join("\n")));
      setIndexing(null);
      return;
    }
    if (!h.present.pages.length) {
      setTextPages([]);
      setIndexing(null);
      return;
    }
    setIndexing({ done: 0, total: h.present.pages.length });
    extractAllText(h.present, s, (done, total) => !stale && setIndexing({ done, total }), () => stale).then((t) => {
      if (stale) return;
      setTextPages(t);
      setIndexing(null);
    });
    return () => {
      stale = true;
    };
  }, [docId, hist.present.pages.length, indexTick]);

  const refreshIndex = useCallback(() => setIndexTick((n) => n + 1), []);

  const openFromHistory = useCallback(
    async (item: HistoryItem) => {
      const rec = await getHistoryRecord(item.id);
      if (!rec) {
        toast("This item's data is not stored locally (file was too large or storage is blocked).", "error");
        return;
      }
      if (item.kind === "qr" && rec.payload) {
        setQrPreset({ ...(rec.payload as QrOptions) });
        setTabState("qr");
        return;
      }
      if (rec.blob) {
        const ext = fileExt(item.fileName);
        if (OPENABLE.includes(ext)) {
          const ok = await openFiles([new File([rec.blob], item.fileName, { type: rec.blob.type })]);
          if (ok) setTabState("editor");
        } else {
          downloadBlob(rec.blob, item.fileName);
          toast(`${item.fileName} downloaded.`, "ok");
        }
      } else {
        toast("No file data was saved for this entry.", "info");
      }
    },
    [openFiles, toast]
  );

  const value = useMemo<WS>(
    () => ({
      tab, setTab, panel, setPanel, openPages, jump, jumpTo,
      doc: hist.present,
      hasDoc: hist.present.pages.length > 0 || !!sheet,
      name, sources, sheet, setSheet, setDoc, undo, redo,
      canUndo: hist.past.length > 0,
      canRedo: hist.future.length > 0,
      dirty, markSaved: () => setDirty(false),
      openFiles, newBlank, closeDoc, loading, docId, textPages, indexing, refreshIndex, exportPdf, toast, qrPreset, openFromHistory,
    }),
    [tab, setTab, panel, openPages, jump, jumpTo, hist, name, sources, sheet, setSheet, setDoc, undo, redo, dirty, openFiles, newBlank, closeDoc, loading, docId, textPages, indexing, refreshIndex, exportPdf, toast, qrPreset, openFromHistory]
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      {loading && (
        <div className="fixed inset-0 z-[120] grid place-items-center bg-black/60 backdrop-blur-sm">
          <div className="card flex items-center gap-3 px-5 py-4 text-sm text-zinc-200">
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-[#ff4a00] border-t-transparent" />
            {loading}
          </div>
        </div>
      )}
      <div className="pointer-events-none fixed bottom-4 left-1/2 z-[130] flex w-[min(92vw,420px)] -translate-x-1/2 flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`animate-pop pointer-events-auto flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm shadow-2xl backdrop-blur ${
              t.type === "ok"
                ? "border-emerald-500/40 bg-emerald-950/90 text-emerald-100"
                : t.type === "error"
                  ? "border-red-500/40 bg-red-950/90 text-red-100"
                  : "border-white/15 bg-zinc-900/95 text-zinc-100"
            }`}
          >
            {t.type === "ok" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> : t.type === "error" ? <XCircle className="mt-0.5 h-4 w-4 shrink-0" /> : <Info className="mt-0.5 h-4 w-4 shrink-0" />}
            <span>{t.msg}</span>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export { baseName };
