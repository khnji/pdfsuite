"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Code2, FileCode2, FileDown, FileJson, FileSpreadsheet, FileText, FileType2, FolderDown, Image as ImageIcon, Lock, Table2, Type, UploadCloud } from "lucide-react";
import { useRef, useState } from "react";
import { baseName, exportPdfBytes, extractAllText, parsePageRange, renderPageToCanvas, textPart } from "@/lib/docOps";
import { downloadBlob, saveToHistory } from "@/lib/history";
import { loadJSZip, loadXLSX } from "@/lib/libs";
import { canvasToBlob } from "@/lib/qr";
import { useAuth } from "./AuthProvider";
import { Spinner } from "./ui";
import { useWS } from "./Workspace";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const pad = (n: number, w = 3) => String(n).padStart(w, "0");
const CSS = "body{font-family:Arial,Helvetica,sans-serif;max-width:860px;margin:32px auto;padding:0 16px;line-height:1.6;color:#111}h2{border-bottom:1px solid #ddd;padding-bottom:4px;margin-top:36px;font-size:15px;color:#666}table{border-collapse:collapse;margin:12px 0}td,th{border:1px solid #bbb;padding:4px 8px;font-size:13px}th{background:#f1f1f1}";

type Fmt = { id: string; title: string; ext: string; desc: string; icon: React.ElementType; premium?: boolean };

const PAGED: Fmt[] = [
  { id: "pdf", title: "PDF", ext: ".pdf", desc: "Vector PDF with all your edits, layers & signatures", icon: FileDown },
  { id: "txt", title: "Plain Text", ext: ".txt", desc: "All text from every page", icon: Type },
  { id: "html", title: "HTML", ext: ".html", desc: "Web page with the document text", icon: Code2, premium: true },
  { id: "doc", title: "Word", ext: ".doc", desc: "Opens in Microsoft Word / Google Docs", icon: FileType2, premium: true },
  { id: "md", title: "Markdown", ext: ".md", desc: "Text with page headings", icon: FileCode2, premium: true },
  { id: "json", title: "JSON", ext: ".json", desc: "Structured text per page", icon: FileJson, premium: true },
  { id: "csv", title: "CSV", ext: ".csv", desc: "One row per text line (page, line, text)", icon: Table2, premium: true },
  { id: "xlsx", title: "Excel", ext: ".xlsx", desc: "Spreadsheet of text lines per page", icon: FileSpreadsheet, premium: true },
];
const SHEET: Fmt[] = [
  { id: "pdf", title: "PDF", ext: ".pdf", desc: "Vector PDF with table grid", icon: FileDown },
  { id: "csv", title: "CSV", ext: ".csv", desc: "Comma separated (one file per sheet)", icon: Table2 },
  { id: "xlsx", title: "Excel", ext: ".xlsx", desc: "Full workbook with all sheets", icon: FileSpreadsheet },
  { id: "html", title: "HTML", ext: ".html", desc: "Tables as a web page", icon: Code2 },
  { id: "txt", title: "Plain Text", ext: ".txt", desc: "Tab separated text", icon: Type },
  { id: "json", title: "JSON", ext: ".json", desc: "Rows per sheet", icon: FileJson },
];

export default function ConvertPanel() {
  const ws = useWS();
  const { premium, gate } = useAuth();
  const [busy, setBusy] = useState("");
  const [progress, setProgress] = useState("");
  const [range, setRange] = useState("");
  const [imgFmt, setImgFmt] = useState<"png" | "jpeg" | "webp">("png");
  const [scale, setScale] = useState(2);
  const [quality, setQuality] = useState(0.92);
  const [outMode, setOutMode] = useState<"zip" | "folder" | "each">("zip");
  const [paste, setPaste] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const base = baseName(ws.name);
  const isSheet = !!ws.sheet;
  const canFolder = typeof window !== "undefined" && "showDirectoryPicker" in window;

  const save = async (blob: Blob, fn: string, tool: string) => {
    downloadBlob(blob, fn);
    await saveToHistory(fn, tool, { blob });
    ws.toast(`${fn} saved – see Recent Work.`, "ok");
  };

  const pagesText = async () => extractAllText(ws.doc, ws.sources);

  const convert = async (f: Fmt) => {
    if (f.premium && !gate("Advanced converters")) return;
    setBusy(f.id);
    setProgress("");
    try {
      const tool = `Convert → ${f.title}`;
      if (f.id === "pdf") {
        const bytes = await ws.exportPdf();
        return await save(new Blob([bytes as BlobPart], { type: "application/pdf" }), `${base}.pdf`, tool);
      }
      if (isSheet) {
        const XLSX = await loadXLSX();
        const sheets = ws.sheet!.sheets;
        if (f.id === "xlsx") {
          const wb = XLSX.utils.book_new();
          sheets.forEach((s, i) => XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(s.rows), (s.name || "Sheet" + (i + 1)).slice(0, 31).replace(/[\\/?*[\]:]/g, "_")));
          const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
          return await save(new Blob([out], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), `${base}.xlsx`, tool);
        }
        if (f.id === "csv") {
          const csv = (rows: string[][]) => "\ufeff" + XLSX.utils.sheet_to_csv(XLSX.utils.aoa_to_sheet(rows));
          if (sheets.length === 1) return await save(new Blob([csv(sheets[0].rows)], { type: "text/csv;charset=utf-8" }), `${base}.csv`, tool);
          const JSZip = await loadJSZip();
          const zip = new JSZip();
          const dir = zip.folder(`${base}-csv`);
          sheets.forEach((s) => dir.file(`${s.name}.csv`, csv(s.rows)));
          return await save(await zip.generateAsync({ type: "blob" }), `${base}-csv.zip`, tool);
        }
        if (f.id === "html") {
          const body = sheets.map((s) => `<h2>${esc(s.name)}</h2><table>${s.rows.map((r, i) => `<tr>${r.map((c) => (i === 0 ? `<th>${esc(c)}</th>` : `<td>${esc(c)}</td>`)).join("")}</tr>`).join("")}</table>`).join("");
          return await save(new Blob([`<!doctype html><meta charset="utf-8"><title>${esc(base)}</title><style>${CSS}</style>${body}`], { type: "text/html" }), `${base}.html`, tool);
        }
        if (f.id === "txt") {
          const t = sheets.map((s) => `# ${s.name}\n` + s.rows.map((r) => r.join("\t")).join("\n")).join("\n\n");
          return await save(new Blob([t], { type: "text/plain;charset=utf-8" }), `${base}.txt`, tool);
        }
        if (f.id === "json") {
          const o: Record<string, string[][]> = {};
          sheets.forEach((s) => (o[s.name] = s.rows));
          return await save(new Blob([JSON.stringify(o, null, 2)], { type: "application/json" }), `${base}.json`, tool);
        }
        return;
      }

      const pages = await pagesText();
      if (f.id === "txt") return await save(new Blob([pages.map((p, i) => (pages.length > 1 ? `--- Page ${i + 1} ---\n` : "") + p).join("\n\n")], { type: "text/plain;charset=utf-8" }), `${base}.txt`, tool);
      if (f.id === "md") return await save(new Blob([`# ${base}\n\n` + pages.map((p, i) => `## Page ${i + 1}\n\n${p}`).join("\n\n")], { type: "text/markdown;charset=utf-8" }), `${base}.md`, tool);
      if (f.id === "json") return await save(new Blob([JSON.stringify({ title: base, pages: pages.map((t, i) => ({ page: i + 1, text: t })) }, null, 2)], { type: "application/json" }), `${base}.json`, tool);
      const html = pages
        .map((p, i) => `<section><h2>Page ${i + 1}</h2>${p.split(/\n{2,}/).map((para) => `<p>${esc(para).replace(/\n/g, "<br>")}</p>`).join("")}</section>`)
        .join("");
      if (f.id === "html") return await save(new Blob([`<!doctype html><html><head><meta charset="utf-8"><title>${esc(base)}</title><style>${CSS}</style></head><body>${html}</body></html>`], { type: "text/html" }), `${base}.html`, tool);
      if (f.id === "doc")
        return await save(
          new Blob([`<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>${esc(base)}</title><style>${CSS}</style></head><body>${html}</body></html>`], { type: "application/msword" }),
          `${base}.doc`,
          tool
        );
      const rows: (string | number)[][] = [["Page", "Line", "Text"]];
      pages.forEach((p, i) => p.split("\n").forEach((ln, k) => ln.trim() && rows.push([i + 1, k + 1, ln])));
      const XLSX = await loadXLSX();
      if (f.id === "csv") return await save(new Blob(["\ufeff" + XLSX.utils.sheet_to_csv(XLSX.utils.aoa_to_sheet(rows))], { type: "text/csv;charset=utf-8" }), `${base}.csv`, tool);
      if (f.id === "xlsx") {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), "Text");
        return await save(new Blob([XLSX.write(wb, { bookType: "xlsx", type: "array" })], { type: "application/octet-stream" }), `${base}.xlsx`, tool);
      }
    } catch (e) {
      ws.toast("Conversion failed: " + ((e as Error).message || "unknown error"), "error");
    } finally {
      setBusy("");
      setProgress("");
    }
  };

  const toImages = async () => {
    if (!gate("PDF to Images")) return;
    const total = ws.doc.pages.length;
    const idx = range.trim() ? parsePageRange(range, total) : Array.from({ length: total }, (_, i) => i);
    if (!idx.length) return ws.toast("No valid pages selected. Use a format like 1-3,5.", "error");
    setBusy("img");
    try {
      const mime = `image/${imgFmt}`;
      const ext = imgFmt === "jpeg" ? "jpg" : imgFmt;
      const files: { name: string; blob: Blob }[] = [];
      for (let n = 0; n < idx.length; n++) {
        setProgress(`Rendering page ${idx[n] + 1} (${n + 1}/${idx.length})…`);
        await new Promise((r) => setTimeout(r, 10));
        const meta = ws.doc.pages[idx[n]];
        let s = scale;
        while (meta.w * s * meta.h * s > 14e6) s *= 0.85;
        const c = await renderPageToCanvas(meta, ws.doc, ws.sources, s, { layers: true, crop: true });
        files.push({ name: `${base}-page-${pad(idx[n] + 1)}.${ext}`, blob: await canvasToBlob(c, mime, quality) });
      }
      const tool = `Convert → ${ext.toUpperCase()} images`;
      if (files.length === 1) {
        await save(files[0].blob, files[0].name, tool);
        return;
      }
      if (outMode === "folder" && canFolder) {
        try {
          const dir = await (window as any).showDirectoryPicker({ mode: "readwrite" });
          const sub = await dir.getDirectoryHandle(`${base}-images`, { create: true });
          for (const f of files) {
            const h = await sub.getFileHandle(f.name, { create: true });
            const w = await h.createWritable();
            await w.write(f.blob);
            await w.close();
          }
          await saveToHistory(`${base}-images (${files.length} files)`, tool, { status: "Saved to folder" });
          ws.toast(`${files.length} images saved into folder “${base}-images”.`, "ok");
          return;
        } catch (e) {
          if ((e as DOMException).name === "AbortError") return;
          ws.toast("Folder access failed – exporting a ZIP folder instead.", "info");
        }
      }
      if (outMode === "each") {
        for (const f of files) {
          downloadBlob(f.blob, f.name);
          await new Promise((r) => setTimeout(r, 350));
        }
        await saveToHistory(`${base} (${files.length} images)`, tool, { status: "Downloaded", blob: files[0].blob });
        ws.toast(`${files.length} images downloaded.`, "ok");
        return;
      }
      setProgress("Packing folder…");
      const JSZip = await loadJSZip();
      const zip = new JSZip();
      const dir = zip.folder(`${base}-images`);
      files.forEach((f) => dir.file(f.name, f.blob));
      await save(await zip.generateAsync({ type: "blob", compression: "STORE" }), `${base}-images.zip`, tool);
    } catch (e) {
      ws.toast("Image export failed: " + ((e as Error).message || "unknown error"), "error");
    } finally {
      setBusy("");
      setProgress("");
    }
  };

  const textToPdf = async () => {
    if (!paste.trim()) return;
    setBusy("paste");
    try {
      const part = textPart(paste);
      const bytes = await exportPdfBytes({ pages: part.pages, layers: part.layers, edits: {} }, {});
      await save(new Blob([bytes as BlobPart], { type: "application/pdf" }), "text-document.pdf", "Text → PDF");
    } catch (e) {
      ws.toast("Could not create PDF: " + (e as Error).message, "error");
    } finally {
      setBusy("");
    }
  };

  const formats = isSheet ? SHEET : PAGED;

  return (
    <div className="mx-auto h-full max-w-5xl overflow-y-auto p-4 sm:p-6">
      <div className="mb-5">
        <h2 className="text-xl font-bold text-white">Universal Converter</h2>
        <p className="text-sm text-zinc-400">Convert any document to PDF, text, images, HTML, Word, Excel and more – processed locally, nothing leaves your device.</p>
      </div>

      <div className="card mb-5 flex flex-wrap items-center gap-3 p-4">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#ff4a00]/15 text-[#ff7a3d]">
          <FileText className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold text-white">{ws.hasDoc ? ws.name : "No file loaded"}</div>
          <div className="text-xs text-zinc-500">
            {ws.hasDoc ? (isSheet ? `${ws.sheet!.sheets.length} sheet(s)` : `${ws.doc.pages.length} page(s)`) : "Choose a file to convert (PDF, DOCX, TXT, XLSX, XLS, CSV, EPUB, images)"}
          </div>
        </div>
        <button className="btn-primary" onClick={() => fileRef.current?.click()}>
          <UploadCloud className="h-4 w-4" /> {ws.hasDoc ? "Change file" : "Choose file"}
        </button>
        <input ref={fileRef} type="file" hidden multiple accept=".pdf,.docx,.txt,.md,.xlsx,.xls,.csv,.epub,.html,.rtf,image/*" onChange={(e) => { const f = Array.from(e.target.files || []); e.target.value = ""; ws.openFiles(f); }} />
      </div>

      {ws.hasDoc && (
        <>
          <h3 className="mb-3 text-sm font-semibold text-zinc-300">Convert to</h3>
          <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {formats.map((f) => {
              const Icon = f.icon;
              const locked = f.premium && !premium;
              return (
                <button key={f.id} disabled={!!busy} onClick={() => convert(f)} className="card group relative p-4 text-left transition hover:border-[#ff4a00]/50 hover:bg-[#ff4a00]/5 disabled:opacity-60">
                  <div className="mb-2 flex items-center justify-between">
                    <Icon className="h-6 w-6 text-[#ff7a3d]" />
                    {locked ? <Lock className="h-3.5 w-3.5 text-zinc-500" /> : busy === f.id ? <Spinner /> : <span className="text-[11px] text-zinc-500">{f.ext}</span>}
                  </div>
                  <div className="text-sm font-semibold text-white">{f.title}</div>
                  <div className="mt-0.5 text-[11px] leading-snug text-zinc-500">{f.desc}</div>
                </button>
              );
            })}
          </div>

          {!isSheet && (
            <div className="card mb-6 p-5">
              <div className="mb-4 flex items-center gap-2">
                <ImageIcon className="h-5 w-5 text-[#ff7a3d]" />
                <h3 className="text-sm font-semibold text-white">Export pages as images {!premium && <Lock className="ml-1 inline h-3.5 w-3.5 text-zinc-500" />}</h3>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-medium text-zinc-400">
                  Pages (blank = all {ws.doc.pages.length})
                  <input className="field mt-1.5 !py-2" placeholder="e.g. 1-3,5" value={range} onChange={(e) => setRange(e.target.value)} />
                </label>
                <label className="text-xs font-medium text-zinc-400">
                  Format
                  <select className="field mt-1.5 !py-2" value={imgFmt} onChange={(e) => setImgFmt(e.target.value as typeof imgFmt)}>
                    <option value="png">PNG (lossless)</option>
                    <option value="jpeg">JPG (smaller)</option>
                    <option value="webp">WEBP</option>
                  </select>
                </label>
                <label className="text-xs font-medium text-zinc-400">
                  Resolution
                  <select className="field mt-1.5 !py-2" value={scale} onChange={(e) => setScale(+e.target.value)}>
                    <option value={1}>Standard (72 dpi)</option>
                    <option value={2}>High (144 dpi)</option>
                    <option value={3}>Ultra (216 dpi)</option>
                  </select>
                </label>
                <label className="text-xs font-medium text-zinc-400">
                  Save as
                  <select className="field mt-1.5 !py-2" value={outMode} onChange={(e) => setOutMode(e.target.value as typeof outMode)}>
                    <option value="zip">Folder (ZIP)</option>
                    {canFolder && <option value="folder">Choose a folder on this device</option>}
                    <option value="each">Separate files</option>
                  </select>
                </label>
              </div>
              {imgFmt !== "png" && (
                <label className="mt-4 block text-xs font-medium text-zinc-400">
                  Quality ({Math.round(quality * 100)}%)
                  <input type="range" min={0.4} max={1} step={0.02} value={quality} onChange={(e) => setQuality(+e.target.value)} className="mt-1 w-full max-w-xs accent-[#ff4a00]" />
                </label>
              )}
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button className="btn-primary" onClick={toImages} disabled={!!busy}>
                  {busy === "img" ? <Spinner /> : <FolderDown className="h-4 w-4" />} Export images
                </button>
                {progress && <span className="text-xs text-zinc-400">{progress}</span>}
              </div>
            </div>
          )}
        </>
      )}

      <div className="card p-5">
        <div className="mb-3 flex items-center gap-2">
          <Type className="h-5 w-5 text-[#ff7a3d]" />
          <h3 className="text-sm font-semibold text-white">Quick text → PDF</h3>
        </div>
        <textarea className="field min-h-28 resize-y" placeholder="Type or paste text here to create a PDF instantly…" value={paste} onChange={(e) => setPaste(e.target.value)} />
        <button className="btn-primary mt-3" disabled={!paste.trim() || !!busy} onClick={textToPdf}>
          {busy === "paste" ? <Spinner /> : <FileDown className="h-4 w-4" />} Create PDF
        </button>
      </div>
    </div>
  );
}
