"use client";
import { Bot, FileSearch, Send, Sparkles, User } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { answer, buildIndex, type Answer } from "@/lib/search";
import { useWS } from "./Workspace";

type Msg = { role: "user" | "bot"; text?: string; ans?: Answer };

const SUGGEST = ["Summarize this document", "How many pages are there?", "Find email addresses", "What are the amounts or totals?", "List any dates"];

export default function ChatPanel() {
  const ws = useWS();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    ws.refreshIndex();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const index = useMemo(() => buildIndex(ws.textPages), [ws.textPages]);
  const label = (p: number) => (ws.sheet ? `Sheet “${ws.sheet.sheets[p - 1]?.name ?? p}”` : `Page ${p}`);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [msgs, thinking]);

  useEffect(() => {
    setMsgs([]);
  }, [ws.docId]);

  const send = (q: string) => {
    const text = q.trim();
    if (!text || thinking) return;
    setMsgs((m) => [...m, { role: "user", text }]);
    setInput("");
    setThinking(true);
    setTimeout(() => {
      const a = answer(index, text, label);
      setMsgs((m) => [...m, { role: "bot", ans: a }]);
      setThinking(false);
    }, 280);
  };

  if (!ws.hasDoc) {
    return (
      <div className="grid h-full place-items-center p-6 text-center">
        <div className="max-w-sm">
          <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-[#ff4a00]/15 text-[#ff7a3d]">
            <FileSearch className="h-8 w-8" />
          </div>
          <h2 className="text-xl font-bold text-white">Ask Your PDF</h2>
          <p className="mt-2 text-sm text-zinc-400">Open a document in the Editor first. Its text is indexed locally in your browser and you can then chat with it – no API key, no uploads.</p>
          <button className="btn-primary mt-5" onClick={() => ws.setTab("editor")}>
            Open a document
          </button>
        </div>
      </div>
    );
  }

  const ready = !ws.indexing;

  return (
    <div className="mx-auto flex h-full min-h-0 w-full max-w-3xl flex-col">
      <div className="flex shrink-0 items-center gap-3 border-b border-white/10 px-4 py-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-[#ff4a00] to-[#ff9a1a]">
          <Sparkles className="h-5 w-5 text-white" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold text-white">Ask Your PDF · {ws.name}</div>
          <div className="text-xs text-zinc-500">
            {ready
              ? index.chunks.length
                ? `Indexed ${index.pages.length} page${index.pages.length === 1 ? "" : "s"} · ${index.words.toLocaleString()} words · runs 100% offline`
                : "No selectable text found in this document"
              : `Reading text… ${ws.indexing!.done}/${ws.indexing!.total} pages`}
          </div>
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-3 py-4 sm:px-4">
        <Bubble role="bot">
          <p>Hi! I've read your document locally. Ask me anything – I'll show you the exact passages and the page they came from.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {SUGGEST.map((s) => (
              <button key={s} disabled={!ready} onClick={() => send(s)} className="rounded-full border border-[#ff4a00]/40 bg-[#ff4a00]/10 px-3 py-1 text-xs text-orange-200 hover:bg-[#ff4a00]/20 disabled:opacity-50">
                {s}
              </button>
            ))}
          </div>
        </Bubble>
        {msgs.map((m, i) =>
          m.role === "user" ? (
            <Bubble key={i} role="user">
              {m.text}
            </Bubble>
          ) : (
            <Bubble key={i} role="bot">
              <p>{m.ans!.text}</p>
              {m.ans!.bullets && (
                <ul className="mt-2 list-disc space-y-1.5 pl-5 text-[13px] text-zinc-300">
                  {m.ans!.bullets.map((b, k) => (
                    <li key={k}>{b}</li>
                  ))}
                </ul>
              )}
              <div className="mt-2 space-y-2">
                {m.ans!.hits.map((h, k) => (
                  <div key={k} className="rounded-xl border border-white/10 bg-black/30 p-3">
                    <div className="mb-1.5 flex items-center justify-between gap-2">
                      <span className="rounded bg-[#ff4a00]/20 px-2 py-0.5 text-[11px] font-semibold text-orange-300">{label(h.page)}</span>
                      {!ws.sheet && (
                        <button className="text-[11px] text-zinc-400 underline hover:text-white" onClick={() => ws.jumpTo(h.page - 1)}>
                          Go to page
                        </button>
                      )}
                    </div>
                    <p className="text-[13px] leading-relaxed text-zinc-300">
                      {h.segs.map((s, j) => (s.hl ? <mark key={j} className="hl">{s.text}</mark> : <span key={j}>{s.text}</span>))}
                    </p>
                  </div>
                ))}
              </div>
            </Bubble>
          )
        )}
        {thinking && (
          <Bubble role="bot">
            <span className="inline-flex gap-1">
              {[0, 1, 2].map((d) => (
                <span key={d} className="h-2 w-2 animate-bounce rounded-full bg-zinc-500" style={{ animationDelay: `${d * 0.15}s` }} />
              ))}
            </span>
          </Bubble>
        )}
        <div ref={endRef} />
      </div>

      <form
        className="flex shrink-0 gap-2 border-t border-white/10 p-3"
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
      >
        <input className="field" placeholder={ready ? "Ask a question about your document…" : "Reading your document…"} value={input} onChange={(e) => setInput(e.target.value)} disabled={!ready} />
        <button className="btn-primary !px-4" disabled={!ready || !input.trim() || thinking} aria-label="Send">
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}

function Bubble({ role, children }: { role: "user" | "bot"; children: React.ReactNode }) {
  const bot = role === "bot";
  return (
    <div className={`flex gap-2.5 ${bot ? "" : "flex-row-reverse"}`}>
      <div className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${bot ? "bg-[#ff4a00]/20 text-[#ff7a3d]" : "bg-white/10 text-zinc-300"}`}>
        {bot ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
      </div>
      <div className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${bot ? "rounded-tl-sm border border-white/10 bg-[#141821] text-zinc-200" : "rounded-tr-sm bg-gradient-to-br from-[#ff4a00] to-[#ff7a1a] text-white"}`}>{children}</div>
    </div>
  );
}
