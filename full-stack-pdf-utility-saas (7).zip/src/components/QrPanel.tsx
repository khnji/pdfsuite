"use client";
import { Camera, CameraOff, Check, Copy, Download, ExternalLink, ImageUp, QrCode, RefreshCw, ScanLine, SwitchCamera } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { downloadBlob, saveToHistory } from "@/lib/history";
import { canvasToBlob, copyText, decodeQrFromCanvas, decodeQrFromFile, qrToCanvas, qrToSvg, type QrOptions } from "@/lib/qr";
import { uid } from "@/lib/types";
import { useCamera } from "@/lib/useCamera";
import { useAuth } from "./AuthProvider";
import { ErrorFlash, Spinner } from "./ui";
import { useWS } from "./Workspace";

const DEFAULTS: QrOptions = { text: "https://example.com", size: 512, fg: "#000000", bg: "#ffffff", margin: 2, ec: "M" };

export default function QrPanel() {
  const ws = useWS();
  const { premium, gate } = useAuth();
  const [mode, setMode] = useState<"gen" | "scan">("gen");

  return (
    <div className="mx-auto h-full max-w-4xl overflow-y-auto p-4 sm:p-6">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">QR Code Toolkit</h2>
          <p className="text-sm text-zinc-400">Generate custom QR codes and scan them with your camera – fully offline.</p>
        </div>
        <div className="flex rounded-xl border border-white/10 bg-white/5 p-1">
          <button className={`tb-btn ${mode === "gen" ? "active" : ""}`} onClick={() => setMode("gen")}>
            <QrCode className="h-4 w-4" /> Generator
          </button>
          <button className={`tb-btn ${mode === "scan" ? "active" : ""}`} onClick={() => (premium || gate("QR Scanner")) && setMode("scan")}>
            <ScanLine className="h-4 w-4" /> Scanner {!premium && "🔒"}
          </button>
        </div>
      </div>
      {mode === "gen" || !premium ? <Generator /> : <Scanner />}
      <span className="hidden">{ws.docId}</span>
    </div>
  );
}

function Generator() {
  const ws = useWS();
  const [o, setO] = useState<QrOptions>(DEFAULTS);
  const [img, setImg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    if (ws.qrPreset) setO(ws.qrPreset);
  }, [ws.qrPreset]);

  useEffect(() => {
    let alive = true;
    const t = setTimeout(() => {
      qrToCanvas({ ...o, text: o.text || " " })
        .then((c) => {
          if (alive) {
            setImg(c.toDataURL("image/png"));
            setErr("");
          }
        })
        .catch(() => alive && setErr("This text is too long to fit in a QR code. Please shorten it."));
    }, 120);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [o]);

  const slug = (o.text || "qr").replace(/https?:\/\//, "").replace(/[^a-z0-9]+/gi, "-").slice(0, 24).replace(/^-|-$/g, "") || "qr";

  const downloadPng = async () => {
    try {
      const c = await qrToCanvas({ ...o, text: o.text || " " });
      const blob = await canvasToBlob(c);
      const fn = `qr-${slug}.png`;
      downloadBlob(blob, fn);
      saveToHistory(fn, "QR Generator", { blob, payload: o, kind: "qr" });
      ws.toast("QR code downloaded.", "ok");
    } catch (e) {
      setErr((e as Error).message);
    }
  };
  const downloadSvg = async () => {
    const svg = await qrToSvg({ ...o, text: o.text || " " });
    const blob = new Blob([svg], { type: "image/svg+xml" });
    downloadBlob(blob, `qr-${slug}.svg`);
    saveToHistory(`qr-${slug}.svg`, "QR Generator (SVG)", { blob, payload: o, kind: "qr" });
  };
  const insert = () => {
    if (!img) return;
    const go = () => {
      ws.setDoc((d) => {
        const page = d.pages[0];
        if (!page) return d;
        return { ...d, layers: [...d.layers, { id: uid(), pageId: page.id, type: "image", kind: "qr", x: (page.w - 120) / 2, y: 80, w: 120, h: 120, rot: 0, src: img }] };
      });
      ws.setTab("editor");
      ws.toast("QR code added to page 1 – drag it anywhere.", "ok");
    };
    if (!ws.hasDoc || ws.sheet) {
      ws.newBlank();
      setTimeout(go, 150);
    } else go();
  };

  return (
    <div className="grid gap-5 md:grid-cols-2">
      <div className="card space-y-4 p-5">
        <div>
          <label className="mb-1.5 block text-xs font-medium text-zinc-400">Text or URL</label>
          <textarea className="field min-h-24 resize-y" value={o.text} onChange={(e) => setO({ ...o, text: e.target.value })} placeholder="https://your-site.com" />
        </div>
        <div>
          <label className="mb-1.5 flex justify-between text-xs font-medium text-zinc-400">
            <span>Size</span>
            <span className="tabular-nums text-zinc-300">{o.size} × {o.size}px</span>
          </label>
          <input type="range" min={128} max={1024} step={16} value={o.size} onChange={(e) => setO({ ...o, size: +e.target.value })} className="w-full accent-[#ff4a00]" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <label className="text-xs font-medium text-zinc-400">
            Foreground
            <div className="mt-1.5 flex items-center gap-2">
              <input type="color" value={o.fg} onChange={(e) => setO({ ...o, fg: e.target.value })} className="h-10 w-14 cursor-pointer rounded-lg border border-white/10 bg-transparent" />
              <span className="font-mono text-[11px] text-zinc-500">{o.fg}</span>
            </div>
          </label>
          <label className="text-xs font-medium text-zinc-400">
            Background
            <div className="mt-1.5 flex items-center gap-2">
              <input type="color" value={o.bg} onChange={(e) => setO({ ...o, bg: e.target.value })} className="h-10 w-14 cursor-pointer rounded-lg border border-white/10 bg-transparent" />
              <span className="font-mono text-[11px] text-zinc-500">{o.bg}</span>
            </div>
          </label>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <label className="text-xs font-medium text-zinc-400">
            Margin ({o.margin})
            <input type="range" min={0} max={8} value={o.margin} onChange={(e) => setO({ ...o, margin: +e.target.value })} className="mt-3 w-full accent-[#ff4a00]" />
          </label>
          <label className="text-xs font-medium text-zinc-400">
            Error correction
            <select className="field mt-1.5 !py-2" value={o.ec} onChange={(e) => setO({ ...o, ec: e.target.value as QrOptions["ec"] })}>
              <option value="L">Low (7%)</option>
              <option value="M">Medium (15%)</option>
              <option value="Q">Quartile (25%)</option>
              <option value="H">High (30%)</option>
            </select>
          </label>
        </div>
      </div>

      <div className="card flex flex-col items-center gap-4 p-5">
        <div className="grid aspect-square w-full max-w-[300px] place-items-center rounded-2xl p-3" style={{ background: o.bg }}>
          {img ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={img} alt="QR code preview" className="h-full w-full object-contain [image-rendering:pixelated]" /> : <Spinner className="h-6 w-6 text-zinc-500" />}
        </div>
        <ErrorFlash message={err} />
        <button className="btn-primary w-full" onClick={downloadPng} disabled={!img}>
          <Download className="h-4 w-4" /> Download PNG ({o.size}px)
        </button>
        <div className="grid w-full grid-cols-2 gap-2">
          <button className="btn-ghost" onClick={downloadSvg} disabled={!img}>Download SVG</button>
          <button className="btn-ghost" onClick={insert} disabled={!img}>Add to document</button>
        </div>
      </div>
    </div>
  );
}

function Scanner() {
  const ws = useWS();
  const cam = useCamera();
  const [result, setResult] = useState("");
  const [copied, setCopied] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const running = useRef(false);
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const { videoRef, active, start, stop } = cam;

  const found = useCallback(
    async (text: string) => {
      running.current = false;
      stop();
      setResult(text);
      const ok = await copyText(text);
      setCopied(ok);
      ws.toast(ok ? "QR decoded & copied to clipboard." : "QR decoded.", "ok");
      if (navigator.vibrate) navigator.vibrate(80);
    },
    [stop, ws]
  );

  const loop = useCallback(() => {
    const tick = async () => {
      if (!running.current) return;
      const v = videoRef.current;
      if (v && v.readyState >= 2 && v.videoWidth) {
        const c = (canvas.current ||= document.createElement("canvas"));
        const k = Math.min(1, 720 / Math.max(v.videoWidth, v.videoHeight));
        c.width = Math.round(v.videoWidth * k);
        c.height = Math.round(v.videoHeight * k);
        c.getContext("2d", { willReadFrequently: true })!.drawImage(v, 0, 0, c.width, c.height);
        try {
          const t = await decodeQrFromCanvas(c);
          if (t && running.current) return found(t);
        } catch {
          /* keep scanning */
        }
      }
      timer.current = setTimeout(tick, 110);
    };
    tick();
  }, [videoRef, found]);

  const begin = async () => {
    setResult("");
    setErr("");
    const ok = await start();
    if (ok) {
      running.current = true;
      loop();
    }
  };
  useEffect(
    () => () => {
      running.current = false;
      clearTimeout(timer.current);
    },
    []
  );

  const fromFile = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    setErr("");
    try {
      const t = await decodeQrFromFile(f);
      if (t) await found(t);
      else setErr("No QR code was detected in that image. Try a sharper, closer photo.");
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const isUrl = /^https?:\/\//i.test(result);

  return (
    <div className="grid gap-5 md:grid-cols-2">
      <div className="card p-4">
        <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-black">
          <video ref={videoRef} playsInline muted autoPlay className={`h-full w-full object-cover ${active ? "" : "invisible"}`} />
          {!active && (
            <div className="absolute inset-0 grid place-items-center text-center text-sm text-zinc-500">
              <div>
                <CameraOff className="mx-auto mb-2 h-10 w-10" />
                Camera is off
              </div>
            </div>
          )}
          {active && (
            <>
              <div className="pointer-events-none absolute inset-[10%] rounded-2xl border-2 border-white/30">
                {["left-0 top-0 border-l-4 border-t-4 rounded-tl-xl", "right-0 top-0 border-r-4 border-t-4 rounded-tr-xl", "bottom-0 left-0 border-b-4 border-l-4 rounded-bl-xl", "bottom-0 right-0 border-b-4 border-r-4 rounded-br-xl"].map((c) => (
                  <span key={c} className={`absolute h-7 w-7 border-[#ff4a00] ${c}`} />
                ))}
              </div>
              <div className="pointer-events-none absolute inset-0">
                <div className="laser-line" />
              </div>
            </>
          )}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {!active ? (
            <button className="btn-primary flex-1" onClick={begin}>
              <Camera className="h-4 w-4" /> Start camera scan
            </button>
          ) : (
            <>
              <button className="btn-ghost flex-1" onClick={() => { running.current = false; stop(); }}>
                <CameraOff className="h-4 w-4" /> Stop
              </button>
              <button className="btn-ghost" onClick={() => cam.flip()} aria-label="Switch camera">
                <SwitchCamera className="h-4 w-4" />
              </button>
            </>
          )}
          <label className="btn-ghost cursor-pointer">
            {busy ? <Spinner /> : <ImageUp className="h-4 w-4" />} Upload image
            <input type="file" accept="image/*" hidden onChange={(e) => { fromFile(e.target.files?.[0]); e.target.value = ""; }} />
          </label>
        </div>
        <div className="mt-3">
          <ErrorFlash message={cam.error || err} />
        </div>
      </div>

      <div className="card p-5">
        <h3 className="mb-3 text-sm font-semibold text-white">Result</h3>
        {result ? (
          <div className="animate-pop space-y-3">
            <div className="max-h-56 overflow-auto break-all rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 font-mono text-sm text-emerald-100">{result}</div>
            <div className="flex flex-wrap gap-2">
              <button className="btn-primary" onClick={async () => setCopied(await copyText(result))}>
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} {copied ? "Copied" : "Copy"}
              </button>
              {isUrl && (
                <a className="btn-ghost" href={result} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" /> Open link
                </a>
              )}
              <button className="btn-ghost" onClick={begin}>
                <RefreshCw className="h-4 w-4" /> Scan again
              </button>
            </div>
          </div>
        ) : (
          <p className="text-sm text-zinc-500">Point your camera at a QR code or upload a picture. The decoded text is shown here and copied to your clipboard automatically.</p>
        )}
      </div>
    </div>
  );
}
