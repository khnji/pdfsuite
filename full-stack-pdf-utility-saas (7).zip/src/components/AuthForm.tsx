"use client";
import { KeyRound, Lock, Mail, User as UserIcon } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useAuth } from "./AuthProvider";
import { ErrorFlash, Logo, Spinner } from "./ui";

export default function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const { user, loading, signIn, signUp } = useAuth();
  const router = useRouter();
  const [f, setF] = useState({ name: "", email: "", password: "", key: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!loading && user && !busy) router.replace("/");
  }, [user, loading, busy, router]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      if (mode === "signup") {
        if (f.password.length < 6) throw new Error("Password must be at least 6 characters.");
        await signUp(f);
        setDone(true);
        setTimeout(() => router.replace("/"), 1100);
      } else {
        await signIn(f.email, f.password);
        router.replace("/");
      }
    } catch (ex) {
      setErr((ex as Error).message);
      setBusy(false);
    }
  };

  const Icon = ({ c }: { c: React.ReactNode }) => (
    <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500">{c}</span>
  );

  return (
    <main className="relative grid min-h-dvh place-items-center overflow-hidden px-4 py-10">
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full bg-[#ff4a00]/15 blur-[120px]" />
      <div className="card relative w-full max-w-md p-6 sm:p-8">
        <div className="mb-6 flex items-center gap-3">
          <Logo />
          <div>
            <h1 className="text-xl font-bold text-white">PDF Suite Pro</h1>
            <p className="text-xs text-zinc-400">{mode === "signup" ? "Activate your Lifetime Premium account" : "Welcome back"}</p>
          </div>
        </div>

        {done ? (
          <div className="animate-pop rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4 text-center">
            <p className="text-sm font-bold tracking-wide text-emerald-300">LIFETIME PREMIUM ACCESS ACTIVATED</p>
            <p className="mt-1 text-xs text-emerald-200/80">Opening your workspace…</p>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-3.5">
            {mode === "signup" && (
              <div className="relative">
                <Icon c={<UserIcon className="h-4 w-4" />} />
                <input className="field pl-9" placeholder="Full Name" required value={f.name} onChange={set("name")} autoComplete="name" />
              </div>
            )}
            <div className="relative">
              <Icon c={<Mail className="h-4 w-4" />} />
              <input className="field pl-9" type="email" placeholder="Email" required value={f.email} onChange={set("email")} autoComplete="email" />
            </div>
            <div className="relative">
              <Icon c={<Lock className="h-4 w-4" />} />
              <input
                className="field pl-9"
                type="password"
                placeholder="Password"
                required
                minLength={6}
                value={f.password}
                onChange={set("password")}
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
              />
            </div>
            {mode === "signup" && (
              <div>
                <label className="mb-1.5 block text-xs font-medium text-zinc-400">AppSumo License Key</label>
                <div className="relative">
                  <Icon c={<KeyRound className="h-4 w-4" />} />
                  <input
                    className="field pl-9 font-mono"
                    placeholder="e.g. PDFUNLMTD-123456-AB"
                    required
                    value={f.key}
                    onChange={set("key")}
                    autoCapitalize="characters"
                    autoComplete="off"
                    spellCheck={false}
                  />
                </div>
              </div>
            )}
            <ErrorFlash message={err} />
            <button className="btn-primary w-full" disabled={busy}>
              {busy && <Spinner />} {mode === "signup" ? (busy ? "Verifying license…" : "Sign Up & Activate") : busy ? "Signing in…" : "Log In"}
            </button>
          </form>
        )}

        <div className="mt-5 flex items-center justify-between text-sm text-zinc-400">
          {mode === "signup" ? (
            <span>
              Already activated?{" "}
              <Link href="/login" className="font-semibold text-[#ff7a3d] hover:underline">
                Log in
              </Link>
            </span>
          ) : (
            <span>
              New here?{" "}
              <Link href="/signup" className="font-semibold text-[#ff7a3d] hover:underline">
                Sign up with license key
              </Link>
            </span>
          )}
          <Link href="/" className="text-zinc-500 hover:text-zinc-300">
            Free mode →
          </Link>
        </div>
      </div>
    </main>
  );
}
