"use client";
import { CheckCircle2, LifeBuoy, Mail, Send, User } from "lucide-react";
import { useState } from "react";
import { supabase, SUPPORT_TABLE } from "@/lib/supabase";
import { ErrorFlash, Spinner } from "./ui";

export default function SupportPanel() {
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");
  const [err, setErr] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setState("sending");
    const { error } = await supabase.from(SUPPORT_TABLE).insert([{ name: f.name.trim(), email: f.email.trim(), message: f.message.trim() }]);
    if (error) {
      setErr("Could not send your message: " + error.message);
      setState("idle");
      return;
    }
    setF({ name: "", email: "", message: "" });
    setState("done");
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6">
      <div className="mx-auto max-w-xl">
        <div className="card overflow-hidden" style={{ boxShadow: "0 20px 60px rgba(255,74,0,0.08)" }}>
          <div className="h-1.5 bg-gradient-to-r from-[#ff4a00] to-[#ff9a1a]" />
          <div className="p-6 sm:p-8">
            <div className="mb-6 flex items-center gap-3">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#ff4a00]/15 text-[#ff4a00]">
                <LifeBuoy className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Customer Support</h2>
                <p className="text-sm text-zinc-400">Questions or problems? We&apos;re here to help.</p>
              </div>
            </div>

            {state === "done" ? (
              <div className="animate-pop py-6 text-center">
                <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-emerald-500/15 text-emerald-400">
                  <CheckCircle2 className="h-9 w-9" />
                </div>
                <p className="text-base font-medium leading-relaxed text-white">Thank you! Your message has been received successfully. Our support team will get back to you shortly!</p>
                <button className="mt-5 text-sm text-[#ff7a3d] underline" onClick={() => setState("idle")}>
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">Your Name</label>
                  <div className="relative">
                    <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                    <input className="field pl-9" required placeholder="John Smith" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
                  </div>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">Your Email</label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                    <input className="field pl-9" type="email" required placeholder="you@example.com" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
                  </div>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">Message or Issue</label>
                  <textarea className="field min-h-32 resize-y" required placeholder="Describe your question or the problem you ran into…" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} />
                </div>
                <ErrorFlash message={err} />
                <button className="btn-primary w-full" disabled={state === "sending"}>
                  {state === "sending" ? <Spinner /> : <Send className="h-4 w-4" />} {state === "sending" ? "Sending..." : "Send Message"}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
