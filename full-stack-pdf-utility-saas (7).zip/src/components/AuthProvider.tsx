"use client";
import type { User } from "@supabase/supabase-js";
import { KeyRound, Lock, LogIn, UserPlus } from "lucide-react";
import Link from "next/link";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { MSG_INVALID, MSG_REDEEMED, checkLicenseKey, lockLicenseKey, userHasLicense } from "@/lib/license";
import { supabase } from "@/lib/supabase";
import { ErrorFlash, Modal, Spinner } from "./ui";

type SignUpArgs = { name: string; email: string; password: string; key: string };
type Ctx = {
  user: User | null;
  premium: boolean;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (a: SignUpArgs) => Promise<void>;
  signOut: () => Promise<void>;
  redeem: (key: string) => Promise<void>;
  /** returns true if premium; otherwise opens the unlock dialog */
  gate: (feature?: string) => boolean;
  openGate: (feature?: string) => void;
};

const AuthCtx = createContext<Ctx | null>(null);
export const useAuth = () => {
  const c = useContext(AuthCtx);
  if (!c) throw new Error("useAuth outside provider");
  return c;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function friendly(err: any): string {
  const m: string = err?.message || String(err);
  if (/already registered|already been registered/i.test(m)) return "This email is already registered. Please log in instead.";
  if (/invalid login/i.test(m)) return "Incorrect email or password.";
  if (/password.*(at least|short)/i.test(m)) return "Password must be at least 6 characters.";
  if (/valid email|invalid email/i.test(m)) return "Please enter a valid email address.";
  if (/rate limit|too many/i.test(m)) return "Too many attempts. Please wait a minute and try again.";
  if (/failed to fetch|network/i.test(m)) return "Network error – please check your internet connection and try again.";
  return m;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [premium, setPremium] = useState(false);
  const [loading, setLoading] = useState(true);
  const [gateOpen, setGateOpen] = useState(false);
  const [gateFeature, setGateFeature] = useState<string | undefined>();

  const applyUser = useCallback((u: User | null) => {
    setUser(u);
    if (!u) {
      setPremium(false);
      return;
    }
    if (u.user_metadata?.premium === true) setPremium(true);
    if (u.email) {
      userHasLicense(u.email.toLowerCase()).then((ok) => {
        if (ok) setPremium(true);
      });
    }
  }, []);

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!alive) return;
      applyUser(data.session?.user ?? null);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      applyUser(session?.user ?? null);
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, [applyUser]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
    if (error) throw new Error(friendly(error));
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setPremium(false);
    setUser(null);
  }, []);

  const verify = async (key: string) => {
    let chk;
    try {
      chk = await checkLicenseKey(key);
    } catch (e) {
      throw new Error("Could not verify the license key right now (" + friendly(e) + ").");
    }
    return chk;
  };

  const signUp = useCallback(async ({ name, email, password, key }: SignUpArgs) => {
    const em = email.trim().toLowerCase();
    const chk = await verify(key);
    if (chk.state === "invalid") throw new Error(MSG_INVALID);
    if (chk.state === "redeemed") throw new Error(MSG_REDEEMED);

    // instant registration – Supabase has email confirmation disabled
    const { data, error } = await supabase.auth.signUp({
      email: em,
      password,
      options: { data: { full_name: name.trim() } },
    });
    if (error) throw new Error(friendly(error));
    if (data.user && data.user.identities && data.user.identities.length === 0)
      throw new Error("This email is already registered. Please log in instead.");
    if (!data.session) {
      const r = await supabase.auth.signInWithPassword({ email: em, password });
      if (r.error)
        throw new Error(
          'Account created, but Supabase still requires email confirmation. In Supabase go to Authentication → Providers → Email and turn OFF "Confirm email".'
        );
    }
    // lock the key: status "active" -> user's email
    const lock = await lockLicenseKey(chk.table!, chk.key!, em);
    if (!lock.ok) {
      await supabase.auth.signOut();
      throw new Error(MSG_REDEEMED);
    }
    await supabase.auth.updateUser({ data: { premium: true, license_key: chk.key, full_name: name.trim() } });
    setPremium(true);
  }, []);

  const redeem = useCallback(
    async (key: string) => {
      const { data: u } = await supabase.auth.getUser();
      const email = u.user?.email?.toLowerCase();
      if (!email) throw new Error("Please log in first.");
      const chk = await verify(key);
      if (chk.state === "invalid") throw new Error(MSG_INVALID);
      if (chk.state === "redeemed") {
        if (chk.owner && chk.owner.toLowerCase() === email) {
          await supabase.auth.updateUser({ data: { premium: true, license_key: chk.key } });
          setPremium(true);
          return;
        }
        throw new Error(MSG_REDEEMED);
      }
      const lock = await lockLicenseKey(chk.table!, chk.key!, email);
      if (!lock.ok) throw new Error(MSG_REDEEMED);
      await supabase.auth.updateUser({ data: { premium: true, license_key: chk.key } });
      setPremium(true);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const openGate = useCallback((f?: string) => {
    setGateFeature(f);
    setGateOpen(true);
  }, []);
  const gate = useCallback(
    (f?: string) => {
      if (premium) return true;
      openGate(f);
      return false;
    },
    [premium, openGate]
  );

  useEffect(() => {
    if (premium) setGateOpen(false);
  }, [premium]);

  const value = useMemo<Ctx>(
    () => ({ user, premium, loading, signIn, signUp, signOut, redeem, gate, openGate }),
    [user, premium, loading, signIn, signUp, signOut, redeem, gate, openGate]
  );

  return (
    <AuthCtx.Provider value={value}>
      {children}
      <GateModal open={gateOpen} onClose={() => setGateOpen(false)} feature={gateFeature} />
    </AuthCtx.Provider>
  );
}

function GateModal({ open, onClose, feature }: { open: boolean; onClose: () => void; feature?: string }) {
  const { user, redeem } = useAuth();
  const [key, setKey] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      await redeem(key);
      setKey("");
    } catch (ex) {
      setErr((ex as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Unlock Enterprise Features">
      <div className="mb-4 flex items-center gap-3 rounded-xl border border-[#ff4a00]/30 bg-[#ff4a00]/10 p-3 text-sm text-orange-100">
        <Lock className="h-5 w-5 shrink-0 text-[#ff7a3d]" />
        <span>{feature ? `“${feature}” is a Lifetime Premium feature.` : "This is a Lifetime Premium feature."} Enter your AppSumo license key to unlock everything.</span>
      </div>
      {user ? (
        <form onSubmit={submit} className="space-y-3">
          <p className="text-xs text-zinc-400">
            Signed in as <b className="text-zinc-200">{user.email}</b>
          </p>
          <div className="relative">
            <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
            <input className="field pl-9" placeholder="AppSumo License Key" value={key} onChange={(e) => setKey(e.target.value)} required />
          </div>
          <ErrorFlash message={err} />
          <button className="btn-primary w-full" disabled={busy || !key.trim()}>
            {busy ? <Spinner /> : <KeyRound className="h-4 w-4" />} Activate Lifetime Access
          </button>
        </form>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-zinc-300">Create a free account with your license key, or log in if you already activated.</p>
          <Link href="/signup" className="btn-primary w-full">
            <UserPlus className="h-4 w-4" /> Sign up with license key
          </Link>
          <Link href="/login" className="btn-ghost w-full">
            <LogIn className="h-4 w-4" /> Log in
          </Link>
        </div>
      )}
    </Modal>
  );
}
