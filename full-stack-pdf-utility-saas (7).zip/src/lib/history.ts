/* Recent Work – metadata lives in localStorage (max 10), file blobs live in IndexedDB. */
/* eslint-disable @typescript-eslint/no-explicit-any */

export type HistoryItem = {
  id: string;
  fileName: string;
  toolUsed: string;
  timestamp: string; // ISO date
  status: string;
  kind: "file" | "qr" | "none";
  mime?: string;
  size?: number;
  stored: boolean; // whether the data is saved locally and can be re-opened
};

const KEY = "pdfsuite_recent_work_v1";
const MAX_ITEMS = 10;
const MAX_BLOB = 90 * 1024 * 1024;
const EVT = "pdfsuite-history";

function read(): HistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}
function write(items: HistoryItem[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(items.slice(0, MAX_ITEMS)));
  } catch {
    /* quota */
  }
  window.dispatchEvent(new Event(EVT));
}

/* ---------------- IndexedDB blob store ---------------- */
function idb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("no idb"));
    const req = indexedDB.open("pdfsuite-pro", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("records");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbOp<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T | undefined> {
  const db = await idb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("records", mode);
    const r = fn(tx.objectStore("records"));
    tx.oncomplete = () => {
      db.close();
      resolve(r ? (r as IDBRequest<T>).result : undefined);
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
    tx.onabort = () => {
      db.close();
      reject(tx.error);
    };
  });
}

export type StoredRecord = { blob?: Blob; payload?: any };

export async function getHistoryRecord(id: string): Promise<StoredRecord | undefined> {
  try {
    return (await idbOp<StoredRecord>("readonly", (s) => s.get(id))) as StoredRecord | undefined;
  } catch {
    return undefined;
  }
}

/* ---------------- public API ---------------- */
export function getHistory(): HistoryItem[] {
  return read().sort((a, b) => +new Date(b.timestamp) - +new Date(a.timestamp));
}

/**
 * Call this whenever a tool finishes: saveToHistory("report.pdf", "PDF Editor", { blob })
 * Only the latest 10 entries are kept.
 */
export async function saveToHistory(
  fileName: string,
  toolUsed: string,
  opts: { status?: string; blob?: Blob; payload?: any; kind?: HistoryItem["kind"] } = {}
): Promise<HistoryItem | null> {
  if (typeof window === "undefined") return null;
  const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  let stored = false;
  const blob = opts.blob;
  const kind: HistoryItem["kind"] = opts.kind ?? (opts.payload ? "qr" : blob ? "file" : "none");
  if ((blob && blob.size <= MAX_BLOB) || opts.payload) {
    try {
      await idbOp("readwrite", (s) => s.put({ blob: blob && blob.size <= MAX_BLOB ? blob : undefined, payload: opts.payload }, id));
      stored = true;
    } catch {
      stored = false;
    }
  }
  const item: HistoryItem = {
    id,
    fileName,
    toolUsed,
    timestamp: new Date().toISOString(),
    status: opts.status ?? "Completed",
    kind,
    mime: blob?.type,
    size: blob?.size,
    stored,
  };
  const all = [item, ...read()];
  const keep = all.slice(0, MAX_ITEMS);
  const drop = all.slice(MAX_ITEMS);
  write(keep);
  for (const d of drop) deleteRecord(d.id);
  return item;
}

async function deleteRecord(id: string) {
  try {
    await idbOp("readwrite", (s) => s.delete(id));
  } catch {
    /* ignore */
  }
}

export function deleteHistoryItem(id: string) {
  write(read().filter((i) => i.id !== id));
  deleteRecord(id);
}

export function clearHistory() {
  const ids = read().map((i) => i.id);
  write([]);
  ids.forEach(deleteRecord);
}

export function subscribeHistory(cb: () => void) {
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY) cb();
  };
  window.addEventListener(EVT, cb);
  window.addEventListener("storage", onStorage);
  return () => {
    window.removeEventListener(EVT, cb);
    window.removeEventListener("storage", onStorage);
  };
}

export function relativeTime(iso: string, now = Date.now()): string {
  const s = Math.max(0, Math.floor((now - +new Date(iso)) / 1000));
  if (s < 10) return "just now";
  if (s < 60) return `${s} secs ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} min${m > 1 ? "s" : ""} ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hour${h > 1 ? "s" : ""} ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d} day${d > 1 ? "s" : ""} ago`;
  return new Date(iso).toLocaleDateString();
}

/** Save a Blob to the user's device. */
export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
