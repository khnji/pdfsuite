import { supabase } from "./supabase";

/**
 * The license table is called "appsumo_licenses pdf" (with a space). Depending on how it was
 * created, the API may expose it as "appsumo_licensespdf". We try the exact name first and then
 * fall back automatically, remembering whichever one works.
 */
export const TABLE_NAMES = ["appsumo_licenses pdf", "appsumo_licensespdf", "appsumo_licenses_pdf"];
let resolved: string | null = null;

export const MSG_REDEEMED = "This license key has already been redeemed by another account.";
export const MSG_INVALID = "Invalid AppSumo license key. Please check the key and try again.";

type Row = { id?: number; license_key: string; status: string | null };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function isMissingTable(err: any) {
  const m = `${err?.message || ""} ${err?.code || ""}`;
  return err?.code === "PGRST205" || err?.code === "42P01" || /schema cache|does not exist|could not find the table/i.test(m);
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function runOnTable<T>(op: (table: string) => PromiseLike<{ data: T | null; error: any }>) {
  const order = resolved ? [resolved, ...TABLE_NAMES.filter((t) => t !== resolved)] : TABLE_NAMES;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let lastErr: any = null;
  for (const t of order) {
    const { data, error } = await op(t);
    if (!error) {
      resolved = t;
      return { table: t, data: data as T };
    }
    if (!isMissingTable(error)) throw error;
    lastErr = error;
  }
  throw lastErr;
}

export type KeyCheck = {
  state: "valid" | "redeemed" | "invalid";
  table?: string;
  key?: string;
  owner?: string;
};

/** Looks up ANY key dynamically in the table. Valid only when status is exactly "active". */
export async function checkLicenseKey(raw: string): Promise<KeyCheck> {
  const key = raw.trim();
  if (!key) return { state: "invalid" };
  const candidates = Array.from(new Set([key, key.toUpperCase()]));
  for (const k of candidates) {
    const { table, data } = await runOnTable<Row[]>(
      async (t) => await supabase.from(t).select("id, license_key, status").eq("license_key", k).limit(25)
    );
    if (data && data.length) {
      const active = (r: Row) => String(r.status ?? "").trim().toLowerCase() === "active";
      if (data.every(active)) return { state: "valid", table, key: k };
      const used = data.find((r) => !active(r));
      return { state: "redeemed", table, key: k, owner: used?.status ?? undefined };
    }
  }
  return { state: "invalid" };
}

/** Swaps status "active" -> user's email so that ONE key works for ONE email only. */
export async function lockLicenseKey(table: string, key: string, email: string) {
  const { data, error } = await supabase
    .from(table)
    .update({ status: email })
    .eq("license_key", key)
    .eq("status", "active")
    .select("id");
  if (error) return { ok: true, warning: error.message };
  if (data && data.length > 0) return { ok: true };
  // nothing updated: either somebody else took it a moment ago, or update is blocked by policy
  const { data: rows } = await supabase.from(table).select("status").eq("license_key", key).limit(25);
  if (rows && rows.length) {
    const owners = rows.map((r) => String(r.status ?? "").toLowerCase());
    if (owners.every((s) => s === email.toLowerCase())) return { ok: true };
    if (owners.some((s) => s !== "active" && s !== email.toLowerCase())) return { ok: false };
  }
  return { ok: true, warning: "no rows updated" };
}

export async function userHasLicense(email: string): Promise<boolean> {
  try {
    const { data } = await runOnTable<{ id: number }[]>(
      async (t) => await supabase.from(t).select("id").eq("status", email).limit(1)
    );
    return !!(data && data.length);
  } catch {
    return false;
  }
}
