"use client";
import { useCallback, useEffect, useRef, useState } from "react";

export function useCamera() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [active, setActive] = useState(false);
  const [error, setError] = useState("");
  const [facing, setFacing] = useState<"environment" | "user">("environment");

  const stop = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setActive(false);
  }, []);

  const start = useCallback(
    async (f?: "environment" | "user") => {
      setError("");
      stop();
      const mode = f ?? facing;
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera access needs a secure (HTTPS) connection and a supported browser.");
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: mode }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
        } catch (e) {
          if ((e as DOMException).name === "NotAllowedError") throw e;
          stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        }
        streamRef.current = stream;
        const v = videoRef.current;
        if (!v) {
          stream.getTracks().forEach((t) => t.stop());
          return false;
        }
        v.srcObject = stream;
        v.muted = true;
        await v.play();
        setFacing(mode);
        setActive(true);
        return true;
      } catch (e) {
        const err = e as DOMException;
        setError(
          err.name === "NotAllowedError"
            ? "Camera permission was denied. Allow camera access in your browser settings and try again."
            : err.name === "NotFoundError"
              ? "No camera was found on this device."
              : err.message || "Could not start the camera."
        );
        setActive(false);
        return false;
      }
    },
    [facing, stop]
  );

  useEffect(() => () => stop(), [stop]);

  return { videoRef, active, error, facing, start, stop, flip: () => start(facing === "environment" ? "user" : "environment") };
}
