/* Document engine: parsing, rendering, exporting (100% client-side). */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { loadJSZip, loadMammoth, loadPdfJs, loadPdfLib, loadXLSX } from "./libs";
import { A4, FONT_CSS, uid } from "./types";
import type { Crop, DocState, FontFamily, Layer, PageMeta, SheetData, Source, TextEdit } from "./types";

export const fileExt = (name: string) => (name.split(".").pop() || "").toLowerCase();
export const baseName = (name: string) => name.replace(/\.[^.]+$/, "") || "document";
export const NOCROP: Crop = { l: 0, t: 0, r: 0, b: 0 };
export const TEXT_PAD = 4;
export const LINE_H = 1.25;

export function hexToRgb(c?: string): [number, number, number] {
  const m = /^#?([0-9a-f]{6})$/i.exec(c || "");
  const n = m ? parseInt(m[1], 16) : 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export const isRtl = (s: string) => /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/.test(s);

export function rotPt(cx: number, cy: number, lx: number, ly: number, rotDeg: number) {
  const a = (rotDeg * Math.PI) / 180;
  const c = Math.cos(a);
  const s = Math.sin(a);
  return { x: cx + lx * c - ly * s, y: cy + lx * s + ly * c };
}

export function wrapLines(text: string, maxW: number, measure: (s: string) => number): string[] {
  const out: string[] = [];
  const breakWord = (w: string) => {
    let chunk = "";
    for (const ch of Array.from(w)) {
      if (chunk && measure(chunk + ch) > maxW) {
        out.push(chunk);
        chunk = "";
      }
      chunk += ch;
    }
    return chunk;
  };
  for (const para of text.split("\n")) {
    if (para === "") {
      out.push("");
      continue;
    }
    let line = "";
    for (const word of para.split(" ")) {
      const test = line ? line + " " + word : word;
      if (measure(test) <= maxW) {
        line = test;
      } else if (!line) {
        line = breakWord(word);
      } else {
        out.push(line);
        line = measure(word) > maxW ? breakWord(word) : word;
      }
    }
    out.push(line);
  }
  return out;
}

/* ---------------- images ---------------- */
const imgCache = new Map<string, Promise<HTMLImageElement>>();
export function loadImg(src: string): Promise<HTMLImageElement> {
  let p = imgCache.get(src);
  if (!p) {
    p = new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("Image failed to load"));
      i.src = src;
    });
    imgCache.set(src, p);
    if (imgCache.size > 120) {
      const k = imgCache.keys().next().value;
      if (k) imgCache.delete(k);
    }
  }
  return p;
}

export async function fileToImage(file: File | Blob, maxDim = 2400): Promise<{ src: string; w: number; h: number }> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("This image format could not be read."));
      i.src = url;
    });
    const iw = img.naturalWidth || 512;
    const ih = img.naturalHeight || 512;
    const k = Math.min(1, maxDim / Math.max(iw, ih));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(iw * k));
    c.height = Math.max(1, Math.round(ih * k));
    const ctx = c.getContext("2d")!;
    const keepAlpha = /png|webp|gif|svg/.test(file.type);
    if (!keepAlpha) {
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, c.width, c.height);
    }
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return { src: keepAlpha ? c.toDataURL("image/png") : c.toDataURL("image/jpeg", 0.92), w: iw, h: ih };
  } finally {
    URL.revokeObjectURL(url);
  }
}

/* ---------------- painting layers on canvas ---------------- */
export function layerFont(l: { fs?: number; bold?: boolean; italic?: boolean; font?: FontFamily }, scale: number) {
  return `${l.italic ? "italic " : ""}${l.bold ? "bold " : ""}${(l.fs || 16) * scale}px ${FONT_CSS[l.font || "sans"]}`;
}

export function paintLayer(ctx: CanvasRenderingContext2D, l: Layer, scale: number, img?: HTMLImageElement) {
  ctx.save();
  ctx.translate((l.x + l.w / 2) * scale, (l.y + l.h / 2) * scale);
  ctx.rotate((l.rot * Math.PI) / 180);
  ctx.globalAlpha = l.opacity ?? 1;
  const w = l.w * scale;
  const h = l.h * scale;
  if (l.type === "image" && img) {
    ctx.drawImage(img, -w / 2, -h / 2, w, h);
  } else if (l.type === "shape") {
    ctx.fillStyle = l.fill || "#fde047";
    ctx.fillRect(-w / 2, -h / 2, w, h);
  } else if (l.type === "redact") {
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#000";
    ctx.fillRect(-w / 2, -h / 2, w, h);
  } else if (l.type === "text") {
    if (l.bg) {
      ctx.fillStyle = l.bg;
      ctx.fillRect(-w / 2, -h / 2, w, h);
    }
    const text = (l.text || "").replace(/\t/g, "    ");
    const fs = l.fs || 16;
    ctx.font = layerFont(l, scale);
    ctx.fillStyle = l.color || "#111";
    ctx.textBaseline = "alphabetic";
    ctx.direction = isRtl(text) ? "rtl" : "ltr";
    const pad = TEXT_PAD * scale;
    const lines = wrapLines(text, w - 2 * pad, (s) => ctx.measureText(s).width);
    const align = l.align || "left";
    ctx.textAlign = align;
    const x = align === "left" ? -w / 2 + pad : align === "right" ? w / 2 - pad : 0;
    lines.forEach((ln, i) => ctx.fillText(ln, x, -h / 2 + pad + i * fs * LINE_H * scale + fs * 0.96 * scale));
  }
  ctx.restore();
}

export function editsFor(doc: DocState, pageId: string): TextEdit[] {
  const pre = pageId + ":";
  const out: TextEdit[] = [];
  for (const k in doc.edits) if (k.startsWith(pre)) out.push(doc.edits[k]);
  return out;
}

export async function renderPageToCanvas(
  meta: PageMeta,
  doc: DocState,
  sources: Record<string, Source>,
  scale: number,
  opt: { layers?: boolean; crop?: boolean } = {}
): Promise<HTMLCanvasElement> {
  const W = Math.round(meta.w * scale);
  const H = Math.round(meta.h * scale);
  const full = document.createElement("canvas");
  full.width = W;
  full.height = H;
  const ctx = full.getContext("2d")!;
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, W, H);
  if (meta.srcId && sources[meta.srcId]) {
    const page = await sources[meta.srcId].pdf.getPage((meta.srcIndex || 0) + 1);
    await page.render({ canvasContext: ctx, viewport: page.getViewport({ scale: W / meta.w }) }).promise;
  } else if (meta.bg) {
    ctx.drawImage(await loadImg(meta.bg), 0, 0, W, H);
  }
  for (const e of editsFor(doc, meta.id)) {
    ctx.font = `${e.fs * scale}px ${FONT_CSS[e.family]}`;
    const tw = ctx.measureText(e.text).width / scale;
    ctx.fillStyle = "#fff";
    ctx.fillRect((e.x - 1) * scale, (e.base - e.fs * 1.02) * scale, (Math.max(e.w, tw) + 2) * scale, e.fs * 1.3 * scale);
    ctx.fillStyle = e.color || "#000";
    ctx.textBaseline = "alphabetic";
    ctx.textAlign = "left";
    ctx.fillText(e.text, e.x * scale, e.base * scale);
  }
  if (opt.layers !== false) {
    for (const l of doc.layers) {
      if (l.pageId !== meta.id || l.hidden) continue;
      let img: HTMLImageElement | undefined;
      if (l.type === "image" && l.src) {
        try {
          img = await loadImg(l.src);
        } catch {
          continue;
        }
      }
      paintLayer(ctx, l, scale, img);
    }
  }
  const { l, t, r, b } = meta.crop;
  if (opt.crop && (l || t || r || b)) {
    const c2 = document.createElement("canvas");
    c2.width = Math.max(1, Math.round(W - (l + r) * scale));
    c2.height = Math.max(1, Math.round(H - (t + b) * scale));
    c2.getContext("2d")!.drawImage(full, -l * scale, -t * scale);
    return c2;
  }
  return full;
}

/* ---------------- PDF export (pdf-lib) ---------------- */
function fontName(L: any, family: FontFamily, bold: boolean, italic: boolean) {
  const F = L.StandardFonts;
  const t: Record<FontFamily, string[]> = {
    sans: [F.Helvetica, F.HelveticaBold, F.HelveticaOblique, F.HelveticaBoldOblique],
    serif: [F.TimesRoman, F.TimesRomanBold, F.TimesRomanItalic, F.TimesRomanBoldItalic],
    mono: [F.Courier, F.CourierBold, F.CourierOblique, F.CourierBoldOblique],
  };
  return t[family][(bold ? 1 : 0) + (italic ? 2 : 0)];
}
const canEncode = (font: any, s: string) => {
  try {
    font.widthOfTextAtSize(s, 10);
    return true;
  } catch {
    return false;
  }
};

export async function exportPdfBytes(doc: DocState, sources: Record<string, Source>, pageIdx?: number[]): Promise<Uint8Array> {
  const L = await loadPdfLib();
  const { PDFDocument, rgb, degrees, PDFName, PDFString } = L;
  const out = await PDFDocument.create();
  const idxs = pageIdx ?? doc.pages.map((_: PageMeta, i: number) => i);
  const col = (c?: string) => {
    const [r, g, b] = hexToRgb(c);
    return rgb(r / 255, g / 255, b / 255);
  };

  // load sources & batch copy pages (keeps shared resources shared => small files)
  const srcDocs: Record<string, any> = {};
  const copied = new Map<string, any>();
  const wanted: Record<string, number[]> = {};
  for (const i of idxs) {
    const p = doc.pages[i];
    if (p.srcId && p.srcIndex !== undefined) (wanted[p.srcId] ||= []).push(p.srcIndex);
  }
  for (const sid of Object.keys(wanted)) {
    const src = sources[sid];
    if (!src) continue;
    try {
      srcDocs[sid] = await PDFDocument.load(src.bytes, { ignoreEncryption: false, updateMetadata: false });
      const uniq = Array.from(new Set(wanted[sid]));
      const pages = await out.copyPages(srcDocs[sid], uniq);
      uniq.forEach((n, k) => copied.set(sid + ":" + n, pages[k]));
    } catch {
      srcDocs[sid] = null; // encrypted / damaged -> flatten these pages instead
    }
  }

  const fonts: Record<string, any> = {};
  const getFont = async (family: FontFamily, bold: boolean, italic: boolean) => {
    const n = fontName(L, family, bold, italic);
    return (fonts[n] ||= await out.embedFont(n));
  };
  const imgs = new Map<string, any>();
  const embed = async (src: string) => {
    let im = imgs.get(src);
    if (!im) {
      im = /^data:image\/jpe?g/i.test(src) ? await out.embedJpg(src) : await out.embedPng(src);
      imgs.set(src, im);
    }
    return im;
  };

  const addLinks = (pg: any, ox: number, oy: number, H: number, links: Layer[]) => {
    for (const l of links) {
      if (!l.url) continue;
      const cx = l.x + l.w / 2;
      const cy = l.y + l.h / 2;
      const pts = [
        [-l.w / 2, -l.h / 2],
        [l.w / 2, -l.h / 2],
        [l.w / 2, l.h / 2],
        [-l.w / 2, l.h / 2],
      ].map(([a, b]) => rotPt(cx, cy, a, b, l.rot));
      const xs = pts.map((p) => ox + p.x);
      const ys = pts.map((p) => oy + H - p.y);
      const annot = out.context.obj({
        Type: "Annot",
        Subtype: "Link",
        Rect: [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)],
        Border: [0, 0, 1],
        C: [0.1, 0.4, 1],
        A: { Type: "Action", S: "URI", URI: PDFString.of(l.url) },
      });
      const ref = out.context.register(annot);
      const existing = pg.node.Annots();
      if (existing) existing.push(ref);
      else pg.node.set(PDFName.of("Annots"), out.context.obj([ref]));
    }
  };

  const applyCrop = (pg: any, bx: number, by: number, bw: number, bh: number, c: Crop) => {
    if (!(c.l || c.t || c.r || c.b)) return;
    const nx = bx + c.l;
    const ny = by + c.b;
    const nw = Math.max(20, bw - c.l - c.r);
    const nh = Math.max(20, bh - c.t - c.b);
    pg.setMediaBox(nx, ny, nw, nh);
    pg.setCropBox(nx, ny, nw, nh);
  };

  const flatten = async (meta: PageMeta) => {
    const scale = Math.min(2.5, 3400 / Math.max(meta.w, meta.h));
    const canvas = await renderPageToCanvas(meta, doc, sources, scale, { layers: true });
    const im = await out.embedJpg(canvas.toDataURL("image/jpeg", 0.92));
    const pg = out.addPage([meta.w, meta.h]);
    pg.drawImage(im, { x: 0, y: 0, width: meta.w, height: meta.h });
    addLinks(pg, 0, 0, meta.h, doc.layers.filter((l) => l.pageId === meta.id && l.type === "link" && !l.hidden));
    applyCrop(pg, 0, 0, meta.w, meta.h, meta.crop);
  };

  const vector = async (meta: PageMeta, pg: any) => {
    const cb = pg.getCropBox();
    const ox = cb.x;
    const oy = cb.y;
    const H = cb.height;
    const P = (x: number, y: number) => ({ x: ox + x, y: oy + H - y });
    for (const e of editsFor(doc, meta.id)) {
      const font = await getFont(e.family, false, false);
      const ok = canEncode(font, e.text);
      let tw = e.w;
      if (ok) tw = Math.max(tw, font.widthOfTextAtSize(e.text, e.fs));
      const bl = P(e.x - 1, e.base + e.fs * 0.28);
      pg.drawRectangle({ x: bl.x, y: bl.y, width: tw + 3, height: e.fs * 1.3, color: rgb(1, 1, 1) });
      if (ok) {
        const p = P(e.x, e.base);
        pg.drawText(e.text, { x: p.x, y: p.y, size: e.fs, font, color: col(e.color) });
      } else {
        const S = 4;
        const c = document.createElement("canvas");
        const m = document.createElement("canvas").getContext("2d")!;
        m.font = `${e.fs * S}px ${FONT_CSS[e.family]}`;
        const wpx = Math.ceil(m.measureText(e.text).width) + 4;
        c.width = wpx;
        c.height = Math.ceil(e.fs * 1.3 * S);
        const cx = c.getContext("2d")!;
        cx.font = m.font;
        cx.fillStyle = e.color || "#000";
        cx.direction = isRtl(e.text) ? "rtl" : "ltr";
        cx.textAlign = isRtl(e.text) ? "right" : "left";
        cx.fillText(e.text, isRtl(e.text) ? wpx - 2 : 2, e.fs * 1.02 * S);
        const im = await embed(c.toDataURL("image/png"));
        const p = P(e.x, e.base + e.fs * 0.28);
        pg.drawImage(im, { x: p.x, y: p.y, width: wpx / S, height: (c.height / S) });
      }
    }
    const links: Layer[] = [];
    for (const l of doc.layers) {
      if (l.pageId !== meta.id || l.hidden) continue;
      const cx = l.x + l.w / 2;
      const cy = l.y + l.h / 2;
      const rotate = degrees(-l.rot);
      const bl = rotPt(cx, cy, -l.w / 2, l.h / 2, l.rot);
      const bp = P(bl.x, bl.y);
      if (l.type === "link") {
        links.push(l);
      } else if (l.type === "image" && l.src) {
        const im = await embed(l.src);
        pg.drawImage(im, { x: bp.x, y: bp.y, width: l.w, height: l.h, rotate, opacity: l.opacity ?? 1 });
      } else if (l.type === "shape" || l.type === "redact") {
        pg.drawRectangle({
          x: bp.x,
          y: bp.y,
          width: l.w,
          height: l.h,
          rotate,
          color: l.type === "redact" ? rgb(0, 0, 0) : col(l.fill || "#fde047"),
          opacity: l.type === "redact" ? 1 : l.opacity ?? 0.4,
        });
      } else if (l.type === "text") {
        const fs = l.fs || 16;
        const text = (l.text || "").replace(/\t/g, "    ").replace(/\r/g, "");
        const font = await getFont(l.font || "sans", !!l.bold, !!l.italic);
        if (l.bg) pg.drawRectangle({ x: bp.x, y: bp.y, width: l.w, height: l.h, rotate, color: col(l.bg), opacity: l.opacity ?? 1 });
        if (!text.trim()) continue;
        if (!canEncode(font, text.replace(/\n/g, ""))) {
          const S = 3;
          const c = document.createElement("canvas");
          c.width = Math.ceil(l.w * S);
          c.height = Math.ceil(l.h * S);
          paintLayer(c.getContext("2d")!, { ...l, x: 0, y: 0, rot: 0, bg: undefined }, S);
          const im = await embed(c.toDataURL("image/png"));
          pg.drawImage(im, { x: bp.x, y: bp.y, width: l.w, height: l.h, rotate, opacity: l.opacity ?? 1 });
          continue;
        }
        const lines = wrapLines(text, l.w - 2 * TEXT_PAD, (s) => font.widthOfTextAtSize(s, fs));
        const align = l.align || "left";
        lines.forEach((ln, i) => {
          if (!ln) return;
          const lw = font.widthOfTextAtSize(ln, fs);
          const lx = align === "left" ? -l.w / 2 + TEXT_PAD : align === "right" ? l.w / 2 - TEXT_PAD - lw : -lw / 2;
          const ly = -l.h / 2 + TEXT_PAD + i * fs * LINE_H + fs * 0.96;
          const pt = rotPt(cx, cy, lx, ly, l.rot);
          const pp = P(pt.x, pt.y);
          pg.drawText(ln, { x: pp.x, y: pp.y, size: fs, font, color: col(l.color), rotate, opacity: l.opacity ?? 1 });
        });
      }
    }
    addLinks(pg, ox, oy, H, links);
    applyCrop(pg, cb.x, cb.y, cb.width, cb.height, meta.crop);
  };

  const usedCopy = new Set<string>();
  for (const i of idxs) {
    const meta = doc.pages[i];
    const hasRedact = doc.layers.some((l) => l.pageId === meta.id && l.type === "redact" && !l.hidden);
    const hasContent = hasRedact || doc.layers.some((l) => l.pageId === meta.id && !l.hidden) || editsFor(doc, meta.id).length > 0;
    const cropped = !!(meta.crop.l || meta.crop.t || meta.crop.r || meta.crop.b);
    if (meta.srcId) {
      const key = meta.srcId + ":" + meta.srcIndex;
      const rotated = (meta.rotate || 0) % 360 !== 0;
      if (srcDocs[meta.srcId] === null || !srcDocs[meta.srcId] || hasRedact || (rotated && (hasContent || cropped))) {
        await flatten(meta);
        continue;
      }
      let pg = copied.get(key);
      if (usedCopy.has(key)) {
        const [again] = await out.copyPages(srcDocs[meta.srcId], [meta.srcIndex!]);
        pg = again;
      }
      usedCopy.add(key);
      out.addPage(pg);
      try {
        await vector(meta, pg);
      } catch {
        out.removePage(out.getPageCount() - 1);
        await flatten(meta);
      }
    } else {
      if (hasRedact) {
        await flatten(meta);
        continue;
      }
      const pg = out.addPage([meta.w, meta.h]);
      if (meta.bg) {
        const im = await embed(meta.bg);
        pg.drawImage(im, { x: 0, y: 0, width: meta.w, height: meta.h });
      }
      try {
        await vector(meta, pg);
      } catch {
        out.removePage(out.getPageCount() - 1);
        await flatten(meta);
      }
    }
  }
  if (out.getPageCount() === 0) out.addPage([A4.w, A4.h]);
  out.setProducer("PDF Suite Pro");
  out.setCreator("PDF Suite Pro");
  return out.save();
}

/* ---------------- spreadsheet -> vector PDF ---------------- */
export async function sheetToPdfBytes(data: SheetData): Promise<Uint8Array> {
  const L = await loadPdfLib();
  const { PDFDocument, StandardFonts, rgb } = L;
  const out = await PDFDocument.create();
  const font = await out.embedFont(StandardFonts.Helvetica);
  const bold = await out.embedFont(StandardFonts.HelveticaBold);
  const clean = (s: string) => {
    s = String(s ?? "").replace(/[\r\n\t]+/g, " ");
    if (canEncode(font, s)) return s;
    return Array.from(s).map((c) => (canEncode(font, c) ? c : "?")).join("");
  };
  for (const sh of data.sheets) {
    const rows = sh.rows.length ? sh.rows : [[""]];
    const cols = Math.max(1, ...rows.slice(0, 500).map((r) => r.length));
    const landscape = cols > 6;
    const [PW, PH] = landscape ? [841.89, 595.28] : [595.28, 841.89];
    const M = 36;
    const fs = cols > 12 ? 7 : 9;
    const avail = PW - 2 * M;
    let widths: number[] = [];
    for (let c = 0; c < cols; c++) {
      let m = 3;
      for (const r of rows.slice(0, 300)) m = Math.max(m, Math.min(40, String(r[c] ?? "").length));
      widths.push(m * fs * 0.55 + 10);
    }
    const sum = widths.reduce((a, b) => a + b, 0);
    widths = widths.map((w) => (sum > avail ? (w * avail) / sum : w));
    const rh = fs * 1.9;
    let page = out.addPage([PW, PH]);
    let y = PH - M;
    page.drawText(clean(sh.name), { x: M, y: y - 8, size: 12, font: bold, color: rgb(0.1, 0.1, 0.1) });
    y -= 26;
    rows.forEach((row, ri) => {
      if (y - rh < M) {
        page = out.addPage([PW, PH]);
        y = PH - M;
      }
      let x = M;
      for (let c = 0; c < cols; c++) {
        const w = widths[c];
        const f = ri === 0 ? bold : font;
        if (ri === 0) page.drawRectangle({ x, y: y - rh, width: w, height: rh, color: rgb(0.93, 0.94, 0.96) });
        page.drawRectangle({ x, y: y - rh, width: w, height: rh, borderColor: rgb(0.75, 0.77, 0.8), borderWidth: 0.4 });
        let s = clean(row[c] ?? "");
        while (s && f.widthOfTextAtSize(s, fs) > w - 5) s = s.slice(0, -1);
        if (s) page.drawText(s, { x: x + 2.5, y: y - rh + fs * 0.6, size: fs, font: f, color: rgb(0.05, 0.05, 0.08) });
        x += w;
      }
      y -= rh;
    });
  }
  out.setProducer("PDF Suite Pro");
  return out.save();
}

/* ---------------- opening files ---------------- */
export type Part = { pages: PageMeta[]; layers: Layer[]; sources: Source[] };

async function loadPdfSource(bytes: Uint8Array, name: string): Promise<{ part: Part }> {
  const pdfjs = await loadPdfJs();
  const task = pdfjs.getDocument({ data: bytes.slice(), isEvalSupported: false });
  task.onPassword = (cb: (p: string) => void, reason: number) => {
    const pw = window.prompt(reason === 2 ? "Wrong password. Try again:" : "This PDF is password protected. Enter the password:");
    if (pw) cb(pw);
    else task.destroy();
  };
  const pdf = await task.promise;
  const src: Source = { id: uid(), name, bytes, pdf };
  const pages: PageMeta[] = [];
  const n = pdf.numPages;
  for (let s = 1; s <= n; s += 40) {
    const batch = await Promise.all(
      Array.from({ length: Math.min(40, n - s + 1) }, async (_, k) => {
        const page = await pdf.getPage(s + k);
        const vp = page.getViewport({ scale: 1 });
        return { w: vp.width, h: vp.height, rotate: page.rotate || 0, i: s + k - 1 };
      })
    );
    for (const b of batch) pages.push({ id: uid(), w: b.w, h: b.h, rotate: b.rotate, srcId: src.id, srcIndex: b.i, crop: { ...NOCROP } });
  }
  return { part: { pages, layers: [], sources: [src] } };
}

export function paginateText(text: string, W = A4.w, H = A4.h, margin = 56, fs = 12): string[] {
  const ctx = document.createElement("canvas").getContext("2d")!;
  ctx.font = `${fs}px ${FONT_CSS.sans}`;
  const lines = wrapLines(text.replace(/\r/g, "").replace(/\t/g, "    "), W - 2 * margin - 2 * TEXT_PAD, (s) => ctx.measureText(s).width);
  const per = Math.max(5, Math.floor((H - 2 * margin - 2 * TEXT_PAD) / (fs * LINE_H)));
  const pages: string[] = [];
  for (let i = 0; i < lines.length && pages.length < 2500; i += per) pages.push(lines.slice(i, i + per).join("\n"));
  return pages.length ? pages : [""];
}

export function textPart(text: string): Part {
  const margin = 56;
  const pages: PageMeta[] = [];
  const layers: Layer[] = [];
  for (const t of paginateText(text)) {
    const p: PageMeta = { id: uid(), w: A4.w, h: A4.h, crop: { ...NOCROP } };
    pages.push(p);
    layers.push({
      id: uid(), pageId: p.id, type: "text", kind: "text", x: margin, y: margin, w: A4.w - 2 * margin, h: A4.h - 2 * margin,
      rot: 0, text: t, fs: 12, color: "#111111", font: "sans", align: "left",
    });
  }
  return { pages, layers, sources: [] };
}

async function imagePart(file: File): Promise<Part> {
  const im = await fileToImage(file);
  const w = im.w >= im.h ? 595.28 : 420;
  const h = Math.max(120, (w * im.h) / im.w);
  return { pages: [{ id: uid(), w, h, bg: im.src, crop: { ...NOCROP } }], layers: [], sources: [] };
}

function htmlToText(html: string): string {
  const d = new DOMParser().parseFromString(html, "text/html");
  d.querySelectorAll("script,style,head").forEach((n) => n.remove());
  d.querySelectorAll("br").forEach((n) => n.replaceWith("\n"));
  d.querySelectorAll("p,div,h1,h2,h3,h4,h5,h6,li,tr,section,article").forEach((n) => n.append("\n"));
  d.querySelectorAll("td,th").forEach((n) => n.append("\t"));
  return (d.body?.textContent || "").replace(/[ \u00a0]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

async function epubText(buf: ArrayBuffer): Promise<string> {
  const JSZip = await loadJSZip();
  const zip = await JSZip.loadAsync(buf);
  const container = await zip.file("META-INF/container.xml")?.async("string");
  const opfPath = container ? /full-path="([^"]+)"/.exec(container)?.[1] : undefined;
  const parts: string[] = [];
  if (opfPath && zip.file(opfPath)) {
    const opf = await zip.file(opfPath).async("string");
    const dir = opfPath.includes("/") ? opfPath.slice(0, opfPath.lastIndexOf("/") + 1) : "";
    const manifest: Record<string, string> = {};
    for (const m of opf.matchAll(/<item\b[^>]*>/g)) {
      const id = /\bid="([^"]+)"/.exec(m[0])?.[1];
      const href = /\bhref="([^"]+)"/.exec(m[0])?.[1];
      if (id && href) manifest[id] = decodeURIComponent(href);
    }
    for (const m of opf.matchAll(/<itemref\b[^>]*idref="([^"]+)"/g)) {
      const href = manifest[m[1]];
      const f = href && zip.file(dir + href);
      if (f) parts.push(htmlToText(await f.async("string")));
    }
  }
  if (!parts.length) {
    const names = Object.keys(zip.files).filter((n) => /\.(x?html?)$/i.test(n)).sort();
    for (const n of names) parts.push(htmlToText(await zip.file(n).async("string")));
  }
  return parts.filter(Boolean).join("\n\n");
}

async function readSheets(file: File, ext: string): Promise<SheetData> {
  const XLSX = await loadXLSX();
  const wb = ext === "csv" || ext === "tsv" ? XLSX.read(await file.text(), { type: "string" }) : XLSX.read(await file.arrayBuffer(), { type: "array" });
  const sheets = wb.SheetNames.map((name: string) => {
    const rows: any[][] = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, raw: false, defval: "" });
    const cols = Math.max(1, ...rows.map((r) => r.length));
    return { name, rows: rows.map((r) => Array.from({ length: cols }, (_, i) => String(r[i] ?? ""))) };
  });
  return { sheets: sheets.length ? sheets : [{ name: "Sheet1", rows: [[""]] }] };
}

export type Parsed = { part?: Part; sheet?: SheetData };

export async function parseFile(file: File): Promise<Parsed> {
  const ext = fileExt(file.name);
  const type = file.type;
  if (ext === "pdf" || type === "application/pdf") return loadPdfSource(new Uint8Array(await file.arrayBuffer()), file.name);
  if (type.startsWith("image/") || ["png", "jpg", "jpeg", "webp", "gif", "bmp", "svg", "avif"].includes(ext)) return { part: await imagePart(file) };
  if (["xlsx", "xls", "csv", "tsv", "xlsm", "ods"].includes(ext)) return { sheet: await readSheets(file, ext) };
  if (ext === "docx") {
    const mammoth = await loadMammoth();
    const r = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return { part: textPart(r.value || "") };
  }
  if (ext === "doc") throw new Error("Old .doc files are not supported in the browser. Save it as .docx (or PDF) and open it again.");
  if (ext === "epub") return { part: textPart(await epubText(await file.arrayBuffer())) };
  if (["html", "htm", "xml"].includes(ext)) return { part: textPart(htmlToText(await file.text())) };
  if (["txt", "md", "rtf", "json", "log", "text", ""].includes(ext) || type.startsWith("text/")) {
    let t = await file.text();
    if (ext === "rtf") t = t.replace(/\\par[d]?/g, "\n").replace(/\{\\[^}]*\}/g, "").replace(/\\[a-z]+-?\d* ?/gi, "").replace(/[{}]/g, "");
    return { part: textPart(t) };
  }
  // last resort: try as text
  const t = await file.text();
  if (/[\u0000-\u0008]/.test(t.slice(0, 2000))) throw new Error(`".${ext}" files are not supported.`);
  return { part: textPart(t) };
}

/* ---------------- text extraction (for Ask-your-PDF + converters) ---------------- */
const textCache = new Map<string, string>();
export async function extractPageText(meta: PageMeta, doc: DocState, sources: Record<string, Source>): Promise<string> {
  if (meta.srcId && sources[meta.srcId]) {
    const key = meta.srcId + ":" + meta.srcIndex;
    const hit = textCache.get(key);
    if (hit !== undefined) return hit;
    const page = await sources[meta.srcId].pdf.getPage((meta.srcIndex || 0) + 1);
    const tc = await page.getTextContent();
    let s = "";
    for (const it of tc.items as any[]) s += it.str + (it.hasEOL ? "\n" : " ");
    s = s.replace(/[ \t]+\n/g, "\n").replace(/ {2,}/g, " ").trim();
    textCache.set(key, s);
    return s;
  }
  return doc.layers
    .filter((l) => l.pageId === meta.id && l.type === "text" && !l.hidden && l.kind !== "note")
    .map((l) => l.text || "")
    .join("\n")
    .trim();
}

export async function extractAllText(
  doc: DocState,
  sources: Record<string, Source>,
  onProgress?: (done: number, total: number) => void,
  isStale?: () => boolean
): Promise<string[]> {
  const out: string[] = [];
  for (let i = 0; i < doc.pages.length; i++) {
    if (isStale?.()) return out;
    try {
      out.push(await extractPageText(doc.pages[i], doc, sources));
    } catch {
      out.push("");
    }
    if (i % 10 === 9) onProgress?.(i + 1, doc.pages.length);
  }
  onProgress?.(doc.pages.length, doc.pages.length);
  return out;
}

export function parsePageRange(input: string, n: number): number[] {
  const set = new Set<number>();
  for (const part of input.split(/[,\s]+/).filter(Boolean)) {
    const m = /^(\d+)(?:-(\d+))?$/.exec(part);
    if (!m) continue;
    const a = Math.max(1, +m[1]);
    const b = Math.min(n, m[2] ? +m[2] : a);
    for (let i = a; i <= b; i++) set.add(i - 1);
  }
  return Array.from(set).sort((x, y) => x - y);
}
