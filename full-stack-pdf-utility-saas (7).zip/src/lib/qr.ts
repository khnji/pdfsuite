import { loadQRGen, loadJsQR } from "./libs";

export type QrOptions = { text: string; size: number; fg: string; bg: string; margin: number; ec: "L" | "M" | "Q" | "H" };

/* eslint-disable @typescript-eslint/no-explicit-any */
async function matrix(text: string, ec: string) {
  const qrcode = await loadQRGen();
  // enable full Unicode (UTF-8) support when the library provides it
  if (qrcode.stringToBytesFuncs?.["UTF-8"]) qrcode.stringToBytes = qrcode.stringToBytesFuncs["UTF-8"];
  const qr = qrcode(0, ec);
  qr.addData(text, "Byte");
  qr.make();
  return qr;
}

export async function qrToCanvas(o: QrOptions): Promise<HTMLCanvasElement> {
  const qr = await matrix(o.text || " ", o.ec);
  const n = qr.getModuleCount();
  const total = n + o.margin * 2;
  const cell = Math.max(1, Math.floor(o.size / total));
  const size = cell * total;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = o.bg;
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = o.fg;
  for (let r = 0; r < n; r++)
    for (let col = 0; col < n; col++)
      if (qr.isDark(r, col)) ctx.fillRect((col + o.margin) * cell, (r + o.margin) * cell, cell, cell);
  return c;
}

export async function qrToSvg(o: QrOptions): Promise<string> {
  const qr = await matrix(o.text || " ", o.ec);
  const n = qr.getModuleCount();
  const total = n + o.margin * 2;
  let path = "";
  for (let r = 0; r < n; r++)
    for (let c = 0; c < n; c++) if (qr.isDark(r, c)) path += `M${c + o.margin} ${r + o.margin}h1v1h-1z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} ${total}" width="${o.size}" height="${o.size}" shape-rendering="crispEdges"><rect width="${total}" height="${total}" fill="${o.bg}"/><path d="${path}" fill="${o.fg}"/></svg>`;
}

export function canvasToBlob(c: HTMLCanvasElement, type = "image/png", q = 0.92): Promise<Blob> {
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error("Could not encode image"))), type, q));
}

/** Decode a QR code from an image source (native BarcodeDetector first, jsQR as fallback). */
export async function decodeQrFromCanvas(canvas: HTMLCanvasElement): Promise<string | null> {
  const BD = (window as any).BarcodeDetector;
  if (BD) {
    try {
      const det = new BD({ formats: ["qr_code"] });
      const r = await det.detect(canvas);
      if (r && r.length) return r[0].rawValue as string;
    } catch {
      /* fall through */
    }
  }
  const jsQR = await loadJsQR();
  const ctx = canvas.getContext("2d")!;
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const res = jsQR(img.data, img.width, img.height, { inversionAttempts: "attemptBoth" });
  return res ? (res.data as string) : null;
}

export async function decodeQrFromFile(file: File): Promise<string | null> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("Cannot read image"));
      i.src = url;
    });
    const max = 1600;
    const k = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * k);
    c.height = Math.round(img.height * k);
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    return await decodeQrFromCanvas(c);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const t = document.createElement("textarea");
      t.value = text;
      t.style.position = "fixed";
      t.style.opacity = "0";
      document.body.appendChild(t);
      t.select();
      const ok = document.execCommand("copy");
      t.remove();
      return ok;
    } catch {
      return false;
    }
  }
}
