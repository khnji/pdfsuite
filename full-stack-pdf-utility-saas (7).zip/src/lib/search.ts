/* Pure-JS local "Ask your document" engine: BM25 retrieval + extractive summaries + data extractors. No network, no API keys. */

const STOP = new Set(
  "a an and are as at be but by for from has have had he her his how i if in into is it its of on or our she so than that the their them then there these they this to was we were what when where which who whom why will with you your do does did can could should would about tell me please show give find any all not no yes also just more most some such very".split(" ")
);

export type Chunk = { page: number; text: string; tokens: string[] };
export type Index = { chunks: Chunk[]; df: Map<string, number>; avgLen: number; pages: string[]; words: number; sentences: { page: number; text: string }[] };
export type Seg = { text: string; hl: boolean };
export type Hit = { page: number; segs: Seg[] };
export type Answer = { text: string; hits: Hit[]; bullets?: string[] };

const stem = (w: string) => (w.length > 5 ? w.replace(/(ing|edly|ed|ly|es|s)$/, "") : w.length > 3 ? w.replace(/s$/, "") : w);
export function tokenize(s: string): string[] {
  const m = s.toLowerCase().match(/[\p{L}\p{N}]+/gu) || [];
  return m.filter((w) => w.length > 1 && !STOP.has(w)).map(stem);
}

function splitSentences(text: string): string[] {
  const t = text.replace(/[ \t]+/g, " ").replace(/\n+/g, " ").trim();
  if (!t) return [];
  const out: string[] = [];
  for (const s of t.replace(/([.!?؟۔])\s+/g, "$1\u0001").split("\u0001")) {
    let x = s.trim();
    while (x.length > 600) {
      let cut = x.lastIndexOf(" ", 450);
      if (cut < 200) cut = 450;
      out.push(x.slice(0, cut).trim());
      x = x.slice(cut).trim();
    }
    if (x) out.push(x);
  }
  return out;
}

export function buildIndex(pages: string[]): Index {
  const chunks: Chunk[] = [];
  const sentences: { page: number; text: string }[] = [];
  let words = 0;
  pages.forEach((p, pi) => {
    words += (p.match(/\S+/g) || []).length;
    const sents = splitSentences(p);
    let buf = "";
    for (const s of sents) {
      sentences.push({ page: pi + 1, text: s });
      if (buf && (buf + " " + s).length > 320) {
        chunks.push({ page: pi + 1, text: buf, tokens: tokenize(buf) });
        buf = s;
      } else buf = buf ? buf + " " + s : s;
    }
    if (buf) chunks.push({ page: pi + 1, text: buf, tokens: tokenize(buf) });
  });
  const df = new Map<string, number>();
  let total = 0;
  for (const c of chunks) {
    total += c.tokens.length;
    for (const t of new Set(c.tokens)) df.set(t, (df.get(t) || 0) + 1);
  }
  return { chunks, df, avgLen: total / Math.max(1, chunks.length), pages, words, sentences };
}

function highlight(text: string, terms: string[]): Seg[] {
  const raw = Array.from(new Set(terms.filter((t) => t.length > 1)));
  if (!raw.length) return [{ text, hl: false }];
  const re = new RegExp("(" + raw.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") + ")", "gi");
  return text.split(re).filter(Boolean).map((s) => ({ text: s, hl: re.test(s) && ((re.lastIndex = 0), true) }));
}

function snippet(text: string, terms: string[], max = 420): string {
  if (text.length <= max) return text;
  const low = text.toLowerCase();
  let pos = -1;
  for (const t of terms) {
    const i = low.indexOf(t.toLowerCase());
    if (i >= 0 && (pos < 0 || i < pos)) pos = i;
  }
  const start = Math.max(0, pos < 0 ? 0 : pos - 120);
  return (start > 0 ? "… " : "") + text.slice(start, start + max).trim() + (start + max < text.length ? " …" : "");
}

function search(index: Index, query: string, k = 4) {
  const qt = Array.from(new Set(tokenize(query)));
  const N = index.chunks.length;
  const phrase = query.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
  const scored = index.chunks.map((c) => {
    let score = 0;
    const len = c.tokens.length || 1;
    for (const t of qt) {
      let tf = 0;
      for (const w of c.tokens) if (w === t) tf++;
      else if (t.length >= 4 && (w.startsWith(t) || t.startsWith(w)) && w.length >= 4) tf += 0.4;
      if (!tf) continue;
      const df = index.df.get(t) || 0;
      const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
      score += (idf * tf * 2.4) / (tf + 1.4 * (0.25 + 0.75 * (len / index.avgLen)));
    }
    if (phrase.length > 5 && c.text.toLowerCase().includes(phrase)) score += 3;
    return { c, score };
  });
  const top = scored.filter((s) => s.score > 0).sort((a, b) => b.score - a.score);
  if (!top.length) return { hits: [] as Hit[], terms: qt };
  const min = top[0].score * 0.3;
  const hits = top.filter((s) => s.score >= min).slice(0, k).map((s) => ({ page: s.c.page, segs: highlight(snippet(s.c.text, qt), qt.concat(query.split(/\s+/).filter((w) => w.length > 2))) }));
  return { hits, terms: qt };
}

function summarize(index: Index, n = 6) {
  const freq = new Map<string, number>();
  for (const c of index.chunks) for (const t of c.tokens) freq.set(t, (freq.get(t) || 0) + 1);
  const max = Math.max(1, ...freq.values());
  const scored = index.sentences
    .map((s, i) => {
      const toks = tokenize(s.text);
      if (toks.length < 5 || s.text.length < 40 || s.text.length > 400) return null;
      let sc = 0;
      for (const t of toks) sc += (freq.get(t) || 0) / max;
      return { ...s, i, sc: sc / Math.sqrt(toks.length) + (i < 8 ? 0.3 : 0) };
    })
    .filter(Boolean) as { page: number; text: string; i: number; sc: number }[];
  return scored.sort((a, b) => b.sc - a.sc).slice(0, n).sort((a, b) => a.i - b.i);
}

const EXTRACTORS: { test: RegExp; label: string; re: RegExp }[] = [
  { test: /e-?mail|mail id/i, label: "email addresses", re: /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g },
  { test: /phone|mobile|contact number|call|tel\b/i, label: "phone numbers", re: /\+?\d[\d\s().-]{7,}\d/g },
  { test: /link|url|website|web site|http/i, label: "links", re: /(?:https?:\/\/|www\.)[^\s<>"')]+/gi },
  { test: /\bdates?\b|when|deadline|due/i, label: "dates", re: /\b(?:\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{4}-\d{2}-\d{2}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.? \d{1,2},? \d{2,4}|\d{1,2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.? \d{2,4})\b/gi },
  { test: /amount|price|cost|total|balance|invoice|payment|money|fee/i, label: "amounts", re: /(?:[$€£₹]|Rs\.?|USD|PKR|INR|EUR)\s?\d[\d,]*(?:\.\d+)?/gi },
];

export function answer(index: Index, q: string, pageLabel: (p: number) => string): Answer {
  const query = q.trim();
  if (!index.chunks.length) {
    return { text: "I couldn't find any selectable text in this document. If it is a scanned image-only PDF, it has no text layer for me to read (offline OCR isn't included).", hits: [] };
  }
  const lower = query.toLowerCase();
  if (/how many (pages|words)|page count|word count|length of/.test(lower)) {
    return { text: `This document has ${index.pages.length} page${index.pages.length === 1 ? "" : "s"} and about ${index.words.toLocaleString()} words.`, hits: [] };
  }
  if (/summar|overview|gist|tl;?dr|main points|key points|what is this (doc|pdf|file)|what('s| is) (it|this) about|\babout (this|the) (doc|pdf|file)/.test(lower)) {
    const s = summarize(index);
    return {
      text: `Here are the key points I found across ${index.pages.length} page${index.pages.length === 1 ? "" : "s"}:`,
      hits: [],
      bullets: s.map((x) => `${x.text}  (${pageLabel(x.page)})`),
    };
  }
  const GENERIC = new Set(["find", "list", "show", "get", "extract", "give", "mention", "mentioned", "document", "pdf", "file", "text", "number", "address", "contain", "number", "id", "available", "provided", "included"]);
  const leftover = (ex: { test: RegExp }) =>
    query
      .toLowerCase()
      .match(/[\p{L}\p{N}]+/gu)!
      ?.filter((w) => w.length > 1 && !STOP.has(w) && !GENERIC.has(stem(w)) && !GENERIC.has(w) && !ex.test.test(w) && !ex.test.test(w.replace(/s$/, ""))).length ?? 0;
  for (const ex of EXTRACTORS) {
    if (!ex.test.test(lower) || leftover(ex) > 1) continue;
    const found: string[] = [];
    index.pages.forEach((p, i) => {
      const m = p.match(ex.re) || [];
      for (const v of m) {
        const val = v.trim();
        if (!found.some((f) => f.startsWith(val + "  ("))) found.push(`${val}  (${pageLabel(i + 1)})`);
      }
    });
    if (found.length) return { text: `I found these ${ex.label} in the document:`, hits: [], bullets: found.slice(0, 12) };
  }
  const { hits } = search(index, query, 4);
  if (!hits.length) {
    return { text: "I couldn't find anything matching that in the document. Try different keywords, a shorter question, or ask for a summary.", hits: [] };
  }
  return { text: hits.length === 1 ? "This is the most relevant passage I found:" : `I found ${hits.length} relevant passages, best match first:`, hits };
}
