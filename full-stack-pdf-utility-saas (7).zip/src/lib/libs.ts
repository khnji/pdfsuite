/* Lazy CDN loaders (open-source libraries, all run in the browser). Each tries several CDNs. */
/* eslint-disable @typescript-eslint/no-explicit-any */

const scripts: Record<string, Promise<void>> = {};
const libs: Record<string, Promise<any>> = {};

function addScript(url: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = url;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => {
      s.remove();
      reject(new Error("Failed to load " + url));
    };
    document.head.appendChild(s);
  });
}

async function loadFrom(urls: string[]): Promise<void> {
  const key = urls[0];
  if (!scripts[key]) {
    scripts[key] = (async () => {
      let last: unknown;
      for (const u of urls) {
        try {
          await addScript(u);
          return;
        } catch (e) {
          last = e;
        }
      }
      throw last;
    })();
    scripts[key].catch(() => delete scripts[key]);
  }
  return scripts[key];
}

function lib<T>(name: string, urls: string[], get: () => T | undefined, after?: (l: T) => void): Promise<T> {
  if (!libs[name]) {
    libs[name] = (async () => {
      if (typeof window === "undefined") throw new Error("Browser only");
      let l = get();
      if (!l) {
        await loadFrom(urls);
        l = get();
      }
      if (!l) throw new Error(name + " failed to initialise");
      after?.(l);
      return l;
    })();
    libs[name].catch(() => delete libs[name]);
  }
  return libs[name];
}

const w = () => window as any;
const JSD = "https://cdn.jsdelivr.net/npm/";
const CJS = "https://cdnjs.cloudflare.com/ajax/libs/";
const UNP = "https://unpkg.com/";

export const loadPdfJs = () =>
  lib<any>(
    "pdfjs",
    [CJS + "pdf.js/3.11.174/pdf.min.js", JSD + "pdfjs-dist@3.11.174/build/pdf.min.js", UNP + "pdfjs-dist@3.11.174/build/pdf.min.js"],
    () => w().pdfjsLib,
    (l) => {
      l.GlobalWorkerOptions.workerSrc = CJS + "pdf.js/3.11.174/pdf.worker.min.js";
    }
  );
export const loadPdfLib = () =>
  lib<any>("pdflib", [JSD + "pdf-lib@1.17.1/dist/pdf-lib.min.js", CJS + "pdf-lib/1.17.1/pdf-lib.min.js", UNP + "pdf-lib@1.17.1/dist/pdf-lib.min.js"], () => w().PDFLib);
export const loadMammoth = () =>
  lib<any>("mammoth", [JSD + "mammoth@1.6.0/mammoth.browser.min.js", CJS + "mammoth/1.6.0/mammoth.browser.min.js", UNP + "mammoth@1.6.0/mammoth.browser.min.js"], () => w().mammoth);
export const loadXLSX = () =>
  lib<any>("xlsx", [JSD + "xlsx@0.18.5/dist/xlsx.full.min.js", CJS + "xlsx/0.18.5/xlsx.full.min.js", UNP + "xlsx@0.18.5/dist/xlsx.full.min.js"], () => w().XLSX);
export const loadQRGen = () =>
  lib<any>("qrgen", [JSD + "qrcode-generator@1.4.4/qrcode.js", CJS + "qrcode-generator/1.4.4/qrcode.min.js", UNP + "qrcode-generator@1.4.4/qrcode.js"], () => w().qrcode);
export const loadJsQR = () =>
  lib<any>("jsqr", [JSD + "jsqr@1.4.0/dist/jsQR.js", CJS + "jsQR/1.4.0/jsQR.min.js", UNP + "jsqr@1.4.0/dist/jsQR.js"], () => w().jsQR);
export const loadJSZip = () =>
  lib<any>("jszip", [JSD + "jszip@3.10.1/dist/jszip.min.js", CJS + "jszip/3.10.1/jszip.min.js", UNP + "jszip@3.10.1/dist/jszip.min.js"], () => w().JSZip);
