/* eslint-disable @typescript-eslint/no-explicit-any */
export type Crop = { l: number; t: number; r: number; b: number };
export type FontFamily = "sans" | "serif" | "mono";

export type PageMeta = {
  id: string;
  w: number;
  h: number;
  srcId?: string; // pdf source
  srcIndex?: number; // 0-based page inside the source pdf
  rotate?: number; // intrinsic rotation of source page
  bg?: string; // image data url used as page background (photos, scans)
  crop: Crop;
};

export type LayerType = "text" | "image" | "shape" | "redact" | "link";
export type LayerKind = "text" | "note" | "image" | "logo" | "signature" | "qr" | "highlight" | "redact" | "link";

export type Layer = {
  id: string;
  pageId: string;
  type: LayerType;
  kind: LayerKind;
  x: number;
  y: number;
  w: number;
  h: number;
  rot: number;
  text?: string;
  fs?: number;
  color?: string;
  bold?: boolean;
  italic?: boolean;
  font?: FontFamily;
  align?: "left" | "center" | "right";
  bg?: string;
  src?: string;
  opacity?: number;
  url?: string;
  fill?: string;
  hidden?: boolean;
  name?: string;
};

export type TextEdit = {
  text: string;
  orig: string;
  x: number;
  top: number;
  w: number;
  h: number;
  fs: number;
  base: number;
  family: FontFamily;
  color: string;
};

export type DocState = { pages: PageMeta[]; layers: Layer[]; edits: Record<string, TextEdit> };

export type Source = { id: string; name: string; bytes: Uint8Array; pdf: any };

export type SheetData = { sheets: { name: string; rows: string[][] }[] };

export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

export const A4 = { w: 595.28, h: 841.89 };
export const LETTER = { w: 612, h: 792 };

export const FONT_CSS: Record<FontFamily, string> = {
  sans: 'Helvetica, Arial, "Liberation Sans", sans-serif',
  serif: '"Times New Roman", Times, "Liberation Serif", serif',
  mono: '"Courier New", Courier, "Liberation Mono", monospace',
};
