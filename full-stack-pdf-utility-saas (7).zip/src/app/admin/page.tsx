"use client";
import { Inbox, Lock, LogOut, RefreshCw, Search, ShieldCheck, Trash2 } from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ErrorFlash, Logo, Spinner } from "@/components/ui";
import { supabase, SUPPORT_TABLE } from "@/lib/supabase";

type Ticket = { id: number; name: string | null; email: string | null; message: string | null; created_at: string };

// Change this with the NEXT_PUBLIC_ADMIN_PASSCODE environment variable (e.g. in Netlify → Site settings → Environment).
const PASSCODE = process.env.NEXT_PUBLIC_ADMIN_PASSCODE || "pdfsuite-admin";

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [pass, setPass] = useState("");
  const [perr, setPerr] = useState("");
  const [rows, setRows] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [q, setQ] = useState("");
  const [deleting, setDeleting] = useState<number | null>(null);

  useEffect(() => {
    if (sessionStorage.getItem("pdfsuite_admin") === "1") setAuthed(true);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setErr("");
    const { data, error } = await supabase.from(SUPPORT_TABLE).select("*").order("created_at", { ascending: false });
    if (error) setErr("Could not load messages: " + error.message);
    else setRows((data as Ticket[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (authed) load();
  }, [authed, load]);

  const remove = async (id: number) => {
    if (!window.confirm("Delete this message permanently?")) return;
    setDeleting(id);
    const { error } = await supabase.from(SUPPORT_TABLE).delete().eq("id", id);
    setDeleting(null);
    if (error) return setErr("Could not delete: " + error.message);
    await load();
  };

  if (!authed) {
    return (
      <main className="grid min-h-dvh place-items-center px-4">
        <form
          className="card w-full max-w-sm p-6"
          onSubmit={(e) => {
            e.preventDefault();
            if (pass === PASSCODE) {
              sessionStorage.setItem("pdfsuite_admin", "1");
              setAuthed(true);
            } else setPerr("Incorrect passcode.");
          }}
        >
          <div className="mb-5 flex items-center gap-3">
            <Logo />
            <div>
              <h1 className="font-bold text-white">Admin Panel</h1>
              <p className="text-xs text-zinc-500">Support inbox · restricted</p>
            </div>
          </div>
          <div className="relative mb-3">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
            <input className="field pl-9" type="password" autoFocus placeholder="Admin passcode" value={pass} onChange={(e) => { setPass(e.target.value); setPerr(""); }} />
          </div>
          <ErrorFlash message={perr} />
          <button className="btn-primary mt-3 w-full">Unlock</button>
          <Link href="/" className="mt-4 block text-center text-xs text-zinc-500 hover:text-zinc-300">← Back to app</Link>
        </form>
      </main>
    );
  }

  const list = rows.filter((r) => !q || `${r.name} ${r.email} ${r.message}`.toLowerCase().includes(q.toLowerCase()));

  return (
    <main className="mx-auto min-h-dvh max-w-6xl px-3 py-6 sm:px-6">
      <header className="mb-5 flex flex-wrap items-center gap-3">
        <Logo />
        <div className="mr-auto">
          <h1 className="flex items-center gap-2 text-xl font-bold text-white">
            Support Inbox <ShieldCheck className="h-4 w-4 text-emerald-400" />
          </h1>
          <p className="text-xs text-zinc-500">{rows.length} message{rows.length === 1 ? "" : "s"} · newest first</p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input className="field !py-2 pl-9" placeholder="Search messages…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <button className="btn-ghost" onClick={load} disabled={loading}>
          {loading ? <Spinner /> : <RefreshCw className="h-4 w-4" />} Refresh
        </button>
        <button className="btn-ghost" onClick={() => { sessionStorage.removeItem("pdfsuite_admin"); setAuthed(false); setPass(""); }}>
          <LogOut className="h-4 w-4" /> Lock
        </button>
      </header>

      <div className="mb-4"><ErrorFlash message={err} /></div>

      {loading && rows.length === 0 ? (
        <div className="grid place-items-center py-20 text-zinc-500"><Spinner className="h-6 w-6" /></div>
      ) : list.length === 0 ? (
        <div className="card grid place-items-center px-6 py-16 text-center text-zinc-500">
          <Inbox className="mb-3 h-10 w-10" />
          {rows.length ? "No messages match your search." : "No support messages yet."}
        </div>
      ) : (
        <>
          {/* desktop table */}
          <div className="card hidden overflow-hidden md:block">
            <table className="w-full text-sm">
              <thead className="bg-white/[0.04] text-left text-xs uppercase tracking-wide text-zinc-500">
                <tr>
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Message</th>
                  <th className="px-4 py-3">Date / Time</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {list.map((r) => (
                  <tr key={r.id} className="align-top hover:bg-white/[0.02]">
                    <td className="px-4 py-3 font-medium text-white">{r.name}</td>
                    <td className="px-4 py-3"><a className="text-[#ff8a50] hover:underline" href={`mailto:${r.email}`}>{r.email}</a></td>
                    <td className="max-w-md whitespace-pre-wrap break-words px-4 py-3 text-zinc-300">{r.message}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs text-zinc-500">{new Date(r.created_at).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => remove(r.id)} disabled={deleting === r.id} className="inline-flex items-center gap-1.5 rounded-lg border border-red-500/30 px-2.5 py-1.5 text-xs font-medium text-red-300 hover:bg-red-500/15">
                        {deleting === r.id ? <Spinner className="h-3.5 w-3.5" /> : <Trash2 className="h-3.5 w-3.5" />} Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* mobile cards */}
          <div className="space-y-3 md:hidden">
            {list.map((r) => (
              <div key={r.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="truncate font-semibold text-white">{r.name}</div>
                    <a className="block truncate text-xs text-[#ff8a50]" href={`mailto:${r.email}`}>{r.email}</a>
                  </div>
                  <button onClick={() => remove(r.id)} disabled={deleting === r.id} className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-red-500/30 px-2.5 py-1.5 text-xs text-red-300">
                    {deleting === r.id ? <Spinner className="h-3.5 w-3.5" /> : <Trash2 className="h-3.5 w-3.5" />} Delete
                  </button>
                </div>
                <p className="mt-2 whitespace-pre-wrap break-words text-sm text-zinc-300">{r.message}</p>
                <p className="mt-2 text-[11px] text-zinc-500">{new Date(r.created_at).toLocaleString()}</p>
              </div>
            ))}
          </div>
        </>
      )}
    </main>
  );
}
