-- Run in Supabase → SQL editor. Adjust if you already have policies.
-- (The app works with the current open setup; these statements document the minimum it needs.)

-- 1) License keys: the browser must be able to read a key row and flip status "active" -> user email.
alter table public."appsumo_licenses pdf" enable row level security;

drop policy if exists "license read"   on public."appsumo_licenses pdf";
drop policy if exists "license redeem" on public."appsumo_licenses pdf";

create policy "license read" on public."appsumo_licenses pdf"
  for select using (true);

-- only rows that are still "active" can be updated, and only to an email address
create policy "license redeem" on public."appsumo_licenses pdf"
  for update using (status = 'active') with check (status <> 'active');

-- 2) Support tickets: anyone can send a message.
alter table public.support_tickets enable row level security;

drop policy if exists "tickets insert" on public.support_tickets;
create policy "tickets insert" on public.support_tickets for insert with check (true);

-- The admin page (/admin) reads + deletes tickets with the public key, so these two must stay open
-- unless you move the admin page behind a Supabase login. To lock it down instead:
--   drop policy if exists "tickets read" on public.support_tickets;
--   create policy "tickets read"   on public.support_tickets for select using (auth.jwt() ->> 'email' = 'YOUR_ADMIN_EMAIL');
--   create policy "tickets delete" on public.support_tickets for delete using (auth.jwt() ->> 'email' = 'YOUR_ADMIN_EMAIL');
drop policy if exists "tickets read" on public.support_tickets;
drop policy if exists "tickets delete" on public.support_tickets;
create policy "tickets read"   on public.support_tickets for select using (true);
create policy "tickets delete" on public.support_tickets for delete using (true);
